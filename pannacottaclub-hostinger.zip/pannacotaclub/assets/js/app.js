/* ==========================================================================
   PANNACOTTACLUB — amorçage & navigation
   Une seule page pour trois usages : client (/), livreur (/livreur), admin (/admin).
   ========================================================================== */
import { api, store, ui, ic, esc, live, connection, LS, K, navigate, toast, BASE } from './core.js';
import { renderHome, renderMenu, renderTrack, openCart, syncCartBar, stopLiveMap } from './views/client.js';
import { configureMap } from './map.js';
import { renderCourier, stopCourierLive } from './views/courier.js';
import { renderAdmin, stopAdminLive } from './views/admin.js';

const view = document.getElementById('view');
let current = '';
let menuStop = null;

/* ------------------------------------------------------------- les routes */
const ROUTES = {
  '/': renderHome,
  '/commander': renderMenu,
  '/suivi': renderTrack,
  '/livreur': renderCourier,
  '/admin': renderAdmin,
  '/equipe': renderCourier,
};

function params() { return new URLSearchParams(location.search); }

/** Chemin de la page, sans le préfixe du sous-dossier éventuel. */
function currentPath() {
  const full = location.pathname;
  const prefix = BASE.replace(/\/$/, '');
  const rel = prefix && full.startsWith(prefix) ? full.slice(prefix.length) : full;
  return (rel.replace(/\/+$/, '') || '/');
}

/** Nettoie ce qui doit l'être avant de changer d'écran. */
function teardown() {
  stopLiveMap();          // carte du livreur de la page d'accueil
  stopCourierLive();
  stopAdminLive();
  menuStop?.(); menuStop = null;
  document.querySelectorAll('.toolbar').forEach((t) => t.remove());
  syncCartBar();
}

async function route() {
  const path = currentPath();
  const handler = ROUTES[path];
  const key = path + location.search;
  if (key === current) return;
  current = key;
  teardown();

  // Espaces sécurisés : on masque le panier et la navigation grand public
  const isStaff = path === '/livreur' || path === '/admin' || path === '/equipe';
  paintHeader(path, isStaff);

  view.innerHTML = '';
  if (handler) {
    try {
      await handler(view, params());
    } catch (err) {
      console.error(err);
      view.innerHTML = `<section class="wrap" style="padding:40px 18px">${ui.banner('error', `Une erreur est survenue : ${esc(err.message)}`, 'alert')}</section>`;
    }
  } else {
    view.innerHTML = `
      <section class="wrap center" style="padding:60px 18px">
        <h1>Oups…</h1>
        <p class="muted">Cette page n'existe pas (ou plus).</p>
        <a class="btn" href="./" data-link style="max-width:320px;margin:0 auto">RETOUR À L'ACCUEIL</a>
      </section>`;
  }
  window.scrollTo(0, 0);

  // Le catalogue vivant reste synchronisé sur les écrans publics.
  if (path === '/' || path === '/commander') {
    menuStop = live('/api/events', {
      'menu:update': () => { /* géré par la vue commander */ },
      'settings:update': () => {},
    });
  }
}

/* ------------------------------------------------------------- en-tête --- */
function paintHeader(path, isStaff) {
  const header = document.getElementById('header');
  const footer = document.getElementById('footer');
  header.hidden = false;
  footer.hidden = isStaff;

  const nav = document.getElementById('nav');
  const actions = document.getElementById('headerActions');

  if (isStaff) {
    nav.innerHTML = `<a href="./" data-link>Site client</a>`;
    actions.innerHTML = '';
    return;
  }

  nav.innerHTML = `
    <a href="commander" data-link class="${path === '/commander' ? 'active' : ''}">Commander</a>
    <a href="suivi" data-link class="${path === '/suivi' ? 'active' : ''}">Suivre ma commande</a>
    ${store.session?.role === 'admin' ? '<a href="admin" data-link>Administration</a>' : ''}
    ${store.session?.role === 'courier' ? '<a href="livreur" data-link>Espace livreur</a>' : ''}`;

  actions.innerHTML = `
    <a class="icon-btn" href="suivi" data-link aria-label="Suivre ma commande" title="Suivre ma commande">${ic('route')}</a>
    <button class="icon-btn" id="headerCart" aria-label="Panier">
      ${ic('cart')}<span class="badge" id="headerCartCount" hidden>0</span>
    </button>`;

  actions.querySelector('#headerCart').addEventListener('click', openCart);
  updateHeaderCart();
}

function updateHeaderCart() {
  const badge = document.getElementById('headerCartCount');
  if (!badge) return;
  const n = store.cartCount();
  badge.hidden = n === 0;
  badge.textContent = String(n);
}

/* --------------------------------------------------------- liens & boutons */
document.addEventListener('click', (e) => {
  const link = e.target.closest('a[data-link]');
  if (link && link.origin === location.origin && !link.target) {
    e.preventDefault();
    const next = link.getAttribute('href') || './';
    if (next.replace(/^#/, '') !== '' ) navigate(next);
  }
  const opener = e.target.closest('[data-open-cart]');
  if (opener) { e.preventDefault(); openCart(); }
});

document.getElementById('cartOpen')?.addEventListener('click', openCart);
window.addEventListener('popstate', () => { current = ''; route(); });

/* ------------------------------------------------------------ état & temps */
store.on((type) => { if (type === 'cart') { syncCartBar(); updateHeaderCart(); } });

connection.onChange((online) => {
  if (online) toast('Connexion rétablie.', 'ok');
});

/* --------------------------------------------------------------- démarrage */
async function boot() {
  ui.sheet.init();

  try {
    store.config = await api.get('/api/config');
    // Le plan de la plage et vos repères de vente viennent de config.php
    configureMap({ zone: store.config.settings?.zone, map: store.config.map });
    document.getElementById('footerInfo').textContent =
      `${store.config.brand.tagline} Zone : ${store.config.settings.zone.label}. Paiement à la livraison uniquement.`;
  } catch {
    store.config = null;
  }

  // Récupère la session éventuelle (livreur/admin restent connectés).
  // Toujours interroger le serveur : le cookie de session est la référence,
  // même si ce navigateur n'a plus de jeton en mémoire.
  const tokens = LS.get(K.tokens, {});
  const jeton = tokens.courier || tokens.admin;
  if (jeton) api.token = jeton;
  try {
    const me = await api.get('/api/auth/me');
    store.session = me.user;
    if (store.session) LS.set(K.session, store.session);
  } catch (err) {
    // 401 confirmé par le serveur : on oublie le jeton mort. Erreur réseau :
    // on le conserve, ce n'est pas une déconnexion.
    if (err.status === 401) { api.token = null; LS.del(K.session); }
  }

  await route();
  syncCartBar();
  updateHeaderCart();

  setTimeout(() => document.getElementById('splash')?.classList.add('gone'), 550);

  // Actualise les positions GPS lors du retour sur l'onglet
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) updateHeaderCart();
  });
}

// Sert de point d'entrée aux scripts externes (boutons « panier » dynamiques)
window.PC = { openCart, navigate, store };

boot();

/* Service worker (installation sur l'écran d'accueil + secours hors ligne) */
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});   // chemin relatif : fonctionne à la racine comme dans un sous-dossier
  });
}
