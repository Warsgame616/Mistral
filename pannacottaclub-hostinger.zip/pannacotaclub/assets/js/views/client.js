/* ==========================================================================
   PANNACOTTACLUB — espace client
   Accueil → Carte → Panier → GPS → Commande → Suivi temps réel
   ========================================================================== */
import {
  api, store, myOrders, euro, heure, heureSec, esc, ic, toast, ui, navigate,
  getPosition, live, connection, LS, K, vibrate, distanceLabel,
} from '../core.js';
import { createMap, mapsLink, routeText } from '../map.js';

let mapCtl = null;        // carte du suivi
let liveMapStop = null;   // arrêt propre de la carte d'accueil
let lastPos = null;       // dernière position connue du livreur (carte d'accueil)
let liveStop = null;      // flux SSE du suivi
let watchedOrder = null;
let suiviTermine = false;   // vrai dès que la course est terminée (livrée ou annulée)
let geoState = { pos: null, error: '', loading: false };

const CATEGORY_ICON = { glaces: 'ice', boissons: 'cup', encas: 'food' };

/* ============================================================== ACCUEIL ==== */
export async function renderHome(root) {
  const cfg = store.config || {};
  const zone = cfg.settings?.zone || {};
  const open = cfg.settings?.acceptingOrders !== false;
  const liveMap = cfg.settings?.liveMapPublic !== false;   // carte du livreur sur l'accueil

  root.innerHTML = `
  <section class="hero">
    <svg class="hero-wave" viewBox="0 0 1440 240" preserveAspectRatio="none" aria-hidden="true">
      <path d="M0 150 C 220 90 360 210 620 150 C 880 90 1060 190 1440 130 L1440 240 L0 240 Z" fill="#fff" opacity=".5"/>
      <path d="M0 190 C 260 130 420 240 700 180 C 980 120 1140 210 1440 165 L1440 240 L0 240 Z" fill="#fff" opacity=".35"/>
    </svg>
    <div class="wrap center" style="position:relative">
      <img class="hero-logo" src="assets/img/logo.png" alt="Logo PANNACOTTACLUB">
      <h1>PANNACOTTACLUB</h1>
      <p class="sub">Livré directement sur la plage.</p>
      <div class="cta stack">
        <a class="btn btn-white" href="commander" data-link>COMMANDER</a>
        <a class="btn btn-outline" href="suivi" data-link style="background:transparent;border-color:rgba(255,255,255,.6);color:#fff">SUIVRE MA COMMANDE</a>
      </div>
      <div class="hero-meta">
        <span class="hero-chip">${ic('pin')}${esc(zone.label || 'Plage de Cabourg')}</span>
        <span class="hero-chip">${ic('euro')}Paiement à la livraison</span>
        <span class="hero-chip">${ic('clock')}Service ${open ? 'ouvert' : 'fermé'}</span>
      </div>
    </div>
  </section>

  ${liveMap ? `
  <section class="section">
    <div class="wrap">
      <p class="eyebrow">En direct</p>
      <h2 class="mb-1">Notre livreur, en ce moment sur la plage.</h2>
      <p class="muted mb-2">Dès qu'une commande part, sa position s'affiche ici. Vous voyez le service tourner.</p>
      <div class="live-card">
        <div class="live-head" id="liveHead">
          <span class="live-dot" aria-hidden="true"></span>
          <span class="grow">
            <strong id="liveTitle">Connexion au service…</strong><br>
            <span class="small muted" id="liveSub">La carte apparaît dès qu'un livreur est en course.</span>
          </span>
          <span class="tag" id="liveTag" hidden></span>
        </div>
        <div class="map" id="liveMapEl" style="height:330px"></div>
        <div class="live-foot">
          <a class="btn btn-sm" href="commander" data-link>COMMANDER</a>
          <span class="small muted">Position du livreur en direct, au mètre près. Aucune donnée de nos clients n'est publiée ici.</span>
        </div>
      </div>
    </div>
  </section>` : ''}

  <section class="section">
    <div class="wrap">
      <p class="eyebrow">Comment ça marche</p>
      <h2>Trois gestes, et c'est servi sur votre serviette.</h2>
      <div class="steps mt-3">
        <div class="step"><span class="n">1</span><div><h4>Scannez le panneau</h4><p>Les panneaux PannacottaClub sont installés près des accès et des escaliers de la plage.</p></div></div>
        <div class="step"><span class="n">2</span><div><h4>Choisissez, partagez votre position</h4><p>Glaces, boissons, encas. Votre position GPS suffit : inutile de décrire où vous êtes.</p></div></div>
        <div class="step"><span class="n">3</span><div><h4>Nous arrivons, vous payez sur place</h4><p>Suivez votre livreur en direct sur la carte. Aucun paiement en ligne : vous réglez à la livraison.</p></div></div>
      </div>
      <div class="mt-3"><a class="btn" href="commander" data-link>VOIR LA CARTE ${ic('arrow')}</a></div>
    </div>
  </section>

  <section class="section section-blue">
    <div class="wrap">
      <div class="grid-3">
        <div class="card card-flat">
          <span class="tag">${ic('pin')}Zone</span>
          <h3 class="mt-2">${esc(zone.label || 'Plage de Cabourg')}</h3>
          <p class="small muted mb-0">Livraison entre les postes de secours 1 et 2, directement sur le sable.</p>
        </div>
        <div class="card card-flat">
          <span class="tag">${ic('euro')}Paiement</span>
          <h3 class="mt-2">À la livraison</h3>
          <p class="small muted mb-0">Espèces ou carte sans contact auprès de votre livreur. Aucune donnée bancaire en ligne.</p>
        </div>
        <div class="card card-flat">
          <span class="tag">${ic('sun')}Saison</span>
          <h3 class="mt-2">Été à Cabourg</h3>
          <p class="small muted mb-0">Glaces artisanales, boissons fraîches et encas, servis en quelques minutes.</p>
        </div>
      </div>
    </div>
  </section>`;

  if (liveMap) mountLiveMap(root);
}

/* --------------------------------------------- carte publique du livreur --- */

/**
 * Carte de la page d'accueil : elle montre le livreur pendant ses livraisons.
 * Les données viennent de /api/couriers/live (position au mètre près, aucune
 * information client, et rien du tout si l'option est désactivée dans l'admin).
 * Rafraîchissement discret toutes les 10 s, arrêt propre en quittant la page.
 */
async function mountLiveMap(root) {
  const el = root.querySelector('#liveMapEl');
  if (!el) return;
  const zone = store.config?.settings?.zone || { lat: 49.29155, lng: -0.12125, radius: 900 };
  const map = createMap(el, { center: zone, zoom: 15, zone });
  const titre = root.querySelector('#liveTitle');
  const sous = root.querySelector('#liveSub');
  const tag = root.querySelector('#liveTag');
  const tete = root.querySelector('#liveHead');
  let arrete = false;

  const peindre = (liste) => {
    const c = liste && liste[0];
    if (!c) {
      tete?.classList.remove('is-live');
      if (titre) titre.textContent = 'Aucune livraison en cours';
      if (sous) sous.textContent = "Dès qu'une commande part, la position s'affiche ici, en direct.";
      if (tag) tag.hidden = true;
      map.clearCourier();
      lastPos = null;
      return;
    }
    tete?.classList.add('is-live');
    const age = Math.max(0, Math.round((Date.now() - c.at) / 1000));
    if (titre) titre.textContent = `${c.name} est en livraison`;
    if (sous) sous.textContent = `Position il y a ${age} s · précision ± ${Math.round(c.accuracy)} m`;
    if (tag) { tag.hidden = false; tag.textContent = c.statusLabel || 'En route'; }
    map.setCourier({ lat: c.lat, lng: c.lng, accuracy: c.accuracy, at: c.at });
    if (!lastPos) map.fit();   // on cadre une fois, ensuite la carte suit sans sauter
    lastPos = { lat: c.lat, lng: c.lng };
  };

  const tick = async () => {
    if (arrete) return;
    if (!document.hidden) {
      try { const res = await api.get('/api/couriers/live'); peindre(res.couriers); }
      catch { if (titre) titre.textContent = 'Connexion au service…'; }
    }
    if (!arrete) setTimeout(tick, 10000);
  };
  await tick();

  liveMapStop = () => { arrete = true; map.destroy(); };
}

/** Arrêt propre de la carte d'accueil (appelé à chaque changement de page). */
export function stopLiveMap() {
  liveMapStop?.();
  liveMapStop = null;
  lastPos = null;
}

/* ================================================================ MENU ===== */
export async function renderMenu(root) {
  const cfg = store.config || {};
  const open = cfg.settings?.acceptingOrders !== false;

  root.innerHTML = `
  <section class="wrap wrap-wide" style="padding-top:24px">
    <p class="eyebrow mb-1">La carte</p>
    <h2 class="mb-0">Qu'est-ce qu'on vous sert ?</h2>
    ${open ? '' : ui.banner('offline', '<strong>Service momentanément fermé.</strong> Les commandes rouvrent très vite — vous pouvez préparer votre panier.', 'alert')}
  </section>
  <div class="toolbar"><div class="cats" id="cats"></div></div>
  <section class="wrap wrap-wide pb-cart">
    <div id="menuList" class="mt-2"></div>
  </section>`;

  const listEl = root.querySelector('#menuList');
  ui.loading(listEl, 3);

  let menu;
  try {
    menu = await api.get('/api/menu');
  } catch (err) {
    listEl.innerHTML = ui.banner('error', `Carte indisponible : ${esc(err.message)}`, 'alert');
    return;
  }
  store.menu = { categories: menu.categories || [], products: menu.products || [] };
  store.emit('menu');

  let active = store.menu.categories[0]?.id || 'glaces';
  const catsEl = root.querySelector('#cats');

  const paintCats = () => {
    catsEl.innerHTML = store.menu.categories.map((c) => `
      <button class="cat ${c.id === active ? 'active' : ''}" data-cat="${c.id}">
        ${esc(c.name)}
      </button>`).join('');
  };

  const paintProducts = () => {
    const items = store.menu.products.filter((p) => p.catId === active);
    if (!items.length) { ui.empty(listEl, { title: 'Catégorie bientôt disponible', text: 'Revenez dans quelques minutes.' }); return; }
    listEl.innerHTML = `<div class="products">${items.map(productCard).join('')}</div>`;
  };

  catsEl.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-cat]');
    if (!btn) return;
    active = btn.dataset.cat;
    paintCats(); paintProducts();
  });

  listEl.addEventListener('click', (e) => {
    const step = e.target.closest('[data-step]');
    if (step) {
      const id = step.dataset.id;
      const delta = Number(step.dataset.step);
      store.addQty(id, delta);
      vibrate(delta > 0 ? 12 : 8);
      paintProducts();
      return;
    }
    const add = e.target.closest('[data-add]');
    if (add) {
      store.addQty(add.dataset.add, 1);
      vibrate(12);
      paintProducts();
    }
  });

  paintCats(); paintProducts();
  syncCartBar();

  // Le catalogue change (produit désactivé, prix modifié) sans rechargement.
  live('/api/events', {
    'menu:update': async () => {
      try {
        const fresh = await api.get('/api/menu');
        const before = JSON.stringify(store.menu.products);
        store.menu = { categories: fresh.categories || [], products: fresh.products || [] };
        store.emit('menu');
        if (JSON.stringify(store.menu.products) !== before) {
          paintProducts();
          toast('La carte vient d’être mise à jour.');
        }
      } catch { /* ignore */ }
    },
  });
}

function productCard(p) {
  const qty = store.cart.items[p.id] || 0;
  return `
  <article class="product" data-p="${p.id}">
    <div class="product-media"><img src="assets/img/prod/${esc(p.img)}" alt="" loading="lazy" decoding="async"></div>
    <div class="product-body">
      <h3 class="product-name">${esc(p.name)}</h3>
      <p class="product-desc">${esc(p.description || '')}</p>
      <div class="product-foot">
        <span class="price mono">${euro(p.price)}</span>
        ${qty > 0
          ? `<span class="stepper">
               <button type="button" data-step="-1" data-id="${p.id}" aria-label="Retirer">−</button>
               <span class="qty mono">${qty}</span>
               <button type="button" data-step="1" data-id="${p.id}" aria-label="Ajouter">+</button>
             </span>`
          : `<button class="add-btn" type="button" data-add="${p.id}" aria-label="Ajouter ${esc(p.name)}">+</button>`}
      </div>
    </div>
  </article>`;
}

/* =============================================================== PANIER ==== */
export function syncCartBar() {
  const bar = document.getElementById('cartbar');
  if (!bar) return;
  const count = store.cartCount();
  const visible = count > 0;
  bar.hidden = !visible;
  if (!visible) return;
  bar.classList.add('show');
  const c = document.getElementById('cartCount');
  const t = document.getElementById('cartTotal');
  if (c.textContent !== String(count)) { c.textContent = count; c.style.animation = 'none'; void c.offsetWidth; c.style.animation = ''; }
  t.textContent = euro(store.cartSubtotal());
}

export function openCart() {
  const lines = store.cartLines();
  if (!lines.length) { toast('Votre panier est vide.'); return; }
  const subtotal = store.cartSubtotal();

  ui.sheet.open({
    title: 'Votre panier',
    body: `
      <div id="cartLines">
        ${lines.map((l) => `
          <div class="line-item">
            <img class="thumb" src="assets/img/prod/${esc(l.product.img)}" alt="">
            <div class="grow">
              <div class="nm">${esc(l.product.name)}</div>
              <div class="pr mono">${euro(l.product.price)} × ${l.qty}</div>
            </div>
            <span class="stepper">
              <button type="button" data-step="-1" data-id="${l.product.id}" aria-label="Retirer">−</button>
              <span class="qty mono">${l.qty}</span>
              <button type="button" data-step="1" data-id="${l.product.id}" aria-label="Ajouter">+</button>
            </span>
          </div>`).join('')}
      </div>
      <div class="sum"><span>Sous-total</span><span class="mono">${euro(subtotal)}</span></div>
      <div class="sum"><span>Livraison sur la plage</span><span class="mono">Offerte</span></div>
      <div class="sum total"><span>Total</span><span class="mono">${euro(subtotal)}</span></div>
      <div class="totals-note">${ic('euro')}<div><strong>Paiement à la livraison</strong><br><span class="small">Vous réglerez directement votre commande auprès de votre livreur. Aucun paiement en ligne.</span></div></div>`,
    foot: `<button class="btn" id="goCheckout">COMMANDER — ${euro(subtotal)}</button>`,
    onMount(body, foot) {
      const repaint = () => {
        const fresh = store.cartLines();
        if (!fresh.length) { ui.sheet.close(); syncCartBar(); return; }
        openCart();
      };
      body.addEventListener('click', (e) => {
        const b = e.target.closest('[data-step]');
        if (!b) return;
        store.addQty(b.dataset.id, Number(b.dataset.step));
        syncCartBar();
        repaint();
      });
      foot.querySelector('#goCheckout').addEventListener('click', () => openCheckout());
    },
  });
}

function refreshCartSheet() { syncCartBar(); }

/* =========================================================== COMMANDE ====== */
function openCheckout() {
  const saved = LS.get(K.customer, { firstName: '', phone: '' });
  const zone = store.config?.settings?.zone;
  geoState = { pos: null, error: '', loading: false };

  ui.sheet.open({
    title: 'Finaliser la commande',
    body: `
      <p class="small muted mt-0">Trois informations, et nous partons. Aucun compte à créer.</p>
      <label class="field">
        <span class="label">Prénom</span>
        <input class="input" id="fFirstName" autocomplete="given-name" inputmode="text" placeholder="Camille" value="${esc(saved.firstName || '')}">
      </label>
      <label class="field">
        <span class="label">Téléphone</span>
        <input class="input" id="fPhone" autocomplete="tel" inputmode="tel" placeholder="06 12 34 56 78" value="${esc(saved.phone || '')}">
        <span class="hint">Pour que le livreur vous appelle en arrivant.</span>
      </label>

      <div class="field">
        <span class="label">Où devons-nous vous livrer ?</span>
        <div id="geoBox"></div>
      </div>

      <label class="field">
        <span class="label">Une indication pour vous retrouver ? <span class="muted" style="text-transform:none;letter-spacing:0">(facultatif)</span></span>
        <input class="input" id="fNote" maxlength="160" placeholder="Près du poste 1, à côté du parasol bleu…">
      </label>

      <div class="totals-note">${ic('euro')}<div><strong>PAIEMENT À LA LIVRAISON</strong><br><span class="small">Vous réglerez directement votre commande auprès de votre livreur.</span></div></div>
      <div id="checkoutErr"></div>`,
    foot: `<button class="btn" id="submitOrder">CONFIRMER LA COMMANDE — ${euro(store.cartSubtotal())}</button>`,
    onMount(body, foot) {
      const geoBox = body.querySelector('#geoBox');
      const paintGeo = () => {
        geoBox.innerHTML = geoState.pos ? geoCard(geoState.pos) : geoAsk();
        const btn = geoBox.querySelector('#askGeo');
        btn?.addEventListener('click', askGeo);
        geoBox.querySelector('#refreshGeo')?.addEventListener('click', askGeo);
      };
      const askGeo = async () => {
        // Une seule recherche à la fois : si elle est déjà en cours, on attend
        // la même (sinon le client attendrait 20 s de plus à chaque essai).
        if (geoState.promesse) return geoState.promesse;
        geoState.loading = true;
        paintGeo();
        geoState.promesse = (async () => {
        try {
          // On cherche LA MEILLEURE mesure pendant 20 s (une seule mesure est
          // souvent imprécise : plusieurs essais divisent l'erreur par 5 à 20).
          const pos = await getPosition({
            timeout: 20000,
            onProgress: (m) => {
              // On garde la meilleure mesure du moment : si le client valide
              // avant la fin de la recherche, c'est elle qui partira.
              geoState.searching = m;
              const box = document.querySelector('#geoSearch');
              if (box) box.textContent = `Recherche en cours… précision actuelle ± ${Math.round(m.accuracy)} m`;
            },
          });
          geoState.pos = pos;
          geoState.error = pos.accuracy > 80 ? 'Votre position est peu précise. Patientez quelques secondes ou ajoutez une indication.' : '';
          vibrate(14);
        } catch (err) {
          geoState.error = err.message;
        } finally {
          geoState.loading = false;
          geoState.promesse = null;
          paintGeo();
        }
        })();
        return geoState.promesse;
      };
      body._askGeo = askGeo;
      paintGeo();
      // Rien à toucher : la position est demandée dès l'ouverture du formulaire.
      askGeo();
      // …et affinée tant que la fenêtre est ouverte (une mesure GPS s'améliore
      // en quelques secondes : on garde toujours la meilleure).
      const reveil = setInterval(() => { if (!geoState.pos || geoState.pos.accuracy > 35) askGeo(); }, 12000);
      body._stopReveil = () => clearInterval(reveil);

      foot.querySelector('#submitOrder').addEventListener('click', async (ev) => {
        const btn = ev.currentTarget;
        const errBox = body.querySelector('#checkoutErr');
        errBox.innerHTML = '';
        const firstName = body.querySelector('#fFirstName').value.trim();
        const phone = body.querySelector('#fPhone').value.trim();
        const note = body.querySelector('#fNote').value.trim();

        const problems = [];
        if (firstName.length < 2) problems.push('Indiquez votre prénom.');
        if (!/^(?:\+33|0)\s*[1-9](?:[\s.\-]*\d{2}){4}$/.test(phone.replace(/\s+/g, ' '))) problems.push('Indiquez un numéro de téléphone valide (10 chiffres).');
        // Sans position : on laisse à la recherche en cours 8 secondes de plus,
        // puis on accepte la commande si une indication écrite est fournie.
        // Objectif : ne jamais perdre une commande à cause du GPS, tout en
        // donnant au livreur de quoi retrouver son client.
        if (!geoState.pos && geoState.searching) {
          // Une mesure approximative est déjà arrivée (± quelques centaines de m) :
          // on l'envoie plutôt que rien. Le livreur appellera, et le client a écrit
          // une indication. Mieux vaut un point approximatif qu'aucun.
          geoState.pos = geoState.searching;
          paintGeo();
        }
        if (!geoState.pos && firstName.length >= 2) {
          btn.innerHTML = '<span class="spin"></span> Recherche de votre position…';
          const attente = new Promise((r) => setTimeout(r, 8000));
          try { await Promise.race([askGeo(), attente]); } catch { /* message ci-dessous */ }
        }
        if (!geoState.pos && note.length < 8) {
          problems.push('Position non obtenue. Touchez « PARTAGER MA POSITION », ou écrivez une indication (par exemple « devant le poste 1, parasol bleu ») : le livreur vous appellera.');
        }
        if (problems.length) {
          errBox.innerHTML = `<div class="banner banner-error">${ic('alert')}<div>${problems.map(esc).join('<br>')}</div></div>`;
          vibrate([18, 40, 18]);
          return;
        }

        btn.disabled = true;
        btn.innerHTML = '<span class="spin"></span> Envoi…';
        try {
          const items = store.cartLines().map((l) => ({ productId: l.product.id, qty: l.qty }));
          const res = await api.post('/api/orders', {
            customer: { firstName, phone, note },
            location: geoState.pos,
            items,
          });
          LS.set(K.customer, { firstName, phone });
          myOrders.add(res.order, res.token || res.order.trackToken || '');
          store.clearCart();
          syncCartBar();
          ui.sheet.close();
          vibrate([12, 30, 12, 30, 24]);
          toast('Commande envoyée ! Un livreur arrive.', 'ok');
          navigate(`suivi?id=${encodeURIComponent(res.order.id)}&t=${encodeURIComponent(res.token || '')}`);
        } catch (err) {
          const extra = err.data?.code === 'OUT_OF_ZONE'
            ? '<br><span class="small">Vous devez être sur la plage de Cabourg, entre les postes de secours 1 et 2.</span>' : '';
          errBox.innerHTML = `<div class="banner banner-error">${ic('alert')}<div>${esc(err.message)}${extra}</div></div>`;
          btn.disabled = false;
          btn.textContent = `CONFIRMER LA COMMANDE — ${euro(store.cartSubtotal())}`;
          vibrate([18, 40, 18]);
        }
      });
    },
  });
}

function geoAsk() {
  if (geoState.loading) {
    return `<div class="card card-flat center" style="padding:22px">
      <span class="spin blue" style="margin:0 auto 12px"></span>
      <div class="small">Recherche de votre position…</div>
      <div class="small muted" id="geoSearch" style="margin-top:4px">Restez quelques secondes au même endroit, sans parasol au-dessus du téléphone.</div>
    </div>`;
  }
  return `
    <div class="card card-flat" style="padding:18px">
      <p class="small muted" style="margin-top:0">Votre position GPS permet au livreur de vous trouver directement sur le sable.</p>
      <button class="btn" type="button" id="askGeo">${ic('pin')} PARTAGER MA POSITION</button>
      ${geoState.error ? `<div class="banner banner-error mt-2">${ic('alert')}<div>${esc(geoState.error)}</div></div>` : ''}
    </div>`;
}

function geoCard(pos) {
  const acc = Math.round(pos.accuracy || 0);
  const weak = acc > 80;
  return `
    <div class="card card-flat" style="padding:18px">
      <div class="row-between">
        <span class="tag tag-solid">${ic('pin')} Position enregistrée</span>
        <button class="btn btn-xs btn-outline" type="button" id="refreshGeo">Actualiser</button>
      </div>
      <p class="small muted mt-2 mb-1 mono">${pos.lat.toFixed(5)}, ${pos.lng.toFixed(5)} — ${heureSec(pos.at)}</p>
      <p class="small ${weak ? '' : 'muted'} mb-0" ${weak ? 'style="color:#7A0016;font-weight:600"' : ''}>
        Précision : ± ${acc} m${weak ? ' — approchez-vous du bord de plage, sans parasol au-dessus du téléphone.' : ' — votre livreur vous trouvera au mètre près.'}
      </p>
      <a class="btn btn-xs btn-ghost mt-2" href="${mapsLink(pos)}" target="_blank" rel="noopener">${ic('route')} Vérifier sur la carte</a>
      <p class="small muted mb-0" style="margin-top:8px">Position refusée ou impossible à obtenir ?
        Écrivez une indication ci-dessous : votre commande sera quand même prise et le livreur vous appellera.</p>
    </div>`;
}

/* =============================================================== SUIVI ===== */
export async function renderTrack(root, params) {
  const id = params.get('id');
  const token = params.get('t');

  if (!id || !token) return renderTrackPicker(root);

  root.innerHTML = `<section class="wrap pb-cart" style="padding-top:24px"><div id="trackBox"></div></section>`;
  const box = root.querySelector('#trackBox');
  ui.loading(box, 2);

  let data;
  try {
    data = await api.get(`/api/orders/${encodeURIComponent(id)}?t=${encodeURIComponent(token)}`);
  } catch (err) {
    box.innerHTML = `
      <div class="banner banner-error">${ic('alert')}<div>${esc(err.message)}</div></div>
      <div class="mt-2"><a class="btn btn-outline" href="suivi" data-link>Voir mes commandes sur cet appareil</a></div>`;
    return;
  }

  watchedOrder = data.order;
  paintTrack(box, data.order, data.timeline, token);
  myOrders.update(id, { status: data.order.status, total: data.order.total });

  liveStop?.();
  liveStop = live(`/api/events/track?t=${encodeURIComponent(token)}`, {
    'order:update': (payload) => {
      if (payload?.order?.id !== id) return;
      watchedOrder = payload.order;
      myOrders.update(id, { status: payload.order.status });
      refreshTrackHeader(payload.order);
      // Commande livrée (ou annulée) : la course est finie, on arrête le suivi
      // GPS et on retire le livreur de la carte.
      if (['delivered', 'cancelled'].includes(payload.order.status)) {
        suiviTermine = true;
        mapCtl?.clearCourier?.();
      }
    },
    'order:eta': (payload) => { if (payload?.order?.id === id) { watchedOrder = payload.order; refreshEta(payload.order); } },
    'courier:position': (payload) => { onCourierPosition(payload); },
    'menu:update': () => { toast('La carte vient d’être mise à jour.'); },
  });
}

function renderTrackPicker(root) {
  const list = myOrders.all();
  root.innerHTML = `
    <section class="wrap" style="padding-top:26px">
      <p class="eyebrow">Suivi</p>
      <h2>Ma commande</h2>
      ${list.length ? `
        <div class="stack mt-2">
          ${list.map((o) => `
            <a class="card card-flat row-between" href="suivi?id=${encodeURIComponent(o.id)}&t=${encodeURIComponent(o.token)}" data-link style="color:inherit">
              <span>
                <span class="strong mono">${esc(o.id)}</span><br>
                <span class="small muted">${heure(o.createdAt)} · ${euro(o.total)} · ${esc(o.status || '')}</span>
              </span>
              ${ic('arrow')}
            </a>`).join('')}
        </div>` : `
        <div class="empty">${ic('route')}<h3>Aucune commande récente</h3>
        <p class="small">Vos commandes passées depuis ce téléphone apparaissent ici automatiquement.</p>
        <a class="btn mt-2" href="commander" data-link>COMMANDER</a></div>`}
      <div class="mt-3 small muted">Vous avez un numéro de commande ? Ouvrez le lien reçu à la validation de votre commande.</div>
    </section>`;
}

function paintTrack(box, order, timeline = [], token) {
  const courierPos = order.courier?.position;
  const steps = timeline.length ? timeline : ['received', 'preparing', 'ready', 'assigned', 'en_route', 'nearby', 'arrived', 'delivered'];

  box.innerHTML = `
    <div id="trackStatus">${statusHero(order)}</div>

    <div class="card mt-3" id="trackEtaWrap">${etaCard(order)}</div>

    <div class="map tall mt-3" id="trackMap">
      <div class="map-legend">
        <div><i class="dot-client"></i>Vous</div>
        ${order.courier ? '<div><i class="dot-courier"></i>Votre livreur</div>' : ''}
      </div>
    </div>

    <div class="card mt-3">
      <div class="card-head"><h3>Suivi de la livraison</h3><span class="small muted">${esc(order.id)}</span></div>
      <ul class="timeline" id="trackTimeline">
        ${timelineHtml(order, visibleSteps(order, steps))}
      </ul>
    </div>

    <div class="card mt-3" id="trackPayment">${paymentCard(order)}</div>

    ${order.courier ? courierCard(order) : ''}

    <div class="card mt-3">
      <div class="card-head"><h3>Ma position</h3></div>
      <p class="small muted" style="margin-top:0">Position transmise le ${heureSec(order.location?.at)} (précision ± ${Math.round(order.location?.accuracy || 0)} m).</p>
      ${order.note ? `<p class="small mb-1"><strong>Indication :</strong> ${esc(order.note)}</p>` : ''}
      <div class="btn-row mt-2">
        <button class="btn btn-outline btn-sm" id="reGeo">${ic('refresh')} Actualiser ma position</button>
        <a class="btn btn-outline btn-sm" href="${order.location ? mapsLink(order.location) : '#'}" target="_blank" rel="noopener">${ic('route')} Ouvrir la carte</a>
      </div>
      <div id="reGeoMsg" class="mt-2"></div>
    </div>

    <div class="btn-row mt-3">
      <a class="btn btn-outline" href="commander" data-link>Commander encore</a>
      <a class="btn btn-ghost" href="suivi" data-link>Mes commandes</a>
    </div>
    <div class="small muted center mt-3">Cette page se met à jour toute seule. Aucun besoin de recharger.</div>`;

  // --- carte réelle
  const mapEl = box.querySelector('#trackMap');
  mapCtl?.destroy();
  mapCtl = createMap(mapEl, {
    center: order.location || store.config?.settings?.zone || { lat: 49.2915, lng: -0.1212 },
    zoom: 17,
    zone: store.config?.settings?.zone,
  });
  if (order.location) mapCtl.setClient(order.location);
  if (courierPos) mapCtl.setCourier(courierPos, { animate: false });
  mapCtl.fit();

  box.querySelector('#reGeo').addEventListener('click', async (ev) => {
    const btn = ev.currentTarget;
    const msg = box.querySelector('#reGeoMsg');
    btn.disabled = true;
    msg.innerHTML = '<div class="small muted">Recherche de votre position…</div>';
    try {
      const pos = await getPosition();
      const res = await api.post(`/api/orders/${encodeURIComponent(order.id)}/location?t=${encodeURIComponent(token)}`, pos);
      watchedOrder = { ...watchedOrder, location: res.order?.location || pos };
      msg.innerHTML = `<div class="small" style="color:var(--blue);font-weight:700">Position actualisée à ${heureSec(pos.at)} (± ${Math.round(pos.accuracy)} m).</div>`;
      mapCtl?.setClient(pos);
    } catch (err) {
      msg.innerHTML = `<div class="small" style="color:#8A0018;font-weight:600">${esc(err.message)}</div>`;
    } finally {
      btn.disabled = false;
    }
  });
}


/** Construit la liste d'étapes à afficher : uniquement celles réellement
 *  franchies, plus l'étape en cours et la suivante (jamais d'étape inventée). */
function visibleSteps(order, steps) {
  const history = order.history || [];
  const done = new Set(history.map((h) => h.status));
  done.add(order.status);
  const idx = steps.indexOf(order.status);
  if (idx >= 0 && steps[idx + 1]) done.add(steps[idx + 1]);
  return steps.filter((s) => done.has(s));
}

function timelineHtml(order, steps) {
  const history = order.history || [];
  return steps.map((s) => {
    const when = history.find((h) => h.status === s)?.at;
    const cls = when ? 'done' : s === order.status ? 'done now' : '';
    return `<li class="${cls}">
      <span class="dot">${ic('check')}</span>
      <span class="txt">${esc(STATUS_TEXT[s] || s)}${when ? `<span class="when">${heure(when)}</span>` : ''}</span>
    </li>`;
  }).join('');
}

const STATUS_TEXT = {
  received: 'Commande reçue',
  preparing: 'Préparation',
  ready: 'Prête',
  assigned: 'Livreur assigné',
  en_route: 'Livreur en route',
  nearby: 'Livreur proche',
  arrived: 'Livreur arrivé',
  delivered: 'Livrée',
  cancelled: 'Annulée',
};

function statusHero(order) {
  const done = order.status === 'delivered';
  const big = {
    received: 'Commande reçue',
    preparing: 'Nous préparons votre commande',
    ready: 'Votre commande est prête',
    assigned: order.awaitingCourier ? 'Recherche d’un livreur…' : 'Un livreur s’occupe de vous',
    en_route: 'Votre commande est en route',
    nearby: 'Votre livreur approche',
    arrived: 'Votre livreur est arrivé',
    delivered: 'Livrée — merci !',
    cancelled: 'Commande annulée',
  }[order.status] || 'Commande en cours';
  const sub = {
    received: 'Nous avons bien reçu votre commande.',
    preparing: 'Encore quelques instants, tout est prêt très vite.',
    ready: 'Elle part vers vous dans un instant.',
    assigned: order.awaitingCourier ? 'Nous cherchons le livreur le plus proche de vous.' : `${esc(order.courier?.name || 'Votre livreur')} prend votre commande en charge.`,
    en_route: 'Suivez son déplacement sur la carte ci-dessous.',
    nearby: 'Restez attentif, il ne devrait plus tarder.',
    arrived: 'Il vous cherche sur la plage — vous pouvez l’appeler.',
    delivered: 'Nous espérons que tout était à votre goût. Bonne journée sur la plage !',
    cancelled: 'Contactez-nous si besoin.',
  }[order.status] || '';

  return `
    <div class="status-hero">
      <div class="order-no">Commande ${esc(order.id)}</div>
      <h2>${esc(big)}</h2>
      <p class="small" style="color:rgba(255,255,255,.86);margin:0">${sub}</p>
      ${done ? '' : `<div class="pulse mt-2"><i></i> Suivi en direct · ${heureSec(Date.now())}</div>`}
    </div>`;
}

function etaCard(order) {
  if (order.status === 'delivered') {
    return `<div class="row-between"><span class="tag tag-solid">${ic('check')} Livrée</span><span class="small muted">${heure(order.deliveredAt)}</span></div>`;
  }
  if (!order.courier) {
    return `<div class="row-between"><span class="tag tag-warn">${ic('clock')} En attente d'un livreur</span><span class="small muted">Commande ${esc(order.id)}</span></div>`;
  }
  const eta = order.eta;
  return `
    <div class="row-between">
      <div>
        <div class="small muted">Arrivée estimée</div>
        <div class="strong" style="font-size:1.5rem">${eta ? `${eta.minutes} min` : '—'}</div>
        <div class="small muted">${eta ? `à environ ${distanceLabel(eta.distance)} de vous` : 'Position du livreur en cours d’acquisition'}</div>
      </div>
      <span class="eta-badge">${ic('truck')} ${esc(STATUS_TEXT[order.status] || '')}</span>
    </div>`;
}

function paymentCard(order) {
  const paid = order.paymentStatus === 'paid';
  return `
    <div class="card-head"><h3>Paiement</h3>
      <span class="tag ${paid ? 'tag-solid' : 'tag-warn'}" id="payTag">${paid ? 'Payé' : 'À régler'}</span>
    </div>
    <div class="sum"><span>${(order.items || []).length} article(s)</span><span class="mono">${euro(order.subtotal)}</span></div>
    <div class="sum"><span>Livraison sur la plage</span><span class="mono">Offerte</span></div>
    <div class="sum total"><span>Total</span><span class="mono">${euro(order.total)}</span></div>
    <div class="totals-note">${ic('euro')}<div><strong>PAIEMENT À LA LIVRAISON</strong><br><span class="small">${paid
      ? 'Paiement réglé auprès de votre livreur. Merci !'
      : 'Vous réglerez directement votre commande auprès de votre livreur.'}</span></div></div>`;
}

function courierCard(order) {
  const c = order.courier;
  const fresh = c.position && Date.now() - (c.position.at || 0) < 1000 * 60 * 3;
  return `
    <div class="card mt-3" id="courierCard">
      <div class="card-head"><h3>Votre livreur</h3>
        <span class="small ${fresh ? '' : 'muted'}" ${fresh ? 'style="color:var(--blue);font-weight:700"' : ''}>
          ${fresh ? 'Position à jour' : 'Dernière position connue'}
        </span>
      </div>
      <div class="row">
        <span class="count" style="width:48px;height:48px;border-radius:50%;background:var(--blue);color:#fff;display:grid;place-items:center;font-weight:800;font-size:1.1rem">${esc((c.name || '?')[0].toUpperCase())}</span>
        <div class="grow">
          <div class="strong">${esc(c.name)}</div>
          <div class="small muted">Livreur PannacottaClub · position mise à jour ${c.position ? heureSec(c.position.at) : '—'}</div>
        </div>
      </div>
      ${c.phone ? `<a class="btn btn-outline mt-2" href="tel:${esc(c.phone.replace(/\s/g, ''))}">${ic('phone')} Appeler mon livreur</a>` : ''}
      <div class="small muted mt-2" id="distLine">${order.location && c.position ? `Distance : ${routeText(c.position, order.location)}` : 'En attente de la position du livreur…'}</div>
    </div>`;
}

function refreshTrackHeader(order) {
  const wrap = document.getElementById('trackStatus');
  if (wrap) wrap.innerHTML = statusHero(order);
  const eta = document.getElementById('trackEtaWrap');
  if (eta) eta.innerHTML = etaCard(order);

  const tl = document.getElementById('trackTimeline');
  if (tl) {
    const steps = order.timeline || Object.keys(STATUS_TEXT).slice(0, 8);
    tl.innerHTML = timelineHtml(order, visibleSteps(order, steps));
  }
  const pay = document.getElementById('trackPayment');
  if (pay) pay.innerHTML = paymentCard(order);
  const cc = document.getElementById('courierCard');
  if (cc && order.courier) cc.outerHTML = courierCard(order);
  if (order.courier?.position && mapCtl) {
    mapCtl.setCourier(order.courier.position, { id: order.courier.id || 'defaut', nom: order.courier.name || '', animate: false });
  }
  if (order.courier?.position) vibrate(10);
}

function refreshEta(order) {
  const eta = document.getElementById('trackEtaWrap');
  if (eta) eta.innerHTML = etaCard(order);
}

function onCourierPosition(payload) {
  if (!watchedOrder || !mapCtl || suiviTermine) return;
  const tracking = payload.orderIds?.includes(watchedOrder.id);
  if (!tracking) return;
  mapCtl.setCourier(payload, { id: payload.courierId || watchedOrder?.courier?.id || 'defaut', nom: watchedOrder?.courier?.name || '' });
  const line = document.getElementById('distLine');
  if (line && watchedOrder.location) line.textContent = `Distance : ${routeText(payload, watchedOrder.location)}`;
}

/* Rafraîchissement de l'horloge du suivi */
setInterval(() => {
  const pulse = document.querySelector('.status-hero .pulse');
  if (pulse) pulse.innerHTML = `<i></i> Suivi en direct · ${heureSec(Date.now())}`;
}, 1000);

store.on((type) => { if (type === 'cart') syncCartBar(); });
window.addEventListener('pc:cart', syncCartBar);
document.addEventListener('visibilitychange', refreshCartSheet);
