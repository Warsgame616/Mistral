/* ==========================================================================
   PANNACOTTACLUB — espace administrateur
   Produits (prix, ajout, retrait) · Commandes · Livreurs · Carte · QR codes
   ========================================================================== */
import {
  api, store, euro, heure, heureSec, esc, ic, toast, ui, navigate,
  live, LS, K, distanceLabel, rememberEmail, lastEmail,
} from '../core.js';
import { createMap, mapsLink } from '../map.js';

let liveStop = null;
let mapCtl = null;
let state = null;
let tab = 'orders';

const TABS = [
  { id: 'orders', label: 'Commandes' },
  { id: 'map', label: 'Carte' },
  { id: 'products', label: 'Produits & prix' },
  { id: 'couriers', label: 'Livreurs' },
  { id: 'qr', label: 'Panneaux QR' },
  { id: 'settings', label: 'Réglages' },
];

/* ============================================================== CONNEXION == */
export async function renderAdmin(root) {
  api.token = (LS.get(K.tokens, {}).admin) || null;

  // Le cookie de session du serveur fait foi : on vérifie toujours.
  {
    try {
      const me = await api.get('/api/auth/me');
      if (me.user.role === 'admin') { store.session = me.user; return renderBoard(root); }
    } catch { /* ignore */ }
  }
  renderLogin(root);
  return undefined;
}

function renderLogin(root, message = '') {
  api.token = null;
  const savedEmail = lastEmail() || 'admin@pannacottaclub.fr';
  root.innerHTML = `
  <div class="auth-shell">
    <div class="auth-card fade-in">
      <img class="brand-logo" src="assets/img/logo.png" alt="PANNACOTTACLUB">
      <h2 class="center" style="margin-bottom:4px">Administration</h2>
      <p class="center small muted">Produits, commandes, livreurs et zone de livraison.</p>
      ${message ? `<div class="banner banner-error mb-2">${ic('alert')}<div>${esc(message)}</div></div>` : ''}
      <form id="adminLogin" novalidate>
        <label class="field">
          <span class="label">Email</span>
          <input class="input" type="email" id="aEmail" autocomplete="username" value="${esc(savedEmail)}">
        </label>
        <label class="field">
          <span class="label">Mot de passe</span>
          <input class="input" type="password" id="aPass" autocomplete="current-password" placeholder="••••••••">
        </label>
        <div id="adminErr"></div>
        <button class="btn btn-block mt-2" type="submit" id="aSubmit">${ic('lock')} SE CONNECTER</button>
        <label class="switch mt-2"><input type="checkbox" id="aRemember" checked><span class="track"></span><span class="small strong">Rester connecté</span></label>
      </form>
    </div>
  </div>`;

  root.querySelector('#adminLogin').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = root.querySelector('#aSubmit');
    const err = root.querySelector('#adminErr');
    err.innerHTML = '';
    btn.disabled = true;
    btn.innerHTML = '<span class="spin"></span> Connexion…';
    try {
      const adminEmail = root.querySelector('#aEmail').value.trim();
      const res = await api.post('/api/auth/login', {
        role: 'admin',
        identifier: adminEmail,
        password: root.querySelector('#aPass').value,
        remember: root.querySelector('#aRemember').checked,
      });
      const tokens = LS.get(K.tokens, {});
      tokens.admin = res.token;
      LS.set(K.tokens, tokens);
      rememberEmail(adminEmail);
      api.token = res.token;
      store.session = res.user;
      renderBoard(root);
    } catch (e2) {
      err.innerHTML = `<div class="banner banner-error mb-2">${ic('alert')}<div>${esc(e2.message)}</div></div>`;
      btn.disabled = false;
      btn.innerHTML = `${ic('lock')} SE CONNECTER`;
    }
  });
}

/* ========================================================== TABLEAU DE BORD = */
async function renderBoard(root) {
  root.innerHTML = `
    <section class="wrap wrap-wide" style="padding-top:18px">
      <div class="row-between">
        <div>
          <div class="eyebrow mb-1">Administration</div>
          <h2 class="mb-0">PannacottaClub · Cabourg</h2>
        </div>
        <button class="btn btn-sm btn-ghost" id="adminLogout">${ic('logout')} Quitter</button>
      </div>
      <div class="grid-3 mt-3" id="adminStats"></div>
      <div class="tabs mt-3" id="adminTabs">
        ${TABS.map((t) => `<button class="tab ${t.id === tab ? 'active' : ''}" data-tab="${t.id}">${esc(t.label)}</button>`).join('')}
      </div>
      <div id="adminPanel" class="mt-3" style="padding-bottom:60px"></div>
    </section>`;

  root.querySelector('#adminLogout').addEventListener('click', logout);
  root.querySelector('#adminTabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    tab = b.dataset.tab;
    root.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
    paintPanel(root);
  });

  await refresh(root);

  liveStop?.();
  liveStop = live(`/api/events/admin?token=${encodeURIComponent(api.token || '')}`, {
    'order:new': () => { toast('Nouvelle commande reçue.', 'ok'); refresh(root, { silent: true }); },
    'order:update': () => refresh(root, { silent: true }),
    'courier:position': (p) => onCourierPosition(root, p),
    'courier:update': () => refresh(root, { silent: true }),
    'couriers:update': () => refresh(root, { silent: true }),
    'menu:update': () => refresh(root, { silent: true }),
    'settings:update': () => refresh(root, { silent: true }),
  });
}

async function logout() {
  try { await api.post('/api/auth/logout'); } catch { /* ignore */ }
  const tokens = LS.get(K.tokens, {});
  delete tokens.admin;
  LS.set(K.tokens, tokens);
  liveStop?.();
  mapCtl?.destroy();
  navigate('admin');
}

async function refresh(root, { silent = false } = {}) {
  try {
    state = await api.get('/api/admin/state');
  } catch (err) {
    if (err.status === 401) { renderLogin(root, 'Reconnectez-vous : vos commandes et vos réglages sont intacts.'); return; }
    if (!silent) toast(err.message, 'err');
    return;
  }
  paintStats(root);
  paintPanel(root);
}

function paintStats(root) {
  const s = state.stats;
  const el = root.querySelector('#adminStats');
  if (!el) return;
  el.innerHTML = `
    <div class="stat"><div class="k">Commandes aujourd'hui</div><div class="v">${s.ordersToday}</div><div class="small muted">${s.active} en cours · ${s.unassigned} sans livreur</div></div>
    <div class="stat"><div class="k">Chiffre du jour</div><div class="v mono">${euro(s.revenueToday)}</div><div class="small muted">${s.unpaid} paiement(s) à régulariser</div></div>
    <div class="stat"><div class="k">Livreurs</div><div class="v">${s.onlineCouriers}<span class="small muted">/${state.couriers.length}</span></div><div class="small muted">en service maintenant</div></div>`;
}

function paintPanel(root) {
  const el = root.querySelector('#adminPanel');
  if (!el || !state) return;
  if (tab === 'orders') paintOrders(root, el);
  else if (tab === 'map') paintMap(root, el);
  else if (tab === 'products') paintProducts(root, el);
  else if (tab === 'couriers') paintCouriers(root, el);
  else if (tab === 'qr') paintQr(root, el);
  else paintSettings(root, el);
}

/* =============================================================== COMMANDES = */
function paintOrders(root, el) {
  const active = state.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status));
  const past = state.orders.filter((o) => ['delivered', 'cancelled'].includes(o.status)).slice(0, 30);

  el.innerHTML = `
    <div class="row-between mb-2">
      <h3 class="mb-0">Commandes en cours (${active.length})</h3>
      <button class="btn btn-xs btn-outline" id="demoOrder">${ic('plus')} Commande test</button>
    </div>
    ${active.length ? active.map((o) => adminOrderCard(o)).join('') : '<div class="card"><p class="small muted mb-0">Aucune commande en cours.</p></div>'}
    <h3 class="mt-3">Historique (${past.length})</h3>
    ${past.length ? past.map((o) => adminOrderCard(o, true)).join('') : '<div class="card"><p class="small muted mb-0">Aucune commande terminée.</p></div>'}`;

  el.querySelector('#demoOrder').addEventListener('click', async (e) => {
    e.currentTarget.disabled = true;
    try {
      const res = await api.post('/api/admin/demo/order');
      toast(`Commande test ${res.order.id} créée.`, 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  });

  el.querySelectorAll('[data-oact]').forEach((btn) => {
    const evt = btn.tagName === 'SELECT' ? 'change' : 'click';
    btn.addEventListener(evt, async () => {
      const { oact, id } = btn.dataset;
      btn.disabled = true;
      try {
        if (oact === 'courier') {
          await api.put(`/api/admin/orders/${encodeURIComponent(id)}`, { courierId: btn.value || null });
          toast(btn.value ? 'Livreur assigné.' : 'Commande remise sans livreur.', 'ok');
        } else if (oact === 'paid') {
          await api.put(`/api/admin/orders/${encodeURIComponent(id)}`, { paymentStatus: 'paid' });
          toast('Paiement marqué encaissé.', 'ok');
        } else if (oact === 'cancel') {
          if (!confirm(`Annuler la commande ${id} ?`)) { btn.disabled = false; return; }
          await api.put(`/api/admin/orders/${encodeURIComponent(id)}`, { status: 'cancelled' });
          toast('Commande annulée.');
        }
        await refresh(root, { silent: true });
      } catch (err) { toast(err.message, 'err'); btn.disabled = false; }
    });
  });
}

function adminOrderCard(o, compact = false) {
  return `
  <article class="admin-order mb-2">
    <header>
      <div>
        <div class="ono">${esc(o.id)}</div>
        <div class="meta">${heure(o.createdAt)} · ${esc(o.customer.firstName)} · ${esc(o.customer.phone)}</div>
      </div>
      <div class="center">
        <span class="pill ${o.status === 'delivered' ? 'grey' : o.status === 'cancelled' ? 'warn' : 'ok'}">${esc(o.statusLabel)}</span>
        <div class="small muted mt-1">${o.paymentStatus === 'paid' ? 'Payé' : 'À encaisser'}</div>
      </div>
    </header>
    <div class="small">
      <strong>${esc(o.courierName || 'Aucun livreur')}</strong>
      ${o.eta ? ` · ${o.eta.minutes} min · ${distanceLabel(o.eta.distance)}` : ''}
      ${o.outOfZone ? ' · <span style="color:#8A0018;font-weight:700">hors zone</span>' : ''}
    </div>
    <ul>${o.items.map((i) => `<li>${i.qty} × ${esc(i.name)} — ${euro(i.price * i.qty)}</li>`).join('')}</ul>
    <div class="row-between">
      <span class="small muted">${o.customer.note ? `Repère : ${esc(o.customer.note)}` : ''}</span>
      <strong class="mono">${euro(o.total)}</strong>
    </div>
    ${compact ? `
      <div class="acts">
        ${o.paymentStatus !== 'paid' && o.status === 'delivered' ? `<button class="btn btn-xs btn-outline" data-oact="paid" data-id="${o.id}">Marquer payé</button>` : ''}
        ${o.location ? `<a class="btn btn-xs btn-ghost" target="_blank" rel="noopener" href="${mapsLink(o.location)}">Position</a>` : ''}
      </div>` : `
      <div class="acts">
        <select class="select" style="min-height:38px;padding:6px 10px;width:auto" data-oact="courier" data-id="${o.id}">
          <option value="">Assigner un livreur…</option>
          ${state.couriers.filter((c) => c.active).map((c) => `<option value="${c.id}" ${o.courierId === c.id ? 'selected' : ''}>${esc(c.name)}${c.online ? ' (en service)' : ''}</option>`).join('')}
        </select>
        <button class="btn btn-xs btn-outline" data-oact="paid" data-id="${o.id}">${ic('euro')} Payé</button>
        ${o.location ? `<a class="btn btn-xs btn-ghost" target="_blank" rel="noopener" href="${mapsLink(o.location)}">${ic('pin')} Voir position</a>` : ''}
        <button class="btn btn-xs btn-danger" data-oact="cancel" data-id="${o.id}">Annuler</button>
      </div>`}
  </article>`;
}

/* ==================================================================== CARTE = */
function paintMap(root, el) {
  el.innerHTML = `
    <div class="row-between mb-2">
      <h3 class="mb-0">Carte générale</h3>
      <span class="small muted" id="mapLiveCount">${state.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status)).length} commande(s) active(s) · ${state.couriers.filter((c) => c.online).length} livreur(s) en service</span>
    </div>
    <div class="map tall" id="adminMap" style="height:520px"></div>
    <div class="grid-2 mt-2">
      <div class="card">
        <div class="card-head"><h3>Commandes actives</h3></div>
        <div id="adminMapList"></div>
      </div>
      <div class="card">
        <div class="card-head"><h3>Livreurs</h3></div>
        <div id="adminCourierList"></div>
      </div>
    </div>`;

  const mapEl = el.querySelector('#adminMap');
  const reuse = mapCtl && mapCtl.el === mapEl;
  if (!reuse) {
    mapCtl?.destroy();
    mapCtl = createMap(mapEl, { center: state.settings.zone, zoom: 15, zone: state.settings.zone });
  }

  const active = state.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status) && o.location);
  const doneIds = new Set();
  for (const o of active) {
    if (doneIds.has(o.id)) continue;
    doneIds.add(o.id);
    mapCtl.setClient(o.location);
  }
  for (const c of state.couriers) {
    if (c.lastPos) mapCtl.setCourier({ ...c.lastPos, id: c.id, nom: c.name }, { id: c.id, nom: c.name, animate: false });
  }
  if (!reuse) { mapCtl.fit(); mapCtl.invalidate(); }

  el.querySelector('#adminMapList').innerHTML = active.length
    ? active.map((o) => `
      <div class="line-item">
        <div class="grow">
          <div class="nm">${esc(o.id)} · ${esc(o.customer.firstName)}</div>
          <div class="pr">${esc(o.statusLabel)}${o.courierName ? ` · ${esc(o.courierName)}` : ' · sans livreur'} · ${euro(o.total)}</div>
        </div>
        ${o.location ? `<a class="btn btn-xs btn-ghost" href="${mapsLink(o.location)}" target="_blank" rel="noopener">Ouvrir</a>` : ''}
      </div>`).join('')
    : '<p class="small muted mb-0">Aucune commande active.</p>';

  el.querySelector('#adminCourierList').innerHTML = state.couriers.length
    ? state.couriers.map((c) => `
      <div class="line-item">
        <div class="grow">
          <div class="nm">${esc(c.name)} ${c.online ? '<span class="pill ok">en service</span>' : '<span class="pill grey">hors service</span>'}</div>
          <div class="pr">${c.activeOrders} en cours · ${c.delivered} livrées${c.lastPos ? ` · position ${heureSec(c.lastPos.at)}` : ' · position inconnue'}</div>
        </div>
        ${c.lastPos ? `<a class="btn btn-xs btn-ghost" href="${mapsLink(c.lastPos)}" target="_blank" rel="noopener">${ic('pin')}</a>` : ''}
      </div>`).join('')
    : '<p class="small muted mb-0">Aucun livreur enregistré.</p>';
}

function onCourierPosition(root, p) {
  if (tab === 'map' && mapCtl) mapCtl.setCourier(p, { id: p.courierId || p.id || 'defaut', nom: p.courierName || p.name || '' });
  const el = root.querySelector('#mapLiveCount');
  if (el) el.textContent = `${state?.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status)).length || 0} commande(s) active(s) · position livreur ${heureSec(p.at)}`;
}

/* ================================================================= PRODUITS = */
function paintProducts(root, el) {
  const cats = state.categories;
  const byCat = (id) => state.products.filter((p) => p.catId === id);

  el.innerHTML = `
    <div class="row-between mb-2">
      <div>
        <h3 class="mb-0">Produits, prix & disponibilité</h3>
        <p class="small muted mb-0">Modifiez un prix, retirez un article de la vente ou ajoutez-en un nouveau. Les clients voient la mise à jour immédiatement.</p>
      </div>
      <button class="btn btn-sm" id="newProduct">${ic('plus')} Ajouter un article</button>
    </div>

    ${cats.map((c) => `
      <h4 class="mt-3">${esc(c.name)} <span class="small muted">(${byCat(c.id).length})</span></h4>
      <div class="only-mobile">${byCat(c.id).map(productCardAdmin).join('')}</div>
      <div class="only-desktop table-wrap">
        <table>
          <thead><tr><th>Article</th><th>Description</th><th>Prix</th><th>État</th><th style="text-align:right">Actions</th></tr></thead>
          <tbody>
            ${byCat(c.id).map((p) => `
              <tr data-p="${p.id}">
                <td>
                  <div class="row">
                    <img src="assets/img/prod/${esc(p.img)}" alt="" style="width:38px;height:38px;border-radius:8px;background:var(--blue-050);padding:3px">
                    <strong>${esc(p.name)}</strong>
                  </div>
                </td>
                <td class="small muted">${esc(p.description || '—')}</td>
                <td>
                  <div class="row" style="gap:6px">
                    <input class="input mono" type="number" step="0.5" min="0" style="width:96px;min-height:40px;padding:6px 10px" value="${(p.price / 100).toFixed(2)}" data-price="${p.id}" aria-label="Prix de ${esc(p.name)}">
                    <span class="small muted">€</span>
                  </div>
                </td>
                <td><span class="pill ${p.available ? 'ok' : 'grey'}">${p.available ? 'En vente' : 'Retiré'}</span></td>
                <td style="text-align:right;white-space:nowrap">
                  <button class="btn btn-xs btn-outline" data-toggle="${p.id}">${p.available ? 'Retirer' : 'Remettre en vente'}</button>
                  <button class="btn btn-xs btn-outline" data-edit="${p.id}">${ic('edit')}</button>
                  <button class="btn btn-xs btn-danger" data-del="${p.id}">${ic('trash')}</button>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`).join('')}`;

  el.querySelector('#newProduct').addEventListener('click', () => productSheet(root, null));
  el.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => productSheet(root, state.products.find((p) => p.id === b.dataset.edit))));
  el.querySelectorAll('[data-toggle]').forEach((b) => b.addEventListener('click', async () => {
    const p = state.products.find((x) => x.id === b.dataset.toggle);
    try {
      await api.put(`/api/admin/products/${encodeURIComponent(p.id)}`, { available: !p.available });
      toast(p.available ? `${p.name} retiré de la vente.` : `${p.name} remis en vente.`, 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  }));
  el.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
    const p = state.products.find((x) => x.id === b.dataset.del);
    if (!confirm(`Supprimer définitivement « ${p.name} » ?\n\nPour le retirer temporairement, utilisez plutôt « Retirer ».`)) return;
    try {
      await api.del(`/api/admin/products/${encodeURIComponent(p.id)}`);
      toast('Article supprimé.');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  }));
  // prix : validation à la sortie du champ
  el.querySelectorAll('[data-price]').forEach((input) => {
    const save = async () => {
      const p = state.products.find((x) => x.id === input.dataset.price);
      const cents = Math.round(Number(String(input.value).replace(',', '.')) * 100);
      if (!Number.isFinite(cents) || cents < 0) { input.value = (p.price / 100).toFixed(2); toast('Prix invalide.', 'err'); return; }
      if (cents === p.price) return;
      try {
        await api.put(`/api/admin/products/${encodeURIComponent(p.id)}`, { price: cents });
        p.price = cents;
        toast(`${p.name} : ${euro(cents)}`, 'ok');
      } catch (err) { toast(err.message, 'err'); input.value = (p.price / 100).toFixed(2); }
    };
    input.addEventListener('change', save);
    input.addEventListener('blur', save);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } });
  });
}

function productSheet(root, product) {
  const isNew = !product;
  ui.sheet.open({
    title: isNew ? 'Nouvel article' : `Modifier ${product.name}`,
    body: `
      <label class="field"><span class="label">Nom</span>
        <input class="input" id="pName" value="${esc(product?.name || '')}" placeholder="Glace pistache"></label>
      <label class="field"><span class="label">Description courte</span>
        <input class="input" id="pDesc" maxlength="120" value="${esc(product?.description || '')}" placeholder="Crème glacée pistache de Sicile"></label>
      <div class="row" style="gap:12px;align-items:flex-start">
        <label class="field grow"><span class="label">Prix (€)</span>
          <input class="input mono" id="pPrice" type="number" step="0.5" min="0" value="${((product?.price ?? 350) / 100).toFixed(2)}"></label>
        <label class="field grow"><span class="label">Catégorie</span>
          <select class="select" id="pCat">
            ${state.categories.map((c) => `<option value="${c.id}" ${product?.catId === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
          </select></label>
      </div>
      <label class="field"><span class="label">Illustration</span>
        <select class="select" id="pImg">
          ${IMG_CHOICES.map((i) => `<option value="${i}" ${product?.img === i ? 'selected' : ''}>${i.replace('.svg', '')}</option>`).join('')}
        </select>
        <span class="hint">Choisissez l’illustration la plus proche du produit.</span></label>
      <label class="switch"><input type="checkbox" id="pAvail" ${product?.available !== false ? 'checked' : ''}><span class="track"></span><span class="strong">Proposé à la vente</span></label>
      <div id="pErr" class="mt-2"></div>`,
    foot: `<button class="btn" id="pSave">${isNew ? 'AJOUTER L’ARTICLE' : 'ENREGISTRER'}</button>`,
    onMount(body, foot) {
      foot.querySelector('#pSave').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        const errBox = body.querySelector('#pErr');
        const payload = {
          name: body.querySelector('#pName').value.trim(),
          description: body.querySelector('#pDesc').value.trim(),
          price: Math.round(Number(String(body.querySelector('#pPrice').value).replace(',', '.')) * 100),
          catId: body.querySelector('#pCat').value,
          img: body.querySelector('#pImg').value,
          available: body.querySelector('#pAvail').checked,
        };
        if (payload.name.length < 2) { errBox.innerHTML = '<div class="banner banner-error">Nom trop court.</div>'; return; }
        if (!Number.isFinite(payload.price) || payload.price < 0) { errBox.innerHTML = '<div class="banner banner-error">Prix invalide.</div>'; return; }
        btn.disabled = true;
        btn.innerHTML = '<span class="spin"></span>';
        try {
          if (isNew) await api.post('/api/admin/products', payload);
          else await api.put(`/api/admin/products/${encodeURIComponent(product.id)}`, payload);
          toast(isNew ? 'Article ajouté.' : 'Article enregistré.', 'ok');
          ui.sheet.close();
          await refresh(root, { silent: true });
        } catch (err) {
          errBox.innerHTML = `<div class="banner banner-error">${esc(err.message)}</div>`;
          btn.disabled = false;
          btn.textContent = isNew ? 'AJOUTER L’ARTICLE' : 'ENREGISTRER';
        }
      });
    },
  });
}

function productCardAdmin(p) {
  return `
  <article class="prod-card">
    <div class="top">
      <img src="assets/img/prod/${esc(p.img)}" alt="">
      <div class="grow">
        <div class="nm">${esc(p.name)}</div>
        <div class="ds">${esc(p.description || '—')}</div>
      </div>
      <span class="pill ${p.available ? 'ok' : 'grey'}">${p.available ? 'En vente' : 'Retiré'}</span>
    </div>
    <div class="price-row">
      <span class="label" style="margin:0">Prix</span>
      <input class="input mono" type="number" step="0.5" min="0" value="${(p.price / 100).toFixed(2)}" data-price="${p.id}" aria-label="Prix de ${esc(p.name)}">
      <span class="strong">€</span>
    </div>
    <div class="acts">
      <button class="btn btn-sm btn-outline" data-toggle="${p.id}">${p.available ? 'Retirer de la vente' : 'Remettre en vente'}</button>
      <button class="btn btn-sm btn-outline" data-edit="${p.id}">${ic('edit')} Modifier</button>
      <button class="btn btn-sm btn-danger" data-del="${p.id}">${ic('trash')}</button>
    </div>
  </article>`;
}

const IMG_CHOICES = [
  'glace-corne.svg', 'glace-pot.svg', 'coupe.svg', 'batonnet.svg',
  'eau.svg', 'soda.svg', 'limonade.svg', 'jus.svg', 'biere.svg', 'cafe.svg',
  'salade.svg', 'panini.svg', 'frites.svg', 'crepe.svg', 'cookie.svg', 'fruits.svg',
];

/* ================================================================= LIVREURS = */
function paintCouriers(root, el) {
  el.innerHTML = `
    <div class="row-between mb-2">
      <div>
        <h3 class="mb-0">Équipe de livraison</h3>
        <p class="small muted mb-0">Ajoutez les livreurs, activez-les ou désactivez-les. Chacun se connecte avec son propre compte.</p>
      </div>
      <button class="btn btn-sm" id="newCourier">${ic('plus')} Ajouter un livreur</button>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Livreur</th><th>Contact</th><th>État</th><th>Activité</th><th style="text-align:right">Actions</th></tr></thead>
        <tbody>
          ${state.couriers.map((c) => `
            <tr>
              <td><strong>${esc(c.name)}</strong><br><span class="small muted">${esc(c.email)}</span></td>
              <td class="small">${esc(c.phone || '—')}<br><span class="small muted">${c.lastPos ? `position ${heureSec(c.lastPos.at)}` : 'position inconnue'}</span></td>
              <td>
                <span class="pill ${c.online ? 'ok' : 'grey'}">${c.online ? 'En service' : 'Hors service'}</span>
                ${c.active ? '' : '<span class="pill warn">désactivé</span>'}
              </td>
              <td class="small">${c.activeOrders} en cours<br><span class="muted">${c.delivered} livrées</span></td>
              <td style="text-align:right;white-space:nowrap">
                <button class="btn btn-xs btn-outline" data-cedit="${c.id}">${ic('edit')}</button>
                ${c.lastPos ? `<a class="btn btn-xs btn-ghost" target="_blank" rel="noopener" href="${mapsLink(c.lastPos)}">${ic('pin')}</a>` : ''}
                <button class="btn btn-xs btn-danger" data-cdel="${c.id}">${esc(c.active ? 'Désactiver' : 'Activer')}</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <p class="small muted mt-2">L’assignation automatique envoie chaque nouvelle commande au livreur en service le moins chargé. Un livreur avec une livraison en cours ne peut pas être supprimé — il est simplement désactivé.</p>`;

  el.querySelector('#newCourier').addEventListener('click', () => courierSheet(root, null));
  el.querySelectorAll('[data-cedit]').forEach((b) => b.addEventListener('click', () => courierSheet(root, state.couriers.find((c) => c.id === b.dataset.cedit))));
  el.querySelectorAll('[data-cdel]').forEach((b) => b.addEventListener('click', async () => {
    const c = state.couriers.find((x) => x.id === b.dataset.cdel);
    const turningOff = c.active;
    if (turningOff && !confirm(`Désactiver ${c.name} ?\nSon compte ne pourra plus se connecter.`)) return;
    try {
      if (turningOff) await api.put(`/api/admin/couriers/${encodeURIComponent(c.id)}`, { active: false, online: false });
      else await api.put(`/api/admin/couriers/${encodeURIComponent(c.id)}`, { active: true });
      toast(turningOff ? 'Livreur désactivé.' : 'Livreur réactivé.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  }));
}

function courierSheet(root, courier) {
  const isNew = !courier;
  ui.sheet.open({
    title: isNew ? 'Nouveau livreur' : `Modifier ${courier.name}`,
    body: `
      <label class="field"><span class="label">Prénom / nom</span><input class="input" id="cName" value="${esc(courier?.name || '')}" placeholder="Léo"></label>
      <label class="field"><span class="label">Email de connexion</span><input class="input" id="cEmail" type="email" value="${esc(courier?.email || '')}" placeholder="livreur@pannacottaclub.fr"></label>
      <label class="field"><span class="label">Téléphone</span><input class="input" id="cPhone" value="${esc(courier?.phone || '')}" placeholder="06 12 34 56 78"></label>
      <label class="field"><span class="label">${isNew ? 'Mot de passe' : 'Nouveau mot de passe (laisser vide pour conserver)'}</span>
        <input class="input" id="cPass" type="text" value="" placeholder="6 caractères minimum"></label>
      ${isNew ? '' : `<label class="switch"><input type="checkbox" id="cActive" ${courier.active !== false ? 'checked' : ''}><span class="track"></span><span class="strong">Compte actif</span></label>`}
      <div id="cErr" class="mt-2"></div>`,
    foot: `<button class="btn" id="cSave">${isNew ? 'CRÉER LE COMPTE' : 'ENREGISTRER'}</button>`,
    onMount(body, foot) {
      foot.querySelector('#cSave').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        const errBox = body.querySelector('#cErr');
        const payload = {
          name: body.querySelector('#cName').value.trim(),
          email: body.querySelector('#cEmail').value.trim(),
          phone: body.querySelector('#cPhone').value.trim(),
          password: body.querySelector('#cPass').value,
        };
        if (!isNew && !payload.password) delete payload.password;
        if (!isNew) payload.active = body.querySelector('#cActive').checked;
        if (payload.name.length < 2) { errBox.innerHTML = '<div class="banner banner-error">Nom trop court.</div>'; return; }
        if (isNew && payload.password.length < 6) { errBox.innerHTML = '<div class="banner banner-error">Mot de passe : 6 caractères minimum.</div>'; return; }
        btn.disabled = true;
        btn.innerHTML = '<span class="spin"></span>';
        try {
          if (isNew) await api.post('/api/admin/couriers', payload);
          else await api.put(`/api/admin/couriers/${encodeURIComponent(courier.id)}`, payload);
          toast(isNew ? 'Compte livreur créé.' : 'Livreur enregistré.', 'ok');
          ui.sheet.close();
          await refresh(root, { silent: true });
        } catch (err) {
          errBox.innerHTML = `<div class="banner banner-error">${esc(err.message)}</div>`;
          btn.disabled = false;
          btn.textContent = isNew ? 'CRÉER LE COMPTE' : 'ENREGISTRER';
        }
      });
    },
  });
}

/* ============================================================ PANNEAUX & QR = */
function paintQr(root, el) {
  const base = state.publicUrl || location.origin;
  const url = `${base}/commander`;
  el.innerHTML = `
    <div class="grid-2">
      <div>
        <h3>Panonceau de plage</h3>
        <p class="small muted">Imprimez ce panneau (A4 ou A3) et fixez-le près des accès et escaliers de la plage. Le QR code ouvre directement la carte.</p>
        <label class="field"><span class="label">Adresse encodée dans le QR code</span>
          <input class="input" id="qrUrl" value="${esc(url)}"></label>
        <div class="btn-row">
          <button class="btn btn-outline" id="qrPrint">${ic('qr')} Imprimer le panneau</button>
          <button class="btn btn-outline" id="qrDownload">Télécharger le QR (PNG)</button>
        </div>
        <div class="banner mt-3">${ic('info')}<div>Le QR code est fabriqué <strong>dans le navigateur</strong> : aucune image ne part sur Internet, aucune donnée n'est partagée. Il pointe vers <strong>${esc(url)}</strong>.</div></div>
      </div>
      <div>
        <div class="poster" id="poster">
          <div class="band"></div>
          <img src="assets/img/logo.png" alt="" style="width:120px;height:120px">
          <h1>PANNACOTTACLUB</h1>
          <p class="lines">
            <span>Une petite soif ?</span>
            <span>Une envie de glace ?</span>
          </p>
          <p class="lines mt-2" style="text-transform:none;font-weight:600">PannacottaClub est là pour vous servir.<br>Livraison directement sur la plage.</p>
          <div id="qrHolder" style="margin:20px auto 10px"></div>
          <p class="strong" style="letter-spacing:.2em">SCANNEZ LE QR CODE</p>
          <p class="zone">${esc(state.settings.zone?.label || 'Plage de Cabourg')}</p>
          <div class="band bottom"></div>
        </div>
      </div>
    </div>`;

  const input = el.querySelector('#qrUrl');
  const holder = el.querySelector('#qrHolder');

  /** Dessine le QR code dans la page (librairie MIT embarquée). */
  const renderQr = () => {
    const value = (input.value || url).trim();
    holder.innerHTML = '';
    if (typeof qrcode !== 'function') {
      holder.innerHTML = '<p class="small muted">Générateur de QR code indisponible.</p>';
      return;
    }
    try {
      const qr = qrcode(0, 'M');            // 0 = taille automatique, correction moyenne
      qr.addData(value);
      qr.make();
      holder.innerHTML = qr.createImgTag(6, 12);   // 6 px par module, marge 12 px
      const img = holder.querySelector('img');
      if (img) {
        img.style.width = '210px';
        img.style.height = '210px';
        img.alt = 'QR code PannacottaClub';
      }
    } catch (err) {
      holder.innerHTML = '<p class="small muted">Adresse trop longue pour un QR code.</p>';
    }
  };

  renderQr();
  input.addEventListener('change', renderQr);
  el.querySelector('#qrPrint').addEventListener('click', () => window.print());
  el.querySelector('#qrDownload').addEventListener('click', () => {
    const img = el.querySelector('#qrHolder img');
    if (!img) return;
    const a = document.createElement('a');
    a.href = img.src;
    a.download = 'pannacottaclub-qr.png';
    a.click();
  });
}

/* ================================================================ RÉGLAGES = */
function paintSettings(root, el) {
  const s = state.settings;
  el.innerHTML = `
    <div class="grid-2">
      <div class="card">
        <div class="card-head"><h3>Exploitation</h3></div>
        <label class="switch mb-2"><input type="checkbox" id="sAccept" ${s.acceptingOrders ? 'checked' : ''}><span class="track"></span><span class="strong">Service ouvert aux commandes</span></label>
        <label class="switch mb-2"><input type="checkbox" id="sAuto" ${s.autoAssign ? 'checked' : ''}><span class="track"></span><span class="strong">Assignation automatique au livreur</span></label>
        <p class="small muted">Avec un seul livreur, l’assignation automatique évite l’étape « prendre la commande » : chaque commande lui est confiée dès sa validation.</p>
        <label class="switch"><input type="checkbox" id="sZoneReq" ${s.requireInZone ? 'checked' : ''}><span class="track"></span><span class="strong">Refuser les commandes hors zone</span></label>
        <label class="switch mt-2"><input type="checkbox" id="sLiveMap" ${s.liveMapPublic !== false ? 'checked' : ''}><span class="track"></span><span class="strong">Afficher le livreur en direct sur la page d'accueil</span></label>
        <p class="small muted" style="margin-top:6px">Position du livreur en direct, au mètre près, sans aucune donnée client, uniquement pendant une livraison. Décochez pour la garder privée.</p>
        <div class="divider"></div>
        <button class="btn btn-outline btn-sm" id="saveOps">Enregistrer</button>
      </div>

      <div class="card">
        <div class="card-head"><h3>Carte Google</h3></div>
        <p class="small muted mb-2">Sans clé, le site affiche déjà la carte Google de la plage, recentrée sur la position exacte du livreur. Avec une clé Google Maps (« Maps JavaScript API »), vous obtenez la carte interactive : marqueurs qui glissent en direct, cercle de la zone de livraison et repères de vos lieux de vente.</p>
        <label class="field"><span class="label">Clé Google Maps (facultative)</span><input class="input mono" id="sGoogleKey" placeholder="AIza…" value="${esc(s.googleKey || '')}"></label>
        <p class="small muted">La clé reste chez vous. Restreignez-la par site web (référent HTTP) dans Google Cloud : elle est faite pour être visible dans le navigateur.</p>
        <button class="btn btn-outline btn-sm mt-2" id="saveGoogle">Enregistrer la clé</button>
      </div>

      <div class="card">
        <div class="card-head"><h3>Zone de livraison</h3></div>
        <label class="field"><span class="label">Libellé</span><input class="input" id="zLabel" value="${esc(s.zone?.label || '')}"></label>
        <div class="row" style="gap:12px">
          <label class="field grow"><span class="label">Latitude</span><input class="input mono" id="zLat" value="${s.zone?.lat ?? ''}"></label>
          <label class="field grow"><span class="label">Longitude</span><input class="input mono" id="zLng" value="${s.zone?.lng ?? ''}"></label>
        </div>
        <label class="field"><span class="label">Rayon (mètres)</span><input class="input mono" id="zRad" type="number" min="50" step="50" value="${s.zone?.radius ?? 900}"></label>
        <label class="field"><span class="label">Vitesse moyenne du livreur (m/s)</span><input class="input mono" id="sSpeed" type="number" step="0.1" min="0.5" value="${s.avgSpeed ?? 1.3}"></label>
        <button class="btn btn-outline btn-sm" id="saveZone">Enregistrer la zone</button>
        <p class="small muted mt-2">Astuce : récupérez les coordonnées du point de départ (poste de secours 1) sur maps.google.com, clic droit → « Plus d’infos sur cet endroit ».</p>
      </div>
    </div>`;

  el.querySelector('#saveOps').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      await api.put('/api/admin/settings', {
        acceptingOrders: el.querySelector('#sAccept').checked,
        autoAssign: el.querySelector('#sAuto').checked,
        requireInZone: el.querySelector('#sZoneReq').checked,
        liveMapPublic: el.querySelector('#sLiveMap').checked,
      });
      toast('Réglages enregistrés.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
    btn.disabled = false;
  });

  el.querySelector('#saveGoogle').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      const rep = await api.put('/api/admin/settings', { googleKey: el.querySelector('#sGoogleKey').value.trim() });
      toast(rep.settings?.googleKey ? 'Clé Google Maps enregistrée.' : 'Clé retirée : carte Google intégrée.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
    btn.disabled = false;
  });

  el.querySelector('#saveZone').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      await api.put('/api/admin/settings', {
        avgSpeed: Number(el.querySelector('#sSpeed').value),
        zone: {
          label: el.querySelector('#zLabel').value.trim(),
          lat: Number(el.querySelector('#zLat').value),
          lng: Number(el.querySelector('#zLng').value),
          radius: Number(el.querySelector('#zRad').value),
        },
      });
      toast('Zone de livraison enregistrée.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
    btn.disabled = false;
  });
}

export function stopAdminLive() { liveStop?.(); liveStop = null; mapCtl?.destroy(); }
