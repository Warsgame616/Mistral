/* ==========================================================================
   PANNACOTTACLUB — carte Google
   --------------------------------------------------------------------------
   Une vraie carte Google, avec la position exacte du livreur en temps réel.

   Deux modes, automatiques :
     1. « Clé API » (le meilleur) : si une clé Google Maps est renseignée
        (Admin → Réglages, ou config.php → map.google_key), le site charge
        l'API Google Maps : carte interactive, marqueurs qui glissent en douceur
        (aucun rechargement), cercle de la zone de livraison et repères de vos
        lieux de vente.
     2. « Sans clé » : sans clé, le site affiche la carte Google intégrée
        (google.com/maps/embed). La carte se recentre automatiquement sur la
        position exacte, avec tout le suivi chiffré : distance au mètre, heure
        de la dernière position, précision du GPS du téléphone.

   Dans les deux modes : la position affichée est la vraie mesure GPS, au mètre,
   et elle se met à jour toute seule (aucun rechargement de page).
   ========================================================================== */
import { distanceLabel } from './core.js';

/* Ouvre l'application de cartes du téléphone (itinéraire). */
export const mapsLink = (pos) =>
  `https://www.google.com/maps/dir/?api=1&destination=${pos.lat},${pos.lng}&travelmode=walking`;

export const geoLink = (pos) => `geo:${pos.lat},${pos.lng}?q=${pos.lat},${pos.lng}`;

/* ------------------------------------------------------------------ réglages */
const DEFAUT = {
  mer: 'nord',              // conservé pour compatibilité (plan d'origine)
  largeur_m: 1500,
  google_key: '',           // clé Google Maps (facultative, voir ci-dessus)
  pois: [
    { label: 'Poste de secours 1', lat: 49.29115, lng: -0.12490, type: 'poste' },
    { label: 'Poste de secours 2', lat: 49.29195, lng: -0.11760, type: 'poste' },
    { label: 'Promenade Marcel Proust', lat: 49.29090, lng: -0.12125, type: 'lieu' },
  ],
};

let CONFIG = { ...DEFAUT, zone: null };

/** Le site transmet ici sa zone, ses lieux de vente et sa clé Google. */
export function configureMap({ zone = null, map = null } = {}) {
  CONFIG = {
    ...DEFAUT,
    ...(map || {}),
    zone: zone || null,
    pois: (map && Array.isArray(map.pois) && map.pois.length) ? map.pois : DEFAUT.pois,
  };
  return CONFIG;
}

const nb = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
const point = (p) => (p && nb(p.lat) != null && nb(p.lng) != null ? { lat: Number(p.lat), lng: Number(p.lng) } : null);
const cle = (pos) => `${pos.lat.toFixed(5)},${pos.lng.toFixed(5)}`;
const centreZone = () => point(CONFIG.zone) || { lat: nb(CONFIG.zone?.lat) ?? 49.29155, lng: nb(CONFIG.zone?.lng) ?? -0.12125 };

/* -------------------------------------------------------- chargement de Google */
let promesseApi = null;

/** Charge l'API Google Maps une seule fois pour toute la page. */
function chargerApiGoogle() {
  if (window.google && window.google.maps) return Promise.resolve(window.google.maps);
  if (!CONFIG.google_key) return Promise.reject(new Error('sans-cle'));
  if (promesseApi) return promesseApi;
  promesseApi = new Promise((resoudre, rejeter) => {
    const fini = (fn, arg) => { promesseApi = null; fn(arg); };
    window.__pcGooglePret = () => fini(resoudre, window.google.maps);
    const s = document.createElement('script');
    s.src = 'https://maps.googleapis.com/maps/api/js'
      + `?key=${encodeURIComponent(CONFIG.google_key)}&language=fr&region=FR&v=weekly&loading=async`
      + '&callback=__pcGooglePret';
    s.async = true; s.defer = true;
    s.onerror = () => fini(rejeter, new Error('google-injoignable'));
    document.head.appendChild(s);
    setTimeout(() => { if (window.google && window.google.maps) return; fini(rejeter, new Error('google-delai')); }, 12000);
  });
  return promesseApi;
}

/* --------------------------------------------------------- URL carte sans clé */
/** Adresse de la carte Google intégrée, centrée sur la position exacte.
    Forme « ll=… » : Google centre la carte sans y poser son propre repère — le
    seul repère affiché est donc le nôtre, pile sur la position mesurée. */
function lienEmbed({ centre = null, z = 15 } = {}) {
  const c = centre || centreZone();
  return `https://maps.google.com/maps?ll=${cle(c)}&z=${z}&hl=fr&output=embed`;
}

/* Échelle de Google Maps (projection Web Mercator) : sert à faire glisser la
   carte au pixel près quand le livreur avance, sans recharger l'iframe. */
const M_PAR_DEG_LAT = 111320;
const mParPixel = (lat, z) => (156543.03392 * Math.cos((lat * Math.PI) / 180)) / 2 ** z;
const SEUIL_RECENTRAGE = 220;      // px : au-delà, on recharge la carte centrée

/* ============================================================== création === */
/**
 * Crée une carte Google.
 * @param {HTMLElement} el conteneur (.map)
 * @param {{center?:{lat,lng}, zoom?:number, zone?:object}} options
 */
export function createMap(el, { center, zoom = 15, zone = null } = {}) {
  if (!el) return null;

  const laZone = zone || CONFIG.zone || null;
  const zBase = Math.max(10, Math.min(20, Number(zoom) || 16));

  const etat = {
    el, mode: '', pret: false, erreur: '', client: null, livreur: null,
    livreurs: new Map(), z: zBase, destruction: false, maj: 0,
  };

  /* ------------------------------------------------------------- structure
     Les éléments déjà présents dans le cadre (légende « Vous / Votre livreur »)
     sont conservés : ils restent posés par-dessus la carte. */
  const dejaLa = [...el.children];
  el.classList.add('pcmap');
  el.innerHTML = `
    <div class="pcmap-cadre">
      <div class="pcmap-canvas"></div>
      <div class="pcmap-pin" hidden><span>L</span></div>
      <div class="pcmap-charge">Chargement de la carte Google…</div>
    </div>
    <div class="pcmap-bandeau">
      <span class="pcmap-etat">Position en cours d'acquisition…</span>
      <a class="pcmap-lien" data-role="position" href="#" target="_blank" rel="noopener">Position</a>
      <a class="pcmap-lien" data-role="itineraire" href="#" target="_blank" rel="noopener" hidden>Itinéraire</a>
    </div>`;

  const cadreEl = el.querySelector('.pcmap-cadre');
  const canvasEl = el.querySelector('.pcmap-canvas');
  const pinEl = el.querySelector('.pcmap-pin');
  const chargeEl = el.querySelector('.pcmap-charge');
  const etatEl = el.querySelector('.pcmap-etat');
  const lienEl = el.querySelector('[data-role="position"]');
  const lienItineraire = el.querySelector('[data-role="itineraire"]');

  /* Contrôles de zoom, comme sur la carte d'origine. */
  for (const node of dejaLa) cadreEl.appendChild(node);

  /* Contrôles de zoom, comme sur la carte d'origine. */
  const controles = document.createElement('div');
  controles.className = 'pcmap-controles';
  controles.innerHTML = `
    <button type="button" class="pcmap-btn" data-zoom="1" aria-label="Zoomer">+</button>
    <button type="button" class="pcmap-btn" data-zoom="-1" aria-label="Dézoomer">−</button>
    <button type="button" class="pcmap-btn pcmap-btn-large" data-action="fit" aria-label="Tout afficher" title="Tout afficher">⤢</button>`;
  el.appendChild(controles);

  /* ---------------------------------------------------------------- iframe */
  let frame = null;
  let signature = '';

  const poserFrame = (url) => {
    if (!frame) {
      frame = document.createElement('iframe');
      frame.className = 'pcmap-frame';
      frame.setAttribute('title', 'Carte Google — position en direct');
      frame.setAttribute('loading', 'eager');
      frame.setAttribute('allowfullscreen', '');
      frame.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
      frame.addEventListener('load', () => { chargeEl.hidden = true; etat.pret = true; });
      cadreEl.appendChild(frame);
    }
    if (frame.getAttribute('src') !== url) frame.setAttribute('src', url);
  };

  /* ------------------------------------------------------ mode API Google */
  let carte = null;
  let cercleZone = null;
  let marqueurClient = null;
  const marqueursPois = [];
  const marqueursLivreurs = new Map();

  const icone = (lettre, couleur) => ({
    path: 'M0 0 C -12 -13 -18 -21 -18 -30 A 18 18 0 0 1 18 -30 C 18 -21 12 -13 0 0 Z',
    fillColor: couleur, fillOpacity: 1, strokeColor: '#FFFFFF', strokeWeight: 2.5,
    scale: 1, anchor: new window.google.maps.Point(0, 0),
    labelOrigin: new window.google.maps.Point(0, -20),
  });

  const poserMarqueur = (pos, { lettre, couleur, titre }) => {
    const m = new window.google.maps.Marker({
      position: pos, map: carte, title: titre,
      icon: icone(lettre, couleur),
      label: { text: lettre, color: '#FFFFFF', fontSize: '13px', fontWeight: '700' },
      zIndex: 30,
    });
    return m;
  };

  /** Déplace un marqueur en douceur (la position glisse vers la nouvelle mesure). */
  const glisser = (marqueur, vers, duree = 900) => {
    if (!marqueur) return;
    const depuis = marqueur.getPosition();
    if (!depuis || !window.requestAnimationFrame) { marqueur.setPosition(vers); return; }
    const t0 = performance.now();
    const etape = (t) => {
      const k = Math.min(1, (t - t0) / duree);
      const e = k < 0.5 ? 2 * k * k : 1 - ((-2 * k + 2) ** 2) / 2;   // adouci
      marqueur.setPosition({
        lat: depuis.lat() + (vers.lat - depuis.lat()) * e,
        lng: depuis.lng() + (vers.lng - depuis.lng()) * e,
      });
      if (k < 1) requestAnimationFrame(etape);
    };
    requestAnimationFrame(etape);
  };

  async function demarrerModeApi() {
    const g = await chargerApiGoogle();
    if (etat.destruction) return;
    etat.mode = 'api';
    canvasEl.hidden = false;
    chargeEl.hidden = true;
    carte = new window.google.maps.Map(canvasEl, {
      center: centreZone(), zoom: zBase, mapTypeControl: false, streetViewControl: false,
      fullscreenControl: false, clickableIcons: false, gestureHandling: 'greedy',
      styles: [
        { featureType: 'water', stylers: [{ color: '#0B10C8' }] },
        { featureType: 'landscape.natural', stylers: [{ color: '#FFFFFF' }] },
        { featureType: 'landscape.man_made', stylers: [{ color: '#F4F5FF' }] },
        { featureType: 'poi', stylers: [{ visibility: 'off' }] },
        { featureType: 'transit', stylers: [{ visibility: 'off' }] },
        { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#E4E7FF' }] },
        { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#D3D8FF' }] },
        { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#4A4E86' }] },
        { featureType: 'administrative', elementType: 'labels.text.fill', stylers: [{ color: '#090A33' }] },
      ],
    });

    if (nb(laZone?.radius)) {
      cercleZone = new window.google.maps.Circle({
        map: carte, center: centreZone(), radius: Number(laZone.radius),
        fillColor: '#060CD4', fillOpacity: 0.07, strokeColor: '#060CD4',
        strokeOpacity: 0.55, strokeWeight: 2,
      });
    }

    for (const p of CONFIG.pois || []) {
      const q = point(p);
      if (!q) continue;
      const m = new window.google.maps.Marker({
        position: q, map: carte, title: p.label || 'Lieu de vente',
        icon: {
          path: 'M0 0 C -10 -11 -15 -17 -15 -24 A 15 15 0 0 1 15 -24 C 15 -17 10 -11 0 0 Z',
          fillColor: '#090A33', fillOpacity: 1, strokeColor: '#FFFFFF', strokeWeight: 2,
        },
      });
      const info = new window.google.maps.InfoWindow({ content: p.label || 'Lieu de vente' });
      m.addListener('click', () => info.open({ map: carte, anchor: m }));
      marqueursPois.push(m);
    }

    peindre();
    fit();
  }

  /* ------------------------------------------------------------- mode sans clé
     La carte Google est centrée sur la position de référence ; à chaque nouvelle
     mesure, on fait glisser la carte du décalage exact (calculé à l'échelle de
     Google), si bien que le repère central suit le livreur au mètre, en douceur
     et sans recharger la carte. Au-delà du seuil, on recentre proprement. */
  function centrerSur(pos, { forcer = false } = {}) {
    etat.ref = { ...pos };
    etat.z = Math.max(3, Math.min(20, etat.z));
    const url = lienEmbed({ centre: pos, z: etat.z });
    if (forcer || url !== signature) {
      signature = url;
      poserFrame(url);                        // crée la carte au premier passage
      frame.style.transition = 'none';
      frame.style.transform = 'translate(0, 0)';
      requestAnimationFrame(() => { frame.style.transition = ''; });
    }
  }

  function glisserVers(pos) {
    const ref = etat.ref;
    if (!ref || !frame) return;
    const mpp = mParPixel(ref.lat, etat.z);
    const dEst = (pos.lng - ref.lng) * M_PAR_DEG_LAT * Math.cos((ref.lat * Math.PI) / 180);
    const dNord = (pos.lat - ref.lat) * M_PAR_DEG_LAT;
    const tx = -dEst / mpp;
    const ty = dNord / mpp;
    if (Math.abs(tx) > SEUIL_RECENTRAGE || Math.abs(ty) > SEUIL_RECENTRAGE) { centrerSur(pos); return; }
    frame.style.transform = `translate(${tx.toFixed(2)}px, ${ty.toFixed(2)}px)`;
  }

  function peindreSansCle() {
    const suivi = etat.livreur || etat.client || centreZone();
    pinEl.hidden = false;
    pinEl.classList.toggle('is-livreur', !!etat.livreur);
    pinEl.querySelector('span').textContent = etat.livreur ? 'L' : 'V';
    if (!etat.ref) centrerSur(suivi);
    else glisserVers(suivi);
    lienEl.href = mapsLink(suivi);
    /* L'itinéraire n'a de sens que si l'on connaît aussi la position du client. */
    const c = etat.client;
    lienItineraire.hidden = !(c && etat.livreur);
    if (c) lienItineraire.href = `https://www.google.com/maps/dir/?api=1&origin=${etat.livreur ? cle(etat.livreur) : ''}&destination=${cle(c)}&travelmode=walking`;
  }

  /* --------------------------------------------------------------- bandeau */
  const ilYA = (ms) => {
    const s = Math.round((Date.now() - ms) / 1000);
    if (s < 5) return "à l'instant";
    if (s < 60) return `il y a ${s} s`;
    const m = Math.round(s / 60);
    return `il y a ${m} min`;
  };

  function majBandeau() {
    const l = etat.livreur;
    const c = etat.client;
    const bouts = [];
    if (l && c) {
      const R = 6371000;
      const dLat = ((c.lat - l.lat) * Math.PI) / 180;
      const dLng = ((c.lng - l.lng) * Math.PI) / 180;
      const h = Math.sin(dLat / 2) ** 2
        + Math.cos((l.lat * Math.PI) / 180) * Math.cos((c.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
      const m = 2 * R * Math.asin(Math.sqrt(h));
      bouts.push(`Livreur à ${distanceLabel(m)}`);
    }
    const ref = l || c;
    if (ref) {
      bouts.push(`position exacte ${ref.lat.toFixed(5)}, ${ref.lng.toFixed(5)}`);
      if (ref.at) bouts.push(`relevée ${ilYA(ref.at)}`);
      if (nb(ref.accuracy) && Number(ref.accuracy) > 0) bouts.push(`précision ± ${Math.round(ref.accuracy)} m`);
    } else {
      bouts.push('Aucune position pour le moment');
    }
    etatEl.textContent = bouts.join(' · ');
  }

  /* ---------------------------------------------------------------- dessin */
  function peindre() {
    majBandeau();
    if (etat.mode === 'api' && carte) {
      pinEl.hidden = true;
      if (etat.client) {
        if (!marqueurClient) {
          marqueurClient = poserMarqueur(etat.client, { lettre: 'V', couleur: '#060CD4', titre: 'Client' });
        } else glisser(marqueurClient, etat.client);
      } else if (marqueurClient) { marqueurClient.setMap(null); marqueurClient = null; }

      for (const [id, l] of etat.livreurs) {
        const vers = { lat: l.lat, lng: l.lng };
        let m = marqueursLivreurs.get(id);
        if (!m) {
          m = poserMarqueur(vers, { lettre: 'L', couleur: '#090A33', titre: l.titre || 'Livreur' });
          marqueursLivreurs.set(id, m);
        } else glisser(m, vers);
      }
      lienEl.href = mapsLink(etat.livreur || etat.client || centreZone());
      return;
    }
    if (etat.mode !== 'api') peindreSansCle();
  }

  /* ------------------------------------------------------- mise en service */
  /** Repasse sur la carte Google intégrée : efface la carte API et son canvas. */
  function basculerSurEmbed(raison) {
    if (etat.mode === 'embed') return;
    if (raison !== 'sans-cle') etat.erreur = raison;
    etat.mode = 'embed';
    try {
      if (marqueurClient) { marqueurClient.setMap(null); marqueurClient = null; }
      for (const m of marqueursLivreurs.values()) m.setMap(null);
      marqueursLivreurs.clear();
      if (cercleZone) { cercleZone.setMap(null); cercleZone = null; }
      for (const m of marqueursPois) m.setMap(null);
      marqueursPois.length = 0;
      carte = null;
      canvasEl.innerHTML = '';
      canvasEl.style.display = 'none';     // la carte intégrée prend toute la place
    } catch { /* ignore */ }
    signature = '';
    chargeEl.hidden = false;
    chargeEl.textContent = 'Chargement de la carte Google…';
    peindre();
  }

  async function demarrer() {
    /* Clé refusée par Google (absente, expirée, mauvaise restriction) : on bascule
       immédiatement sur la carte Google intégrée, sans rien casser. */
    window.gm_authFailure = () => basculerSurEmbed('cle-refusee');
    /* ?pcmap=embed force la carte intégrée (utile pour vérifier le site). */
    const forceEmbed = /[?&]pcmap=embed/.test(location.search);
    if (CONFIG.google_key && !forceEmbed) {
      try { await demarrerModeApi(); return; }
      catch (e) { basculerSurEmbed(String((e && e.message) || e)); return; }
    }
    basculerSurEmbed('sans-cle');
  }

  /* ------------------------------------------------------------- contrôles */
  const zoomer = (d) => {
    if (etat.mode === 'api' && carte) { carte.setZoom(carte.getZoom() + d); return; }
    etat.z = Math.max(3, Math.min(20, etat.z + d));
    signature = '';
    const cible = etat.livreur || etat.client || centreZone();
    centrerSur(cible, { forcer: true });
    peindre();
  };
  el.querySelector('[data-zoom="1"]').addEventListener('click', () => zoomer(1));
  el.querySelector('[data-zoom="-1"]').addEventListener('click', () => zoomer(-1));
  el.querySelector('[data-action="fit"]').addEventListener('click', () => api.fit());

  /* --------------------------------------------------------------- traces */
  const info = () => ({
    mode: etat.mode,
    pret: etat.pret,
    erreur: etat.erreur,
    source: frame ? frame.src : 'api-google',
    decalage: frame ? (frame.style.transform || 'aucun') : 'api-google',
    reference: etat.ref ? cle(etat.ref) : null,
    zoom: etat.z,
    client: etat.client ? cle(etat.client) : null,
    livreur: etat.livreur ? cle(etat.livreur) : null,
    livreurs: etat.livreurs.size,
    maj: etat.maj,
  });

  /* ------------------------------------------------------------------ API */
  const api = {
    el,
    state: etat,
    /** Position du client (exacte, telle que mesurée par son téléphone). */
    setClient(pos, { focus = false } = {}) {
      const p = point(pos);
      if (!p || etat.destruction) return;
      etat.client = {
        ...p, accuracy: Number(pos.accuracy) || 0, at: pos.at || Date.now(), titre: 'Client',
      };
      etat.maj++;
      peindre();
      if (focus) api.fit();
    },
    /** Position(s) du livreur : la vraie mesure, sans arrondi. */
    setCourier(pos, { id = 'defaut', nom = '', animate = true } = {}) {
      const p = point(pos);
      if (!p || etat.destruction) return;
      const fiche = {
        ...p, accuracy: Number(pos.accuracy) || 0, at: pos.at || Date.now(),
        titre: nom ? `Livreur ${nom}` : 'Livreur',
      };
      etat.livreurs.set(id, fiche);
      etat.livreur = fiche;                  // le dernier reçu = celui du suivi
      etat.maj++;
      peindre();
    },
    /** Course terminée : plus aucune position sur la carte. */
    clearCourier() {
      if (etat.destruction) return;
      etat.livreur = null;
      etat.livreurs.clear();
      for (const m of marqueursLivreurs.values()) m.setMap(null);
      marqueursLivreurs.clear();
      signature = '';
      etat.ref = null;
      etat.maj++;
      peindre();
    },
    /** Cadre tout ce qu'il y a à voir (client, livreurs, zone, lieux de vente). */
    fit() {
      if (etat.mode === 'api' && carte && window.google?.maps) {
        const bornes = new window.google.maps.LatLngBounds();
        const points = [etat.client, ...etat.livreurs.values()].filter(Boolean);
        (points.length ? points : [centreZone()]).forEach((p) => bornes.extend({ lat: p.lat, lng: p.lng }));
        if (bornes.isEmpty()) return;
        carte.fitBounds(bornes, { padding: 60, maxZoom: 18 });
        return;
      }
      signature = '';
      etat.z = 15;
      const cible = etat.livreur || etat.client || centreZone();
      if (etat.mode !== 'api') centrerSur(cible, { forcer: true });
      peindre();
    },
    /** Le cadre a changé de taille : on redessine. */
    invalidate() {
      setTimeout(() => {
        if (etat.destruction) return;
        if (etat.mode === 'api' && carte && window.google?.maps) {
          window.google.maps.event.trigger(carte, 'resize');
        }
        signature = '';
        peindre();
      }, 120);
    },
    info,
    destroy() {
      etat.destruction = true;
      for (const m of marqueursLivreurs.values()) m.setMap(null);
      marqueursLivreurs.clear();
      if (marqueurClient) marqueurClient.setMap(null);
      for (const m of marqueursPois) m.setMap(null);
      if (cercleZone) cercleZone.setMap(null);
      el.innerHTML = '';
      el.classList.remove('pcmap');
    },
  };

  demarrer().catch((e) => {
    etat.erreur = String((e && e.message) || e);
    etatEl.textContent = 'Carte indisponible hors connexion — position exacte affichée ci-dessous.';
    lienEl.href = mapsLink(etat.livreur || etat.client || centreZone());
  });
  majBandeau();

  /* Le bandeau se rafraîchit tout seul (« relevée il y a 3 s »). */
  const minuteur = setInterval(() => { if (!etat.destruction) majBandeau(); }, 4000);
  api.state.minuteur = minuteur;
  window.addEventListener('pagehide', () => clearInterval(minuteur), { once: true });

  return api;
}

/* ------------------------------------------------------------ utilitaires */
/** Texte lisible : distance entre le livreur et le client. */
export function routeText(courier, client) {
  if (!courier || !client) return '';
  const R = 6371000;
  const dLat = ((client.lat - courier.lat) * Math.PI) / 180;
  const dLng = ((client.lng - courier.lng) * Math.PI) / 180;
  const la1 = (courier.lat * Math.PI) / 180;
  const la2 = (client.lat * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  const m = 2 * R * Math.asin(Math.sqrt(h));
  return `${distanceLabel(m)} de vous`;
}
