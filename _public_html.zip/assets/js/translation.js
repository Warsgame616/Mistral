/* Missiona — sélecteur de traduction volontairement déclenché par l'utilisateur.
   Aucun script Google n'est chargé sur le site : après le choix d'une langue,
   l'utilisateur est dirigé vers la page Google Translate correspondante. */
(function(){
  function initTranslation(){
    var select = document.getElementById('site-language');
    if (!select || select.dataset.ready === '1') return;
    select.dataset.ready = '1';

    select.addEventListener('change', function(){
      var language = select.value;
      if (!language) return;

      // La version française est l'original du site.
      if (language === 'fr') {
        window.location.assign(window.location.href);
        return;
      }

      var page = window.location.href;
      var url = 'https://translate.google.com/translate?sl=fr&tl=' +
        encodeURIComponent(language) + '&u=' + encodeURIComponent(page);
      window.location.assign(url);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTranslation);
  } else {
    initTranslation();
  }
})();
