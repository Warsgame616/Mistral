import fs from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const Engine = require('php-parser');
const parser = new Engine({
  parser: { phpVersion: '8.1', suppressErrors: false },
  ast: { withPositions: true },
});

for (const file of ['index.php', 'scripts/php-test-router.php']) {
  parser.parseCode(fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8'), file);
}

console.log('PHP syntax check passed.');
