<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <a href="/" class="logo mb-2"><img class="logo-mark" src="<?= asset('assets/img/mark.svg') ?>" alt="" width="32" height="32"> Missiona</a>
        <p class="small" style="max-width:300px">Vous décrivez le projet, on livre le résultat. Notre équipe sélectionne les experts et pilote l'exécution de vos projets par des freelances qualifiés.</p>
      </div>
      <div>
        <h5>Plateforme</h5>
        <ul>
          <li><a href="/entreprises">Pour les entreprises</a></li>
          <li><a href="/freelances">Pour les freelances</a></li>
          <li><a href="/services">Nos expertises</a></li>
          <li><a href="/a-propos">Qui sommes-nous</a></li>
          <li><a href="/contact">Nous contacter</a></li>
          <li><a href="/a-propos">Notre méthode de sélection</a></li>
          <?php if (!beta_lien_masque('/tarifs')): ?><li><a href="/tarifs">Tarifs et devis</a></li><?php endif; ?>
        </ul>
      </div>
      <div>
        <h5>Ressources</h5>
        <ul>
          <li><a href="/faq">Questions fréquentes</a></li>
          <li><a href="/inscription">Créer un compte</a></li>
          <li><a href="/connexion">Se connecter</a></li>
        </ul>
      </div>
      <div>
        <h5>Légal</h5>
        <ul>
          <li><a href="/mentions">Mentions légales</a></li>
          <li><a href="/mentions#cgu">CGU / CGV</a></li>
          <li><a href="/mentions#rgpd">Confidentialité / RGPD</a></li>
          <li><a href="/mentions#cookies">Cookies</a></li>
        </ul>
      </div>
    </div>

    <div class="footer-translate" aria-label="Traduction du site">
      <div>
        <strong>Traduire le site</strong>
        <span>Choisissez une langue européenne. La traduction automatique s'ouvre avec Google Translate.</span>
      </div>
      <label class="sr-only" for="site-language">Choisir la langue du site</label>
      <select id="site-language" name="site-language">
        <option value="" selected>Choisir une langue</option>
        <optgroup label="Langues de l'Union européenne">
          <option value="bg">Български — Bulgare</option>
          <option value="hr">Hrvatski — Croate</option>
          <option value="cs">Čeština — Tchèque</option>
          <option value="da">Dansk — Danois</option>
          <option value="nl">Nederlands — Néerlandais</option>
          <option value="en">English — Anglais</option>
          <option value="et">Eesti — Estonien</option>
          <option value="fi">Suomi — Finnois</option>
          <option value="fr">Français — Original</option>
          <option value="de">Deutsch — Allemand</option>
          <option value="el">Ελληνικά — Grec</option>
          <option value="hu">Magyar — Hongrois</option>
          <option value="ga">Gaeilge — Irlandais</option>
          <option value="it">Italiano — Italien</option>
          <option value="lv">Latviešu — Letton</option>
          <option value="lt">Lietuvių — Lituanien</option>
          <option value="mt">Malti — Maltais</option>
          <option value="pl">Polski — Polonais</option>
          <option value="pt">Português — Portugais</option>
          <option value="ro">Română — Roumain</option>
          <option value="sk">Slovenčina — Slovaque</option>
          <option value="sl">Slovenščina — Slovène</option>
          <option value="es">Español — Espagnol</option>
          <option value="sv">Svenska — Suédois</option>
        </optgroup>
        <optgroup label="Autres langues européennes">
          <option value="sq">Shqip — Albanais</option>
          <option value="hy">Հայերեն — Arménien</option>
          <option value="az">Azərbaycanca — Azéri</option>
          <option value="eu">Euskara — Basque</option>
          <option value="be">Беларуская — Biélorusse</option>
          <option value="bs">Bosanski — Bosnien</option>
          <option value="ca">Català — Catalan</option>
          <option value="fo">Føroyskt — Féroïen</option>
          <option value="gl">Galego — Galicien</option>
          <option value="cy">Cymraeg — Gallois</option>
          <option value="ka">ქართული — Géorgien</option>
          <option value="is">Íslenska — Islandais</option>
          <option value="lb">Lëtzebuergesch — Luxembourgeois</option>
          <option value="mk">Македонски — Macédonien</option>
          <option value="no">Norsk — Norvégien</option>
          <option value="ru">Русский — Russe</option>
          <option value="sr">Српски — Serbe</option>
          <option value="tr">Türkçe — Turc</option>
          <option value="uk">Українська — Ukrainien</option>
        </optgroup>
      </select>
    </div>

    <div class="footer-bottom">
      <span>© <?= date('Y') ?> Missiona — Tous droits réservés.</span>
      <span>Conçu en France 🇫🇷</span>
    </div>
  </div>
</footer>

<script src="<?= asset('assets/js/app.js') ?>" defer></script>
<script src="<?= asset('assets/js/translation.js') ?>" defer></script>
</body>
</html>
