<?php
/**
 * Missiona — Réglages de VOTRE installation
 * ==================================================================
 *  MODE D'EMPLOI
 *   1. Renommez ce fichier en « config.local.php ».
 *   2. Retirez les // devant les lignes qui vous concernent.
 *   3. Laissez les autres commentées : les valeurs par défaut de
 *      config.php s'appliqueront.
 *   4. Gardez une copie sur votre ordinateur.
 *
 *  Ce fichier n'est jamais inclus dans les mises à jour : il ne sera
 *  donc jamais écrasé. Tout ce qu'il définit l'emporte sur config.php.
 *
 *  Aucun espace ni ligne vide avant le <?php ci-dessus, sous peine
 *  d'un message « headers already sent ».
 * ==================================================================
 */

/* ==================================================================
 *  À RENSEIGNER EN PREMIER
 * ================================================================== */

/* Adresse publique du site, SANS barre oblique finale.
   Indispensable si votre domaine diffère de missiona.eu, sinon les
   liens partagés et le référencement pointeront au mauvais endroit. */
// define('SITE_URL',   'https://missiona.eu');

/* Identité affichée sur le site et dans les factures. */
// define('SITE_NOM',   'Missiona');
// define('SITE_EMAIL', 'contact@missiona.eu');
// define('SITE_TEL',   '01 23 45 67 89');

/* ------------------------------------------------------------------
 *  Compte administrateur
 * ------------------------------------------------------------------
 *  ATTENTION : ces deux lignes ne servent qu'au TOUT PREMIER
 *  chargement du site, quand la base est encore vide. Ensuite, le
 *  mot de passe se change dans le back-office.
 *
 *  Renseignez-les AVANT d'ouvrir le site pour la première fois.
 *  Le mot de passe par défaut (admin123) ne doit jamais rester.
 * ------------------------------------------------------------------ */
// define('ADMIN_EMAIL',    'vous@votre-domaine.eu');
// define('ADMIN_PASSWORD', 'un-mot-de-passe-long-et-unique');

/* ==================================================================
 *  EMPLACEMENT DES DONNÉES
 * ------------------------------------------------------------------
 *  Par défaut, la base est rangée toute seule dans un dossier situé
 *  À CÔTÉ du site (…/missiona-data/), pour qu'une mise à jour des
 *  fichiers ne puisse jamais l'effacer.
 *
 *  N'imposez un chemin que si vous savez pourquoi. Il doit se trouver
 *  HORS du dossier public et ne plus jamais changer : le modifier
 *  revient à repartir d'une base vide.
 * ================================================================== */
// define('DB_FILE', '/home/votre-compte/prive/missiona.sqlite');

/* ==================================================================
 *  E-MAILS — SMTP DE VOTRE HÉBERGEMENT
 * ------------------------------------------------------------------
 *  Réglages du compte e-mail de votre hébergement (ex. Hostinger :
 *  « E-mails » → votre adresse → « Configuration » → SMTP).
 *
 *  Port 465 = connexion chiffrée SSL ; port 587 = STARTTLS.
 *
 *  Tant que ces lignes restent commentées, le site essaie d'envoyer
 *  les e-mails par la fonction mail() de l'hébergement (résultat
 *  variable selon l'hébergeur ; le SMTP est recommandé).
 * ================================================================== */
// define('SMTP_HOST', 'smtp.hostinger.com');
// define('SMTP_PORT', 465);
// define('SMTP_USER', 'contact@votre-domaine.eu');
// define('SMTP_PASS', 'le-mot-de-passe-de-la-boite-mail');

/* ==================================================================
 *  PAIEMENTS — STRIPE (inutilisé dans le modèle actuel)
 * ------------------------------------------------------------------
 *  Le modèle en vigueur est le paiement direct : le client règle
 *  l'expert lui-même, Missiona n'encaisse rien. Ces clés ne servent
 *  donc plus. Ne les renseignez que si vous réactivez un jour
 *  l'encaissement en ligne.
 * ================================================================== */
// define('STRIPE_SECRET_KEY',     'sk_test_...');
// define('STRIPE_PUBLIC_KEY',     'pk_test_...');
// define('STRIPE_WEBHOOK_SECRET', 'whsec_...');

/* ==================================================================
 *  CONNEXION AVEC GOOGLE
 * ------------------------------------------------------------------
 *  Une seule fois, sur console.cloud.google.com :
 *   1. Créez un projet.
 *   2. « API et services » → « Écran de consentement OAuth » :
 *      type Externe, nom du site et votre adresse.
 *   3. « Identifiants » → « Créer » → « ID client OAuth » →
 *      type « Application Web ».
 *   4. Dans « URI de redirection autorisés », collez EXACTEMENT :
 *          https://votre-domaine/google-callback.php
 *      La moindre différence (http au lieu de https, www en trop)
 *      provoque l'erreur redirect_uri_mismatch.
 *
 *  Tant que ces lignes restent commentées, le bouton Google ne
 *  s'affiche pas et le site fonctionne normalement sans lui.
 * ================================================================== */
// define('GOOGLE_CLIENT_ID',     '123456789-xxxx.apps.googleusercontent.com');
// define('GOOGLE_CLIENT_SECRET', 'GOCSPX-xxxxxxxxxxxxxxxx');

/* Seulement si la détection automatique de l'adresse de retour échoue
   (site derrière un proxy, installation dans un sous-dossier). */
// define('GOOGLE_REDIRECT_URI', 'https://votre-domaine/google-callback.php');

/* ==================================================================
 *  MODÈLE ÉCONOMIQUE
 * ------------------------------------------------------------------
 *  Valeurs de départ uniquement. Une fois le site installé, réglez-les
 *  dans le back-office : ce que vous y saisissez prime sur ces lignes.
 * ================================================================== */
// define('COMMISSION_DEFAUT',  20);   // part Missiona, en %
// define('FRAIS_DOSSIER',       2);   // (historique) frais de validation, en €
// define('BUDGET_PLAFOND_CFG', 50000); // plafond du curseur de budget, en €

/* ==================================================================
 *  DÉPANNAGE
 * ================================================================== */

/* Affiche les erreurs à l'écran. À n'activer qu'en local, jamais en
   ligne : un message d'erreur révèle les chemins de votre serveur. */
// define('MODE_DEBUG', true);

/* ------------------------------------------------------------------
 *  Je ne peux plus me connecter
 * ------------------------------------------------------------------
 *  Décommentez la ligne suivante avec une phrase longue connue de
 *  vous seul, puis ouvrez :
 *
 *      https://votre-domaine/secours-admin.php
 *
 *  Cet écran recherche toutes les bases présentes sur l'hébergement,
 *  indique combien de comptes contient chacune, permet de remettre la
 *  bonne en service, de changer le mot de passe administrateur ou
 *  d'en créer un nouveau.
 *
 *  RECOMMENTEZ cette ligne dès que l'accès est rétabli : tant qu'elle
 *  est active, qui devine la phrase peut reprendre la main.
 * ------------------------------------------------------------------ */
// define('CLE_SECOURS', 'une-phrase-longue-et-unique');
