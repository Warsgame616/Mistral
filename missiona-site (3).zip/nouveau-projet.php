<?php
require_once __DIR__ . '/includes/functions.php';
require_role(['entreprise','particulier']);
$u = user();
$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $t = trim($_POST['titre'] ?? '');
    $c = trim($_POST['categorie'] ?? '');
    $d = trim($_POST['description'] ?? '');
    if (!$t || !$c || !$d) {
        $erreur = "Le titre, la catégorie et la description sont obligatoires.";
    } else {
        // Marqué si déposé pendant la préinscription : le client doit savoir
        // que son projet sera étudié à l'ouverture, pas dans les 48 heures.
        db()->prepare("INSERT INTO projets (entreprise_id,titre,categorie,description,competences,budget_min,budget_max,delai,date_limite,statut,cree_en_beta)
                       VALUES (?,?,?,?,?,?,?,?,?,'nouveau',?)")
            ->execute([$u['id'], $t, $c, $d, trim($_POST['competences'] ?? ''),
                       (int)($_POST['budget_min'] ?? 0), (int)($_POST['budget_max'] ?? 0),
                       trim($_POST['delai'] ?? ''), trim($_POST['date_limite'] ?? ''),
                       beta_actif() ? 1 : 0]);
        $pid = db()->lastInsertId();
        auto_assigner_client($u['id']);
        $gs = db()->prepare("SELECT gestionnaire_id FROM users WHERE id=?");
        $gs->execute([$u['id']]);
        $gest = (int) $gs->fetchColumn() ?: admin_id();
        notify($u['id'], beta_actif()
            ? "Votre projet « $t » est enregistré. Il sera étudié dès l'ouverture du service."
            : "Votre projet « $t » a bien été enregistré. Réponse sous 48 h.",
            'projet.php?id='.$pid);
        notify($gest, "Nouveau projet à analyser : « $t » (".($u['societe'] ?: $u['nom']).").", 'admin-matching.php?id='.$pid);
        // Alerte sur le téléphone des administrateurs abonnés
        push_alerter_admins("Nouveau projet : " . $t, 'admin-matching.php?id=' . $pid);
        db()->prepare("INSERT INTO messages (projet_id,expediteur_id,destinataire_id,contenu) VALUES (?,1,?,?)")
            ->execute([$pid, $u['id'],
              beta_actif()
                ? "Bonjour, nous avons bien reçu votre projet « $t ». Missiona est actuellement en préinscription : votre demande est enregistrée et sera étudiée en priorité dès l'ouverture du service. Vous serez prévenu par courriel."
                : "Bonjour, nous avons bien reçu votre projet « $t ». Notre équipe analyse votre besoin et revient vers vous sous 48 heures avec une proposition d'expert et une estimation budgétaire."]);
        flash(beta_actif()
            ? "Projet enregistré. Missiona est en préinscription : votre demande sera étudiée dès l'ouverture, et vous serez prévenu en priorité."
            : "Projet envoyé. Notre équipe revient vers vous sous 48 heures.");
        header('Location: ' . u('projet.php?id=' . $pid)); exit;
    }
}

// Jauge de budget : de 0 € au plafond réglé dans config.php, à l'euro près.
// Le clavier permet d'avancer de 1 en 1 une fois le curseur sélectionné ;
// pour un montant précis, un clic sur le prix ouvre une saisie directe.
$bmin  = 0;
$bmax  = max(1000, (int) BUDGET_PLAFOND);
$bdef1 = (int) round($bmax * 0.02);
$bdef2 = (int) round($bmax * 0.10);

$titre = "Nouveau projet";
require_once __DIR__ . '/includes/header.php';
?>
<div class="app">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">

  <div class="wizard">
    <div class="page-head">
      <div>
        <h1>Décrire un nouveau projet</h1>
        <p>5 étapes guidées. Vous n'avez pas besoin de connaître le détail technique.</p>
      </div>
    </div>

    <?php if (beta_actif() && !beta_exempt()): ?>
      <div class="alert alert-bleu mb-3">
        <strong>Missiona est en préinscription.</strong>
        Vous pouvez décrire votre projet dès maintenant : il sera conservé et
        <strong>étudié en priorité dès l'ouverture</strong>. Aucun règlement ne
        vous sera demandé avant.
      </div>
    <?php endif; ?>

    <?php if ($erreur): ?><div class="alert alert-error"><?= e($erreur) ?></div><?php endif; ?>

    <form method="post" id="wizard">
      <?= csrf_field() ?>

      <div class="wizard-bar">
        <div class="wz-step active"><div class="n">1</div><div class="t">Le besoin</div></div>
        <div class="wz-step"><div class="n">2</div><div class="t">Description</div></div>
        <div class="wz-step"><div class="n">3</div><div class="t">Compétences</div></div>
        <div class="wz-step"><div class="n">4</div><div class="t">Budget &amp; délai</div></div>
        <div class="wz-step"><div class="n">5</div><div class="t">Récapitulatif</div></div>
      </div>

      <div class="panel">
        <div class="panel-body">

          <!-- Étape 1 -->
          <div class="wz-panel active">
            <h3 class="mb-1">Quel est votre besoin ?</h3>
            <p class="small muted mb-3">Donnez un intitulé clair et choisissez le domaine concerné.</p>
            <div class="field">
              <label for="titre">Titre du projet *</label>
              <input type="text" id="titre" name="titre" class="input" required
                     placeholder="Ex. Refonte de notre site vitrine corporate">
              <div class="hint">Une phrase suffit. Votre chargé de compte affinera avec vous.</div>
            </div>
            <div class="field">
              <label for="categorie">Domaine *</label>
              <select id="categorie" name="categorie" class="select" required>
                <option value="">Sélectionner un domaine…</option>
                <?php foreach (domaines_projet() as $c): ?>
                  <option value="<?= e($c) ?>"><?= e($c) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <!-- Étape 2 -->
          <div class="wz-panel">
            <h3 class="mb-1">Décrivez le projet</h3>
            <p class="small muted mb-3">Contexte, objectif attendu et contraintes éventuelles. Pas de jargon nécessaire.</p>
            <div class="field">
              <label for="description">Description détaillée *</label>
              <textarea id="description" name="description" class="textarea" required data-counter="cnt"
                        placeholder="Quel problème cherchez-vous à résoudre ? Qui utilisera le résultat ? Quels sont vos critères de réussite ?"></textarea>
              <div class="hint" id="cnt">0 caractères</div>
            </div>
            <div class="alert alert-info" style="margin:0">
              💡 Plus votre description est précise, plus notre proposition sera juste dès le premier échange.
            </div>
          </div>

          <!-- Étape 3 -->
          <div class="wz-panel">
            <h3 class="mb-1">Compétences attendues</h3>
            <p class="small muted mb-3">Si vous ne savez pas, passez cette étape : nous les déterminerons pour vous.</p>
            <div class="field">
              <?php champ_competences(''); ?>
              <div class="hint">Cliquez pour sélectionner. Ces compétences alimentent notre moteur de matching.</div>
            </div>
          </div>

          <!-- Étape 4 -->
          <div class="wz-panel">
            <h3 class="mb-1">Budget et délai</h3>
            <p class="small muted mb-3">Une fourchette indicative suffit. Le devis ferme sera établi après cadrage.</p>
            <div class="field">
              <label>Fourchette budgétaire</label>

              <div class="range-wrap" id="budgetRange">
                <div class="range-values">
                  <div class="range-val">
                    <span class="range-lbl">Minimum</span>
                    <button type="button" class="range-prix" id="budgetMinTxt"
                            data-cible="budget_min" data-suivi-non
                            title="Cliquez pour saisir le montant exact"><?= euros($bdef1) ?></button>
                  </div>
                  <div class="range-val" style="text-align:right">
                    <span class="range-lbl">Maximum</span>
                    <button type="button" class="range-prix" id="budgetMaxTxt"
                            data-cible="budget_max" data-suivi-non
                            title="Cliquez pour saisir le montant exact"><?= euros($bdef2) ?></button>
                  </div>
                </div>

                <?php
                  // La valeur envoyée est celle des champs cachés : elle peut
                  // être n'importe quel montant. Les curseurs ne servent qu'au
                  // réglage à la main, avec un pas confortable.
                ?>
                <input type="hidden" name="budget_min" id="budget_min" value="<?= $bdef1 ?>">
                <input type="hidden" name="budget_max" id="budget_max" value="<?= $bdef2 ?>">

                <div class="range-track">
                  <div class="range-fill" id="budgetFill"></div>
                  <input type="range" id="rgMin" min="<?= $bmin ?>" max="<?= $bmax ?>" step="1" value="<?= $bdef1 ?>" aria-label="Budget minimum">
                  <input type="range" id="rgMax" min="<?= $bmin ?>" max="<?= $bmax ?>" step="1" value="<?= $bdef2 ?>" aria-label="Budget maximum">
                </div>

                <div class="range-scale">
                  <?php for ($i = 0; $i <= 4; $i++): $v = (int) round($bmax * $i / 4); ?>
                    <span><?= euros($v) ?><?= $i === 4 ? '+' : '' ?></span>
                  <?php endfor; ?>
                </div>
              </div>

              <div class="hint">Faites glisser les curseurs, ou cliquez sur un montant
              pour saisir le chiffre exact, à l'euro près. Une fois un curseur
              sélectionné, les flèches du clavier l'avancent de 1 en 1.
              Fourchette possible : de <?= euros($bmin) ?> à <?= euros($bmax) ?>.</div>
            </div>
            <div class="field-row">
              <div class="field">
                <label for="delai">Durée souhaitée</label>
                <select id="delai" name="delai" class="select">
                  <option value="">Sélectionner…</option>
                  <?php foreach (['Moins de 1 mois','1 mois','2 mois','3 mois','4 mois','6 mois','Plus de 6 mois','Récurrent'] as $d): ?>
                    <option><?= $d ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="field">
                <label for="date_limite">Date de livraison souhaitée</label>
                <input type="date" id="date_limite" name="date_limite" class="input">
              </div>
            </div>
            <div class="alert alert-warn" style="margin:0">
              La publication du projet et l'étude sont gratuites. Aucun engagement à ce stade.
            </div>
          </div>

          <!-- Étape 5 -->
          <div class="wz-panel">
            <h3 class="mb-1">Récapitulatif</h3>
            <p class="small muted mb-3">Vérifiez les informations avant envoi à notre équipe.</p>
            <div class="recap" id="recapBox"></div>
            <div class="alert alert-info mt-3" style="margin-bottom:0">
              ✅ Après envoi, votre chargé de compte analyse le besoin et vous répond sous 48 heures ouvrées
              avec un profil d'expert recommandé et une estimation budgétaire.
            </div>
          </div>

        </div>
      </div>

      <div class="wz-nav">
        <button type="button" class="btn btn-ghost" id="wzPrev">← Précédent</button>
        <div style="display:flex;gap:10px">
          <a href="/dashboard-entreprise" class="btn btn-ghost">Annuler</a>
          <button type="button" class="btn btn-primary" id="wzNext">Continuer →</button>
          <button type="submit" class="btn btn-primary" id="wzSubmit" style="display:none">Envoyer le projet</button>
        </div>
      </div>
    </form>
  </div>

</main>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
