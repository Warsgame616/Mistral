<?php
require_once __DIR__ . '/includes/functions.php';
if (is_logged()) { header('Location: ' . dashboard_url(null, true)); exit; }

$erreur = '';
$role_pre = in_array($_GET['role'] ?? '', ['entreprise','particulier','freelance'], true) ? $_GET['role'] : 'entreprise';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $role  = in_array($_POST['role'] ?? '', ['entreprise','particulier','freelance'], true) ? $_POST['role'] : '';
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';
    $nom   = trim($_POST['nom'] ?? '');
    $prenom= trim($_POST['prenom'] ?? '');

    if (!$role)                                        { $erreur = "Veuillez choisir un type de compte."; }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)){ $erreur = "Adresse e-mail invalide."; }
    elseif (strlen($pass) < 6)                         { $erreur = "Le mot de passe doit contenir au moins 6 caractères."; }
    elseif ($pass !== ($_POST['password2'] ?? ''))     { $erreur = "Les deux mots de passe ne correspondent pas."; }
    elseif (!$nom)                                     { $erreur = "Le nom est obligatoire."; }
    elseif (empty($_POST['rgpd']))                     { $erreur = "Vous devez accepter la politique de confidentialité."; }
    else {
        $st = db()->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $st->execute([$email]);
        if ($st->fetchColumn()) {
            $erreur = "Un compte existe déjà avec cette adresse e-mail.";
        } else {
            db()->prepare("INSERT INTO users
                (email,password_hash,role,nom,prenom,telephone,societe,siret,secteur,taille,titre_pro,bio,competences,tarif_projet,experience,disponibilite)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
              ->execute([
                $email, password_hash($pass, PASSWORD_DEFAULT), $role, $nom, $prenom,
                trim($_POST['telephone'] ?? ''),
                trim($_POST['societe'] ?? ''), trim($_POST['siret'] ?? ''),
                trim($_POST['secteur'] ?? ''), trim($_POST['taille'] ?? ''),
                trim($_POST['titre_pro'] ?? ''), trim($_POST['bio'] ?? ''),
                trim($_POST['competences'] ?? ''),
                (int)($_POST['tarif_projet'] ?? 0), (int)($_POST['experience'] ?? 0),
                $_POST['disponibilite'] ?? 'disponible',
              ]);
            $uid = db()->lastInsertId();
            if (in_array($role, ['entreprise','particulier'], true)) { auto_assigner_client($uid); }
            notify($uid, "Bienvenue sur Missiona. Votre chargé de compte vous contactera sous 48 h.", 'index.php');
            notify(admin_id(), "Nouvelle inscription : " . $nom . " (" . $role . ").", 'admin.php');
            email_bienvenue($email, $prenom ?: $nom, $role);
            push_apres_inscription();
            header('Location: ' . u('/connexion?inscrit=1')); exit;
        }
    }
    $role_pre = $role ?: $role_pre;
}

$titre = "Créer un compte";
$page  = 'inscription';
require_once __DIR__ . '/includes/header.php';
?>

<div class="auth-wrap">
  <div class="auth-card" style="max-width:560px">
    <h1>Créer un compte</h1>
    <p>Quelques informations pour démarrer. Cela prend moins de 3 minutes.</p>

    <?php if ($erreur): ?><div class="alert alert-error"><?= e($erreur) ?></div><?php endif; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <input type="hidden" name="role" id="role" value="<?= e($role_pre) ?>">

      <label class="strong small mb-1" style="display:block">Je suis…</label>
      <div class="role-grid role-grid-3">
        <div class="role-opt <?= $role_pre==='entreprise'?'selected':'' ?>" data-target="role" data-value="entreprise">
          <div class="ico">🏢</div><strong>Une entreprise</strong><span>Je veux faire réaliser un projet</span>
        </div>
        <div class="role-opt <?= $role_pre==='particulier'?'selected':'' ?>" data-target="role" data-value="particulier">
          <div class="ico">🙋</div><strong>Un particulier</strong><span>J'ai un projet personnel</span>
        </div>
        <div class="role-opt <?= $role_pre==='freelance'?'selected':'' ?>" data-target="role" data-value="freelance">
          <div class="ico">👩‍💻</div><strong>Un freelance</strong><span>Je veux recevoir des missions</span>
        </div>
      </div>

      <div class="field-row">
        <div class="field">
          <label for="prenom">Prénom</label>
          <input type="text" id="prenom" name="prenom" class="input" value="<?= e($_POST['prenom'] ?? '') ?>">
        </div>
        <div class="field">
          <label for="nom">Nom *</label>
          <input type="text" id="nom" name="nom" class="input" required value="<?= e($_POST['nom'] ?? '') ?>">
        </div>
      </div>

      <div class="field">
        <label for="email">Adresse e-mail *</label>
        <input type="email" id="email" name="email" class="input" required value="<?= e($_POST['email'] ?? '') ?>">
      </div>

      <div class="field">
        <label for="telephone">Téléphone</label>
        <input type="tel" id="telephone" name="telephone" class="input" value="<?= e($_POST['telephone'] ?? '') ?>">
      </div>

      <!-- Bloc entreprise -->
      <div data-role-block="entreprise" style="<?= $role_pre==='entreprise'?'':'display:none' ?>">
        <div class="field">
          <label for="societe">Nom de l'entreprise</label>
          <input type="text" id="societe" name="societe" class="input" value="<?= e($_POST['societe'] ?? '') ?>">
        </div>
        <div class="field">
          <label for="taille">Effectif</label>
          <select id="taille" name="taille" class="select">
            <option value="">Sélectionner…</option>
            <?php foreach (['1-10','10-50','50-200','200-1000','1000+'] as $t): ?>
              <option <?= ($_POST['taille'] ?? '')===$t?'selected':'' ?>><?= $t ?> salariés</option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <!-- Bloc particulier : aucun champ supplémentaire -->
      <div data-role-block="particulier" style="<?= $role_pre==='particulier'?'':'display:none' ?>">
        <div class="alert alert-info" style="margin-bottom:18px">
          🙋 En tant que particulier, vous décrivez simplement votre projet : notre équipe s'occupe de tout le reste.
        </div>
      </div>

      <!-- Bloc freelance -->
      <div data-role-block="freelance" style="<?= $role_pre==='freelance'?'':'display:none' ?>">
        <div class="field">
          <label for="titre_pro">Titre professionnel</label>
          <input type="text" id="titre_pro" name="titre_pro" class="input"
                 placeholder="Ex. Développeuse Full-Stack" value="<?= e($_POST['titre_pro'] ?? '') ?>">
        </div>
        <div class="field">
          <label for="bio">Présentation</label>
          <textarea id="bio" name="bio" class="input" rows="5"
                    placeholder="Décrivez votre parcours, vos domaines de spécialité et le type de missions qui vous intéresse."><?= e($_POST['bio'] ?? '') ?></textarea>
          <div class="hint">Quelques lignes suffisent. Notre équipe s'appuie dessus pour vous proposer les bonnes missions.</div>
        </div>
        <div class="field">
          <label>Vos compétences</label>
          <?php champ_competences($_POST['competences'] ?? ''); ?>
          <div class="hint">Cliquez pour sélectionner toutes vos compétences, dans un ou plusieurs domaines.</div>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="tarif_projet">Tarif par projet (€)</label>
            <input type="number" id="tarif_projet" name="tarif_projet" class="input" min="0" step="1" placeholder="Ex. 2000" value="<?= e($_POST['tarif_projet'] ?? '') ?>">
            <div class="hint">Ce que vous facturez pour une journée de travail.</div>
          </div>
          <div class="field">
            <label for="experience">Années d'expérience</label>
            <input type="number" id="experience" name="experience" class="input" min="0" max="50" value="<?= e($_POST['experience'] ?? '') ?>">
          </div>
        </div>
        <div class="field">
          <label for="disponibilite">Disponibilité</label>
          <select id="disponibilite" name="disponibilite" class="select">
            <option value="disponible">Disponible immédiatement</option>
            <option value="partiel">Partiellement disponible</option>
            <option value="occupe">Actuellement en mission</option>
          </select>
        </div>
      </div>

      <div class="field-row">
        <div class="field">
          <label for="password">Mot de passe *</label>
          <input type="password" id="password" name="password" class="input" required minlength="6">
          <div class="hint">6 caractères minimum.</div>
        </div>
        <div class="field">
          <label for="password2">Confirmation *</label>
          <input type="password" id="password2" name="password2" class="input" required minlength="6">
        </div>
      </div>

      <label class="check mb-3">
        <input type="checkbox" name="rgpd" value="1" required>
        <span>J'accepte les <a href="/mentions#cgu" style="color:var(--blue)">conditions générales</a> et la
        <a href="/mentions#rgpd" style="color:var(--blue)">politique de confidentialité</a>. Mes données sont utilisées uniquement
        dans le cadre de la mise en relation et du suivi de projet (RGPD).</span>
      </label>

      <button type="submit" class="btn btn-primary btn-block btn-lg">Créer mon compte</button>
    </form>
    <?php if (google_actif()): ?>
      <div class="sep-ou"><span>ou</span></div>
      <a class="btn btn-google btn-block" href="<?= e(google_url_auth($role_pre)) ?>">
        <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true" focusable="false">
          <path fill="#4285F4" d="M45.1 24.5c0-1.6-.1-2.8-.4-4H24v7.3h12.1c-.2 2-1.6 5-4.5 7l-.1.3 6.5 5 .5.1c4.1-3.8 6.6-9.4 6.6-15.7"/>
          <path fill="#34A853" d="M24 46c5.9 0 10.9-1.9 14.5-5.3l-6.9-5.3c-1.8 1.3-4.3 2.2-7.6 2.2-5.8 0-10.7-3.8-12.5-9l-.3.1-6.7 5.2-.1.3C7.9 41.1 15.4 46 24 46"/>
          <path fill="#FBBC05" d="M11.5 28.6c-.5-1.4-.7-2.9-.7-4.6s.3-3.2.7-4.6v-.3l-6.8-5.3-.2.1C2.9 16.9 2 20.3 2 24s.9 7.1 2.5 10.1l7-5.5"/>
          <path fill="#EB4335" d="M24 10.7c4.1 0 6.9 1.8 8.5 3.3l6.2-6C34.9 4.5 29.9 2 24 2 15.4 2 7.9 6.9 4.5 13.9l7 5.5c1.8-5.2 6.7-8.7 12.5-8.7"/>
        </svg>
        <span>S'inscrire avec Google</span>
      </a>
    <?php endif; ?>


    <div class="auth-alt">Déjà inscrit ? <a href="/connexion">Se connecter</a></div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
