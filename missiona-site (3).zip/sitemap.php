<?php
/**
 * Sitemap XML généré depuis le catalogue seo_pages().
 * Ajouter une page publique dans includes/seo.php suffit à l'y faire figurer.
 */
require_once __DIR__ . '/includes/seo.php';

header('Content-Type: application/xml; charset=UTF-8');

/** Priorité et fréquence par page, selon son importance réelle. */
$reglages = [
    'accueil'     => ['1.0', 'weekly'],
    'entreprises' => ['0.9', 'monthly'],
    'freelances'  => ['0.9', 'monthly'],
    'services'    => ['0.8', 'monthly'],
    'tarifs'      => ['0.8', 'monthly'],
    'faq'         => ['0.7', 'monthly'],
    'a-propos'    => ['0.6', 'yearly'],
    'contact'     => ['0.6', 'yearly'],
    'inscription' => ['0.5', 'yearly'],
    'connexion'   => ['0.3', 'yearly'],
    'mentions'    => ['0.2', 'yearly'],
];

// Date de dernière modification réelle du fichier correspondant
$fichiers = [
    'accueil'     => 'index.php',
    'entreprises' => 'entreprises.php',
    'freelances'  => 'freelances.php',
    'services'    => 'services.php',
    'tarifs'      => 'tarifs.php',
    'faq'         => 'faq.php',
    'a-propos'    => 'a-propos.php',
    'contact'     => 'contact.php',
    'inscription' => 'inscription.php',
    'connexion'   => 'connexion.php',
    'mentions'    => 'mentions.php',
];

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

foreach (seo_pages() as $cle => $p) {
    [$prio, $freq] = $reglages[$cle] ?? ['0.5', 'monthly'];
    $f    = __DIR__ . '/' . ($fichiers[$cle] ?? '');
    $date = is_file($f) ? date('Y-m-d', filemtime($f)) : date('Y-m-d');
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars(seo_url($p['path']), ENT_XML1) . "</loc>\n";
    echo "    <lastmod>{$date}</lastmod>\n";
    echo "    <changefreq>{$freq}</changefreq>\n";
    echo "    <priority>{$prio}</priority>\n";
    echo "  </url>\n";
}

echo '</urlset>' . "\n";
