<?php
/**
 * Missiona — métadonnées SEO centralisées.
 *
 * Chaque page publique déclare $page (clé ci-dessous) avant d'inclure header.php.
 * Les pages privées (espace connecté, back-office) sont marquées noindex
 * automatiquement : elles n'ont rien à faire dans l'index de Google.
 */

/** Adresse publique du site, sans barre oblique finale. */
// SITE_URL est défini dans config.php (repli ici si le fichier est absent).
if (!defined('SITE_URL')) { define('SITE_URL', 'https://missiona.eu'); }

/**
 * Catalogue des pages publiques.
 * 'title'       ≤ 60 caractères, mot-clé principal en tête
 * 'description' 150-160 caractères, incitative, avec le mot-clé
 * 'path'        URL canonique (sans .php, voir la réécriture .htaccess)
 */
function seo_pages() {
    return [
        'accueil' => [
            'title'       => "Déléguer vos projets digitaux sans les gérer",
            'description' => "Vous décrivez le projet, on livre le résultat. Nous sélectionnons et pilotons les freelances à votre place, avec un budget fixé à l'avance.",
            'path'        => '/',
        ],
        'entreprises' => [
            'title'       => "Sous-traiter vos projets web sereinement",
            'description' => "Confiez vos projets digitaux à une équipe qui recrute et pilote les experts pour vous. Devis sous 48 h, budget validé avant démarrage.",
            'path'        => '/entreprises',
        ],
        'freelances' => [
            'title'       => "Missions freelance sans prospection",
            'description' => "Recevez des missions cadrées et payées au juste prix. Missiona gère la prospection, le cadrage et la facturation : vous vous concentrez sur votre métier.",
            'path'        => '/freelances',
        ],
        'services' => [
            'title'       => "Nos expertises : web, mobile, design et data",
            'description' => "Développement web et mobile, design, data et marketing digital : les domaines couverts par notre réseau d'experts sélectionnés.",
            'path'        => '/services',
        ],
        'tarifs' => [
            'title'       => "Tarifs : combien coûte un projet délégué",
            'description' => "Vous réglez l'expert directement, au prix convenu. Missiona ne vous facture aucun supplément : notre rémunération est facturée à l'expert. Tarification transparente, sans abonnement ni coût caché.",
            'path'        => '/tarifs',
        ],
        'a-propos' => [
            'title'       => "Qui sommes-nous",
            'description' => "Notre méthode de sélection des freelances, nos engagements et notre façon de piloter les projets. Découvrez comment nous travaillons.",
            'path'        => '/a-propos',
        ],
        'contact' => [
            'title'       => "Contact : parlons de votre projet",
            'description' => "Décrivez votre besoin en quelques lignes : notre équipe revient vers vous sous 48 heures avec une estimation de budget et de délai, sans engagement.",
            'path'        => '/contact',
        ],
        'faq' => [
            'title'       => "Questions fréquentes",
            'description' => "Délais, budgets, propriété du code, confidentialité : les réponses aux questions que posent nos clients avant de lancer un projet.",
            'path'        => '/faq',
        ],
        'mentions' => [
            'title'       => "Mentions légales",
            'description' => "Informations légales, éditeur du site, hébergement et traitement des données personnelles de la plateforme Missiona.",
            'path'        => '/mentions',
        ],
        'connexion' => [
            'title'       => "Connexion à votre espace client",
            'description' => "Accédez à votre espace Missiona pour suivre l'avancement de vos projets, échanger avec votre gestionnaire et consulter vos documents.",
            'path'        => '/connexion',
        ],
        'inscription' => [
            'title'       => "Créer un compte entreprise ou freelance",
            'description' => "Ouvrez votre compte en moins de trois minutes pour déposer un projet ou rejoindre notre réseau d'experts. Gratuit et sans engagement.",
            'path'        => '/inscription',
        ],
    ];
}

/** Métadonnées de la page courante, avec repli propre. */
function seo_meta($page) {
    $pages = seo_pages();
    if (isset($pages[$page])) { return $pages[$page]; }
    return [
        'title'       => '',
        'description' => "Missiona : vous décrivez le projet, on livre le résultat. Des freelances sélectionnés et pilotés par notre équipe, pour un livrable garanti.",
        'path'        => null,
        'noindex'     => true,
    ];
}

/** Une page privée ne doit jamais être indexée. */
function seo_est_privee($page) {
    return !array_key_exists($page, seo_pages());
}

/** URL absolue à partir d'un chemin canonique. */
function seo_url($path) {
    return SITE_URL . ($path === '/' ? '/' : rtrim($path, '/'));
}
