<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <a href="/" class="logo mb-2"><img class="logo-mark" src="<?= asset('assets/img/mark.svg') ?>" alt="" width="32" height="32"> Missiona</a>
        <p class="small" style="max-width:300px">Vous décrivez le projet, on livre le résultat. Notre équipe sélectionne, pilote et garantit l'exécution de vos projets par des freelances qualifiés.</p>
      </div>
      <div>
        <h5>Plateforme</h5>
        <ul>
          <li><a href="/entreprises">Pour les entreprises</a></li>
          <li><a href="/freelances">Pour les freelances</a></li>
          <li><a href="/services">Nos expertises</a></li>
          <li><a href="/a-propos">Qui sommes-nous</a></li>
          <li><a href="/contact">Nous contacter</a></li>
          <li><a href="/a-propos">Notre méthode de sélection</a></li>
          <?php if (!beta_lien_masque('/tarifs')): ?><li><a href="/tarifs">Tarifs et devis</a></li><?php endif; ?>
        </ul>
      </div>
      <div>
        <h5>Ressources</h5>
        <ul>
          <li><a href="/faq">Questions fréquentes</a></li>
          <li><a href="/inscription">Créer un compte</a></li>
          <li><a href="/connexion">Se connecter</a></li>
        </ul>
      </div>
      <div>
        <h5>Légal</h5>
        <ul>
          <li><a href="/mentions">Mentions légales</a></li>
          <li><a href="/mentions#cgu">CGU / CGV</a></li>
          <li><a href="/mentions#rgpd">Confidentialité / RGPD</a></li>
          <li><a href="/mentions#cookies">Cookies</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© <?= date('Y') ?> Missiona — Tous droits réservés.</span>
      <span>Conçu en France 🇫🇷</span>
    </div>
  </div>
</footer>

<script src="<?= asset('assets/js/app.js') ?>" defer></script>
</body>
</html>
