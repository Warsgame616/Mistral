<?php
/**
 * Missiona — Mesure d'audience interne
 * ------------------------------------------------------------------
 * Aucun service externe : tout est enregistré dans la base du site.
 *
 * Choix imposés par le RGPD et la position de la CNIL sur la mesure
 * d'audience (exemption de consentement) :
 *   - l'adresse IP n'est JAMAIS stockée en clair, seulement un condensé
 *     salé et tronqué, qui sert uniquement à distinguer deux visiteurs ;
 *   - le sel change chaque jour : impossible de suivre quelqu'un d'un
 *     jour sur l'autre, donc pas de profilage ;
 *   - aucune donnée n'est transmise à un tiers, aucun recoupement entre
 *     sites, pas de publicité ;
 *   - les données sont purgées automatiquement (13 mois par défaut).
 *
 * Ces conditions réunies, la CNIL dispense la mesure d'audience de
 * bandeau de consentement. Elles doivent le rester.
 */

/** Durée de conservation, en jours. */
function stats_retention() { return (int) param('stats_retention', 395); }

/** La mesure est-elle activée ? */
function stats_actif() { return (int) param('stats_actif', 1) === 1; }

/**
 * Identifiant de visiteur : condensé du couple IP + navigateur, salé
 * avec une valeur qui change chaque jour. Permet de compter des
 * visiteurs distincts sans jamais pouvoir remonter à une personne.
 */
function stats_visiteur_id() {
    static $id = null;
    if ($id !== null) { return $id; }

    $sel = param('stats_sel', '');
    if ($sel === '') { $sel = bin2hex(random_bytes(16)); set_param('stats_sel', $sel); }

    $brut = ($_SERVER['REMOTE_ADDR'] ?? '')
          . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '')
          . '|' . date('Y-m-d')   // le sel tourne chaque jour
          . '|' . $sel;

    return $id = substr(hash('sha256', $brut), 0, 16);
}

/** Type d'appareil, déduit de façon grossière mais suffisante. */
function stats_appareil() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '') { return 'inconnu'; }
    if (preg_match('/ipad|tablet|playbook|silk/', $ua))                 { return 'tablette'; }
    if (preg_match('/mobile|iphone|android|ipod|blackberry/', $ua))     { return 'mobile'; }
    return 'ordinateur';
}

/** Robots d'indexation : comptés à part, jamais mélangés aux humains. */
function stats_est_robot() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '') { return true; }
    return (bool) preg_match(
        '/bot|crawl|spider|slurp|bingpreview|facebookexternalhit|preview|monitor|curl|wget|python|headless|lighthouse/',
        $ua);
}

/** Origine du visiteur, réduite au nom de domaine. */
function stats_source() {
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    if ($ref === '') { return 'direct'; }
    $h = parse_url($ref, PHP_URL_HOST);
    if (!$h) { return 'direct'; }
    $h = preg_replace('/^www\./', '', strtolower($h));
    $site = preg_replace('/^www\./', '', strtolower($_SERVER['HTTP_HOST'] ?? ''));
    if ($h === $site) { return 'interne'; }
    if (preg_match('/google|bing|duckduckgo|qwant|ecosia|yahoo/', $h)) { return 'recherche'; }
    return $h;
}

/**
 * Enregistre une page vue. Appelé automatiquement par l'en-tête.
 * Silencieux par construction : la mesure ne doit jamais casser le site.
 */
function stats_visite($chemin = null) {
    if (!stats_actif()) { return; }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') { return; }

    try {
        $chemin = $chemin ?? parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $chemin = '/' . ltrim((string) $chemin, '/');
        if (strlen($chemin) > 200) { $chemin = substr($chemin, 0, 200); }

        $uid = null;
        if (function_exists('user')) { $x = user(); $uid = $x['id'] ?? null; }

        db()->prepare(
            "INSERT INTO visites (visiteur, user_id, chemin, source, appareil, robot, created_at)
             VALUES (?,?,?,?,?,?,datetime('now'))"
        )->execute([
            stats_visiteur_id(), $uid, $chemin,
            substr(stats_source(), 0, 100), stats_appareil(),
            stats_est_robot() ? 1 : 0,
        ]);

        stats_purge_occasionnelle();
    } catch (Throwable $e) {
        // Une mesure d'audience ne justifie jamais une page en erreur.
    }
}

/**
 * Enregistre une action : clic sur un bouton, envoi d'un formulaire…
 * @param string $type   famille d'action (clic, formulaire, telechargement…)
 * @param string $cible  identifiant lisible de l'élément
 */
function stats_action($type, $cible, $detail = '') {
    if (!stats_actif()) { return; }
    try {
        $uid = null;
        if (function_exists('user')) { $x = user(); $uid = $x['id'] ?? null; }

        db()->prepare(
            "INSERT INTO evenements (visiteur, user_id, type, cible, detail, chemin, created_at)
             VALUES (?,?,?,?,?,?,datetime('now'))"
        )->execute([
            stats_visiteur_id(), $uid,
            substr((string) $type, 0, 40),
            substr((string) $cible, 0, 120),
            substr((string) $detail, 0, 200),
            substr((string) (parse_url($_SERVER['HTTP_REFERER'] ?? '', PHP_URL_PATH) ?: ''), 0, 200),
        ]);
    } catch (Throwable $e) {
        // idem : jamais bloquant
    }
}

/** Purge des données trop anciennes, déclenchée de loin en loin. */
function stats_purge_occasionnelle() {
    if (random_int(1, 200) !== 1) { return; }
    stats_purge();
}

function stats_purge() {
    $j = max(30, stats_retention());
    try {
        db()->exec("DELETE FROM visites    WHERE created_at < datetime('now','-" . $j . " days')");
        db()->exec("DELETE FROM evenements WHERE created_at < datetime('now','-" . $j . " days')");
    } catch (Throwable $e) {}
}

/* ==================================================================
 *  Lectures pour le tableau de bord
 * ================================================================== */

/** Filtre SQL commun : humains uniquement, sur N jours. */
function stats_ou($jours, $table = 'visites') {
    $j = max(1, (int) $jours);
    $robot = ($table === 'visites') ? " AND robot = 0" : "";
    return " WHERE created_at >= datetime('now','-" . $j . " days')" . $robot;
}

/** Chiffres clés de la période. */
function stats_resume($jours = 30) {
    $o = stats_ou($jours);
    $r = db()->query("SELECT COUNT(*) pages, COUNT(DISTINCT visiteur) visiteurs,
                             COUNT(DISTINCT user_id) connectes
                      FROM visites" . $o)->fetch() ?: [];
    $r['actions'] = (int) db()->query("SELECT COUNT(*) FROM evenements" . stats_ou($jours, 'evenements'))->fetchColumn();
    $r['robots']  = (int) db()->query("SELECT COUNT(*) FROM visites
                                       WHERE created_at >= datetime('now','-" . max(1, (int) $jours) . " days')
                                       AND robot = 1")->fetchColumn();
    $r['pages']     = (int) ($r['pages'] ?? 0);
    $r['visiteurs'] = (int) ($r['visiteurs'] ?? 0);
    $r['connectes'] = (int) ($r['connectes'] ?? 0);
    $r['par_visiteur'] = $r['visiteurs'] > 0 ? round($r['pages'] / $r['visiteurs'], 1) : 0;
    return $r;
}

/** Série journalière, sans trou : les jours sans visite valent zéro. */
function stats_par_jour($jours = 30) {
    $j = max(1, (int) $jours);
    $brut = [];
    foreach (db()->query("SELECT date(created_at) d, COUNT(*) pages,
                                 COUNT(DISTINCT visiteur) visiteurs
                          FROM visites" . stats_ou($j) . "
                          GROUP BY d") as $r) {
        $brut[$r['d']] = $r;
    }
    $out = [];
    for ($i = $j - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i days"));
        $out[] = [
            'date'      => $d,
            'pages'     => (int) ($brut[$d]['pages'] ?? 0),
            'visiteurs' => (int) ($brut[$d]['visiteurs'] ?? 0),
        ];
    }
    return $out;
}

function stats_top_pages($jours = 30, $n = 12) {
    $st = db()->prepare("SELECT chemin, COUNT(*) n, COUNT(DISTINCT visiteur) v
                         FROM visites" . stats_ou($jours) . "
                         GROUP BY chemin ORDER BY n DESC LIMIT ?");
    $st->execute([(int) $n]);
    return $st->fetchAll();
}

function stats_top_actions($jours = 30, $n = 15) {
    $st = db()->prepare("SELECT type, cible, COUNT(*) n
                         FROM evenements" . stats_ou($jours, 'evenements') . "
                         GROUP BY type, cible ORDER BY n DESC LIMIT ?");
    $st->execute([(int) $n]);
    return $st->fetchAll();
}

function stats_repartition($colonne, $jours = 30, $n = 8) {
    $col = in_array($colonne, ['appareil', 'source'], true) ? $colonne : 'appareil';
    $st = db()->prepare("SELECT $col AS k, COUNT(*) n FROM visites" . stats_ou($jours) . "
                         GROUP BY k ORDER BY n DESC LIMIT ?");
    $st->execute([(int) $n]);
    return $st->fetchAll();
}

function stats_par_heure($jours = 7) {
    $out = array_fill(0, 24, 0);
    foreach (db()->query("SELECT CAST(strftime('%H', created_at) AS INTEGER) h, COUNT(*) n
                          FROM visites" . stats_ou($jours) . " GROUP BY h") as $r) {
        $out[(int) $r['h']] = (int) $r['n'];
    }
    return $out;
}

/* ==================================================================
 *  Graphiques : SVG produit côté serveur
 *  Aucune bibliothèque, aucun script : le rendu fonctionne même si
 *  le JavaScript est désactivé.
 * ================================================================== */

/** Courbe d'évolution à deux séries. */
function svg_courbe(array $points, $cle1 = 'pages', $cle2 = 'visiteurs', $h = 220) {
    $n = count($points);
    if ($n === 0) { return '<p class="muted small">Aucune donnée.</p>'; }

    $L = 820; $pad_g = 46; $pad_d = 14; $pad_h = 16; $pad_b = 34;
    $iw = $L - $pad_g - $pad_d;
    $ih = $h - $pad_h - $pad_b;

    $max = 1;
    foreach ($points as $p) { $max = max($max, (int) $p[$cle1], (int) $p[$cle2]); }
    $max = (int) (ceil($max / 5) * 5) ?: 5;

    $x = fn($i) => $pad_g + ($n <= 1 ? $iw / 2 : $i * $iw / ($n - 1));
    $y = fn($v) => $pad_h + $ih - ($v / $max) * $ih;

    $s = '<svg viewBox="0 0 ' . $L . ' ' . $h . '" class="chart" role="img" '
       . 'aria-label="Évolution de la fréquentation" preserveAspectRatio="xMidYMid meet">';

    // Grille horizontale et échelle
    for ($g = 0; $g <= 4; $g++) {
        $v  = $max * $g / 4;
        $yy = $y($v);
        $s .= '<line x1="' . $pad_g . '" y1="' . round($yy, 1) . '" x2="' . ($L - $pad_d)
            . '" y2="' . round($yy, 1) . '" stroke="#e9ecef" stroke-width="1"/>';
        $s .= '<text x="' . ($pad_g - 8) . '" y="' . round($yy + 4, 1)
            . '" text-anchor="end" font-size="11" fill="#8a9099">' . round($v) . '</text>';
    }

    $chemin = function ($cle) use ($points, $x, $y) {
        $d = '';
        foreach ($points as $i => $p) {
            $d .= ($i === 0 ? 'M' : 'L') . round($x($i), 1) . ' ' . round($y((int) $p[$cle]), 1) . ' ';
        }
        return trim($d);
    };

    // Aire sous la courbe principale
    $aire = $chemin($cle1) . ' L' . round($x($n - 1), 1) . ' ' . round($y(0), 1)
          . ' L' . round($x(0), 1) . ' ' . round($y(0), 1) . ' Z';
    $s .= '<path d="' . $aire . '" fill="#2f6df6" fill-opacity="0.08"/>';
    $s .= '<path d="' . $chemin($cle1) . '" fill="none" stroke="#2f6df6" stroke-width="2.2" '
        . 'stroke-linejoin="round" stroke-linecap="round"/>';
    $s .= '<path d="' . $chemin($cle2) . '" fill="none" stroke="#12a150" stroke-width="2" '
        . 'stroke-dasharray="5 4" stroke-linejoin="round"/>';

    // Dates : quelques repères seulement, pour rester lisible
    $pas = max(1, (int) ceil($n / 8));
    foreach ($points as $i => $p) {
        if ($i % $pas !== 0 && $i !== $n - 1) { continue; }
        $s .= '<text x="' . round($x($i), 1) . '" y="' . ($h - 12)
            . '" text-anchor="middle" font-size="11" fill="#8a9099">'
            . date('d/m', strtotime($p['date'])) . '</text>';
    }

    // Valeur du dernier point
    $s .= '<circle cx="' . round($x($n - 1), 1) . '" cy="' . round($y((int) $points[$n - 1][$cle1]), 1)
        . '" r="3.5" fill="#2f6df6"/>';
    $s .= '</svg>';
    return $s;
}

/**
 * Troncature sûre : mbstring n'est pas installé partout, et couper
 * un texte UTF-8 au milieu d'un caractère produit des losanges noirs.
 */
function stats_tronquer($texte, $max = 42) {
    $t = (string) $texte;
    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        return mb_strlen($t, 'UTF-8') <= $max ? $t : mb_substr($t, 0, $max - 1, 'UTF-8') . '…';
    }
    if (strlen($t) <= $max) { return $t; }
    $c = substr($t, 0, $max - 1);
    // Ne pas laisser un octet de continuation orphelin en fin de chaîne.
    while ($c !== '' && (ord($c[strlen($c) - 1]) & 0xC0) === 0x80) { $c = substr($c, 0, -1); }
    if ($c !== '' && (ord($c[strlen($c) - 1]) & 0xC0) === 0xC0) { $c = substr($c, 0, -1); }
    return $c . '…';
}

/** Barres horizontales, pour les classements. */
function svg_barres(array $lignes, $cle_lib, $cle_val, $max_lignes = 10) {
    $lignes = array_slice($lignes, 0, $max_lignes);
    if (!$lignes) { return '<p class="muted small">Aucune donnée.</p>'; }

    $max = 1;
    foreach ($lignes as $l) { $max = max($max, (int) $l[$cle_val]); }

    $out = '<div class="barres">';
    foreach ($lignes as $l) {
        $pct = round((int) $l[$cle_val] / $max * 100, 1);
        $lib = (string) $l[$cle_lib];
        if ($lib === '') { $lib = '(vide)'; }
        $out .= '<div class="barre-l">'
              . '<div class="barre-t" title="' . htmlspecialchars($lib, ENT_QUOTES) . '">'
              . htmlspecialchars(stats_tronquer($lib, 42), ENT_QUOTES) . '</div>'
              . '<div class="barre-p"><span style="width:' . $pct . '%"></span></div>'
              . '<div class="barre-v">' . (int) $l[$cle_val] . '</div>'
              . '</div>';
    }
    return $out . '</div>';
}

/** Histogramme vertical compact (répartition par heure). */
function svg_heures(array $heures) {
    $max = max(1, max($heures));
    $L = 820; $h = 140; $pad_b = 22; $pad_h = 8;
    $lb = $L / 24;
    $s = '<svg viewBox="0 0 ' . $L . ' ' . $h . '" class="chart" role="img" '
       . 'aria-label="Fréquentation par heure" preserveAspectRatio="xMidYMid meet">';
    foreach ($heures as $hh => $v) {
        $bh = ($h - $pad_b - $pad_h) * ($v / $max);
        $x  = $hh * $lb + 3;
        $y  = $h - $pad_b - $bh;
        $s .= '<rect x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($lb - 6, 1)
            . '" height="' . round(max($bh, 1), 1) . '" rx="2" fill="#2f6df6" fill-opacity="'
            . ($v > 0 ? '0.75' : '0.15') . '"><title>' . $hh . 'h : ' . $v . '</title></rect>';
        if ($hh % 3 === 0) {
            $s .= '<text x="' . round($x + $lb / 2 - 3, 1) . '" y="' . ($h - 7)
                . '" text-anchor="middle" font-size="10" fill="#8a9099">' . $hh . 'h</text>';
        }
    }
    return $s . '</svg>';
}
