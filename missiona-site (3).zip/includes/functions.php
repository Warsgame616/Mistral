<?php
// Missiona - Fonctions utilitaires, sessions, sécurité, matching
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/stripe.php';
require_once __DIR__ . '/stripe-connect.php';

if (session_status() === PHP_SESSION_NONE) {
    // Nom de session court et uniforme : c'est aussi le paramètre d'URL
    // utilisé en repli quand le navigateur bloque les cookies (?sid=...).
    session_name('sid');

    // En HTTPS (et notamment dans un aperçu embarqué en iframe), les navigateurs
    // n'acceptent le cookie de session que s'il est marqué SameSite=None; Secure.
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $local = (strpos($host, 'localhost') === 0) || (strpos($host, '127.0.0.1') === 0);
    // Hors développement local, le site est servi en HTTPS (hébergeur ou aperçu
    // embarqué). Le cookie doit alors être Secure + SameSite=None, sinon les
    // navigateurs le refusent dans une iframe et la session ne tient pas.
    $https = !$local
          || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
          || (($_SERVER['SERVER_PORT'] ?? '') == 443);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'secure'   => $https,
        'samesite' => $https ? 'None' : 'Lax',
    ]);
    // Repli : si le navigateur bloque les cookies, l'identifiant de session est
    // relayé par l'URL. PHP le reprend alors automatiquement.
    $sid = $_GET['sid'] ?? $_POST['sid'] ?? '';
    if (empty($_COOKIE[session_name()]) && $sid
        && preg_match('/^[A-Za-z0-9,\-]{20,128}$/', $sid)) {
        session_id($sid);
        // Le cookie est refusé : PHP réécrit lui-même TOUS les liens et
        // formulaires internes pour y propager l'identifiant de session.
        // Indispensable pour les liens construits dynamiquement
        // (ex. admin-matching.php?id=12), que l'on ne peut pas traiter un à un.
        ini_set('session.use_cookies',      '0');
        ini_set('session.use_only_cookies', '0');
        ini_set('session.use_trans_sid',    '1');
        ini_set('session.trans_sid_tags',   'a=href,area=href,frame=src,form=');
        $h = $_SERVER['HTTP_HOST'] ?? '';
        if ($h !== '') { ini_set('session.trans_sid_hosts', $h); }
        @ini_set('url_rewriter.tags',       'a=href,area=href,frame=src,form=');
    }
    session_start();
}

/**
 * URL d'un fichier statique suffixée par sa date de modification.
 * Le navigateur recharge automatiquement la feuille de style ou le script
 * dès qu'on les modifie, sans avoir à vider le cache manuellement.
 */
function asset($chemin) {
    // Sert la version minifiée quand elle existe et qu'elle est à jour
    $min = preg_replace('/\.(css|js)$/', '.min.$1', $chemin);
    if ($min !== $chemin) {
        $aMin = __DIR__ . '/../' . ltrim($min, '/');
        $aSrc = __DIR__ . '/../' . ltrim($chemin, '/');
        if (is_file($aMin) && (!is_file($aSrc) || filemtime($aMin) >= filemtime($aSrc))) {
            $chemin = $min;
        }
    }
    $abs = __DIR__ . '/../' . ltrim($chemin, '/');
    $v   = is_file($abs) ? filemtime($abs) : time();
    return $chemin . '?v=' . $v;
}

/** Ajoute l'identifiant de session à une URL quand le cookie est refusé. */
function u($url) {
    if (!empty($_COOKIE[session_name()]) || empty($_SESSION['uid'])) { return $url; }
    if (strpos($url, 'sid=') !== false || strpos($url, '://') !== false) { return $url; }
    return $url . (strpos($url, '?') === false ? '?' : '&') . 'sid=' . urlencode(session_id());
}

// Initialise la base et les données de démonstration dès le premier accès au site
db();

/* ---------- Compatibilité : repli si l'extension mbstring est absente ---------- */
if (!function_exists('mb_substr')) {
    function mb_substr($s, $start, $length = null, $enc = null) {
        return $length === null ? substr((string)$s, $start) : substr((string)$s, $start, $length);
    }
}
if (!function_exists('mb_strlen'))   { function mb_strlen($s, $e = null)   { return strlen((string)$s); } }
if (!function_exists('mb_strtolower')){ function mb_strtolower($s, $e = null){ return strtolower((string)$s); } }
if (!function_exists('mb_strtoupper')){ function mb_strtoupper($s, $e = null){ return strtoupper((string)$s); } }
if (!function_exists('mb_str_split')) {
    function mb_str_split($s, $n = 1, $e = null) { return str_split((string)$s, $n); }
}

/* ---------- Sécurité / helpers ---------- */
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/** Clé de signature, persistée dans /data (hors racine web). */
function csrf_secret() {
    static $k = null;
    if ($k !== null) return $k;
    $f = __DIR__ . '/../data/.csrf_key';
    if (is_file($f)) { $k = trim(file_get_contents($f)); }
    if (empty($k)) {
        $k = bin2hex(random_bytes(32));
        if (!is_dir(dirname($f))) { @mkdir(dirname($f), 0755, true); }
        @file_put_contents($f, $k);
        @chmod($f, 0600);
    }
    return $k;
}

/**
 * Jeton CSRF signé (HMAC) et horodaté.
 * Il ne dépend PAS de la session : les formulaires restent utilisables même
 * quand le navigateur refuse les cookies (aperçu en iframe, cookies tiers
 * bloqués). La signature empêche toute falsification.
 */
function csrf_token() {
    $t = time();
    return $t . '.' . hash_hmac('sha256', (string)$t, csrf_secret());
}
function csrf_field() {
    $h = '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
    // Relaie aussi la session quand le cookie est bloqué
    if (empty($_COOKIE[session_name()]) && !empty($_SESSION['uid'])) {
        $h .= '<input type="hidden" name="sid" value="' . htmlspecialchars(session_id(), ENT_QUOTES) . '">';
    }
    return $h;
}
function csrf_valide($jeton) {
    if (!is_string($jeton) || strpos($jeton, '.') === false) { return false; }
    [$t, $sig] = explode('.', $jeton, 2);
    if (!ctype_digit($t)) { return false; }
    if (abs(time() - (int)$t) > 86400) { return false; }          // valable 24 h
    return hash_equals(hash_hmac('sha256', $t, csrf_secret()), $sig);
}

function csrf_check() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { return; }
    if (csrf_valide($_POST['csrf'] ?? '')) { return; }

    // Échec : le plus souvent la session a expiré ou le navigateur refuse le cookie.
    http_response_code(400);
    $retour = htmlspecialchars($_SERVER['HTTP_REFERER'] ?? 'index.php', ENT_QUOTES);
    echo '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>Session expirée</title>'
       . '<style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;'
       . 'background:#F8FAFC;color:#0F172A;display:grid;place-items:center;min-height:100vh;margin:0;padding:24px}'
       . '.b{max-width:460px;background:#fff;border:1px solid #E2E8F0;border-radius:16px;padding:32px;text-align:center}'
       . 'h1{font-size:1.25rem;margin:0 0 10px}p{color:#64748B;font-size:.9375rem;line-height:1.6;margin:0 0 22px}'
       . 'a{display:inline-block;padding:12px 22px;background:#165DFF;color:#fff;border-radius:10px;'
       . 'text-decoration:none;font-weight:600;font-size:.9375rem}</style></head><body><div class="b">'
       . '<div style="font-size:2.5rem;margin-bottom:12px">⏱️</div>'
       . '<h1>Votre session a expiré</h1>'
       . '<p>Par sécurité, le formulaire a été refusé car votre session n\'était plus active. '
       . 'Cela arrive après une longue inactivité, ou si votre navigateur bloque les cookies. '
       . 'Il suffit de recommencer.</p>'
       . '<a href="' . $retour . '">Réessayer</a>'
       . '</div></body></html>';
    exit;
}

/* ---------- Authentification ---------- */
function user($recharger = false) {
    if (empty($_SESSION['uid'])) return null;
    static $cache = null;
    if ($recharger) { $cache = null; }
    if ($cache && $cache['id'] == $_SESSION['uid']) return $cache;
    $st = db()->prepare("SELECT * FROM users WHERE id = ?");
    $st->execute([$_SESSION['uid']]);
    $cache = $st->fetch() ?: null;
    return $cache;
}
function is_logged() { return user() !== null; }
function role() { $u = user(); return $u ? $u['role'] : null; }

function require_role($roles) {
    $roles = (array)$roles;
    if (!is_logged()) { header('Location: ' . u('/connexion')); exit; }
    if (!in_array(role(), $roles, true)) { header('Location: ' . u('/')); exit; }
}

function login($email, $password) {
    $st = db()->prepare("SELECT * FROM users WHERE email = ? AND actif = 1");
    $st->execute([strtolower(trim($email))]);
    $u = $st->fetch();
    if ($u && password_verify($password, $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['uid'] = $u['id'];
        return $u;
    }
    return false;
}
function logout() { $_SESSION = []; session_destroy(); }

/* ---------- Réinitialisation de mot de passe (par e-mail) ---------- */

/**
 * Crée un jeton de réinitialisation pour un compte et envoie le lien.
 * Renvoie toujours true, que le compte existe ou non, pour ne pas
 * révéler quelles adresses sont inscrites.
 */
function mdp_demander_reinit($email) {
    $email = strtolower(trim((string) $email));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { return true; }

    $st = db()->prepare("SELECT * FROM users WHERE email = ? AND actif = 1");
    $st->execute([$email]);
    $u = $st->fetch();
    if (!$u) { return true; }

    // Un jeton aléatoire fort ; seul son condensat est stocké.
    $jeton = bin2hex(random_bytes(32));
    db()->prepare("INSERT INTO reinit_mdp (user_id, jeton_hash, expire_at)
                    VALUES (?, ?, datetime('now', '+1 hour'))")
        ->execute([(int) $u['id'], hash('sha256', $jeton)]);

    $lien = email_url('/mdp-reinitialiser.php?jeton=' . $jeton);
    $sujet = "Réinitialisation de votre mot de passe Missiona";
    $html  = email_gabarit("Réinitialisation de votre mot de passe",
        "<p>Bonjour,</p>"
      . "<p>Une demande de réinitialisation du mot de passe de votre compte Missiona a été faite. "
      . "Cliquez sur le lien ci-dessous pour choisir un nouveau mot de passe :</p>"
      . '<p style="margin:20px 0;"><a href="' . e($lien) . '" style="display:inline-block;background:#0b1c3d;color:#ffffff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:bold;">Choisir un nouveau mot de passe</a></p>'
      . "<p style=\"color:#6b7280;font-size:13px;\">Ce lien est valable 1 heure. Si vous n'êtes pas à l'origine de cette demande, "
      . "vous pouvez ignorer cet e-mail : votre mot de passe reste inchangé.</p>");
    email_envoyer($email, $sujet, $html);
    return true;
}

/** Vérifie un jeton ; renoie la ligne (user_id compris) ou false. */
function mdp_verifier_jeton($jeton) {
    if (!preg_match('/^[a-f0-9]{64}$/', (string) $jeton)) { return false; }
    $st = db()->prepare("SELECT * FROM reinit_mdp
                         WHERE jeton_hash = ? AND utilise = 0
                           AND expire_at > datetime('now')");
    $st->execute([hash('sha256', $jeton)]);
    return $st->fetch() ?: false;
}

/** Applique le nouveau mot de passe puis invalide tous les jetons du compte. */
function mdp_utiliser_jeton($ligne, $nouveau_mdp) {
    db()->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
        ->execute([password_hash($nouveau_mdp, PASSWORD_DEFAULT), (int) $ligne['user_id']]);
    db()->prepare("UPDATE reinit_mdp SET utilise = 1 WHERE user_id = ?")
        ->execute([(int) $ligne['user_id']]);
    return true;
}

/**
 * Le compte administrateur utilise-t-il encore le mot de passe livré
 * par défaut ? Tant que c'est le cas, n'importe qui connaissant le
 * logiciel peut entrer : on le signale de façon très visible.
 */
/**
 * L'application installable est-elle proposée à cet utilisateur ?
 * ------------------------------------------------------------------
 * Par défaut, elle est réservée à l'administration : tant que le
 * service n'est pas ouvert, inutile que des visiteurs installent une
 * application qu'ils ne pourraient pas encore utiliser.
 *
 * Le réglage « Application mobile » du back-office permet de l'ouvrir
 * à tous le moment venu, sans toucher au code.
 */
function app_mobile_visible($u = null) {
    if ((int) param('app_mobile_public', 0) === 1) { return true; }
    $u = $u ?: user();
    return $u && ($u['role'] ?? '') === 'admin';
}

function mot_de_passe_par_defaut($u = null) {
    $u = $u ?: user();
    if (!$u || ($u['role'] ?? '') !== 'admin') { return false; }
    if (!defined('ADMIN_PASSWORD') || ADMIN_PASSWORD === '')  { return false; }
    return password_verify(ADMIN_PASSWORD, (string) $u['password_hash']);
}

function dashboard_url($role = null, $avec_sid = false) {
    $role = $role ?: role();
    $url = match ($role) {
        'admin'                     => 'admin.php',
        'entreprise', 'particulier' => 'dashboard-entreprise.php',
        'freelance'                 => 'dashboard-freelance.php',
        default                     => 'index.php',
    };
    return $avec_sid ? u($url) : $url;
}

/** Un client est une entreprise OU un particulier : même parcours, même espace. */
function est_client($role = null) {
    $role = $role ?: role();
    return in_array($role, ['entreprise', 'particulier'], true);
}

/** Libellé lisible d'un rôle */
function role_label($role) {
    return ['entreprise'=>'Entreprise','particulier'=>'Particulier','freelance'=>'Freelance','admin'=>'Administration'][$role] ?? ucfirst($role);
}

/* ---------- Données ---------- */
function flash($msg = null, $type = 'success') {
    if ($msg !== null) { $_SESSION['flash'] = ['m' => $msg, 't' => $type]; return; }
    if (!empty($_SESSION['flash'])) { $f = $_SESSION['flash']; unset($_SESSION['flash']); return $f; }
    return null;
}

/* ─────────────────────────────────────────────────────────────
   PAIEMENT DIRECT CLIENT → EXPERT
   L'entreprise règle l'expert directement, au montant convenu :
   Missiona n'encaisse rien. La rémunération de Missiona (commission
   d'apport d'affaires) est facturée à l'expert, et n'est exigible
   qu'une fois le client réglé. Aucun frais fixe : le forfait de
   service a été supprimé le 2 octobre 2026.
   ───────────────────────────────────────────────────────────── */

/**
 * Mode gratuit : Missiona renonce à sa propre rémunération.
 * ------------------------------------------------------------------
 * Le client règle TOUJOURS l'expert directement, hors plateforme —
 * Missiona n'encaisse jamais. Ce mode suspend en plus la facturation
 * de la commission d'apport d'affaires que Missiona adresse
 * normalement à l'expert.
 *
 * Utile en phase de lancement ou pour un test sans facturation.
 */
function mode_gratuit() { return (int) param('mode_gratuit', 0) === 1; }

/** Taux de commission d'apport d'affaires en % (paramétrable dans l'admin). */
function taux_frais() { return mode_gratuit() ? 0.0 : (float) param('commission', 20); }

/**
 * Historique : frais de dossier facturés à l'entreprise dans l'ancien
 * modèle. Conservé pour la lecture d'anciennes données ; le modèle en
 * vigueur est le paiement direct (aucun frais côté entreprise).
 */
function frais_dossier() {
    if (mode_gratuit()) { return 0; }
    return defined('FRAIS_DOSSIER') ? (int) FRAIS_DOSSIER : 2;
}

/**
 * Décompose un montant de mission.
 * Le prix annoncé au client inclut déjà la part Missiona : le client
 * ne voit qu'un total, le freelance perçoit sa base intégrale.
 * @param int $base Montant revenant au freelance (son prix).
 * @return array{base:int,part:int,total:int}
 */
function decomposer_montant($base) {
    $base = max(0, (int) $base);
    $part = (int) round($base * (taux_frais() / 100));
    return ['base' => $base, 'part' => $part, 'total' => $base + $part];
}

/** Les deux paiements d'un projet, indexés par type. */
function paiements_projet($projet_id) {
    $st = db()->prepare("SELECT * FROM paiements WHERE projet_id=? ORDER BY id");
    $st->execute([$projet_id]);
    $out = [];
    foreach ($st->fetchAll() as $r) { $out[$r['type']] = $r; }
    return $out;
}

/** Crée l'échéance demandée si elle n'existe pas déjà. */
function creer_paiement($projet_id, $type, $montant, $statut = 'a_payer') {
    $st = db()->prepare("SELECT COUNT(*) FROM paiements WHERE projet_id=? AND type=?");
    $st->execute([$projet_id, $type]);
    if ($st->fetchColumn()) { return false; }
    db()->prepare("INSERT INTO paiements (projet_id,type,montant,statut) VALUES (?,?,?,?)")
        ->execute([$projet_id, $type, (int) $montant, $statut]);
    return true;
}

/**
 * Enregistre un règlement.
 * En paiement direct, la ligne « projet » passe à « paye » lorsque
 * l'entreprise confirme avoir réglé l'expert. L'ancienne ligne « frais »
 * (héritée) resterait « en suspens » jusqu'à la livraison.
 */
function regler_paiement($projet_id, $type, $stripe_ref = '') {
    $statut = ($type === 'frais') ? 'en_suspens' : 'paye';
    db()->prepare("UPDATE paiements SET statut=?, paye_le=CURRENT_TIMESTAMP, reference=?, stripe_ref=? WHERE projet_id=? AND type=? AND statut='a_payer'")
        ->execute([
            $statut,
            strtoupper($type[0]) . '-' . date('Ymd') . '-' . str_pad($projet_id, 4, '0', STR_PAD_LEFT),
            $stripe_ref, $projet_id, $type,
        ]);
}

/**
 * Met à jour le montant de l'échéance « projet » tant qu'elle n'est pas réglée.
 * Indispensable : le montant fixé à l'attribution est une estimation basée sur
 * le tarif de l'expert ; l'équipe arrête le montant réel à la livraison.
 */
function maj_montant_projet($projet_id, $base) {
    $d = decomposer_montant((int) $base);
    $st = db()->prepare("UPDATE paiements SET montant=? WHERE projet_id=? AND type='projet' AND statut='a_payer'");
    $st->execute([$d['total'], $projet_id]);
    if ($st->rowCount() === 0) {
        // L'échéance n'existait pas encore (projet terminé sans attribution) : on la crée.
        creer_paiement($projet_id, 'projet', $d['total'], 'a_payer');
    }
    return $d;
}

/* ─────────────────────────────────────────────────────────────
   ÉQUIPE MISSIONA
   ───────────────────────────────────────────────────────────── */

/**
 * L'administrateur principal : le compte dont l'e-mail est ADMIN_EMAIL.
 * Lui seul gère les comptes admin et les assignations. À défaut (compte
 * renommé ou supprimé), on retombe sur le plus ancien admin.
 */
function admin_principal() {
    static $p = null;
    if ($p !== null) { return $p; }
    if (defined('ADMIN_EMAIL')) {
        $st = db()->prepare("SELECT * FROM users WHERE role='admin' AND email=? LIMIT 1");
        $st->execute([ADMIN_EMAIL]);
        if ($r = $st->fetch()) { return $p = $r; }
    }
    $r = db()->query("SELECT * FROM users WHERE role='admin' ORDER BY id LIMIT 1")->fetch();
    return $p = ($r ?: null);
}

/** L'utilisateur donné est-il l'administrateur principal ? */
function est_admin_principal($u = null) {
    $u = $u ?: user();
    if (!$u || ($u['role'] ?? '') !== 'admin') { return false; }
    $p = admin_principal();
    return $p && (int) $p['id'] === (int) $u['id'];
}

/** Réservé à l'administrateur principal : redirige les autres. */
function require_admin_principal() {
    require_role('admin');
    if (!est_admin_principal()) {
        flash("Cette action est réservée à l'administrateur principal.", 'error');
        header('Location: ' . u('/admin')); exit;
    }
}

/**
 * Cet admin peut-il MODIFIER ce projet ?
 * Le principal peut tout ; un gestionnaire n'agit que sur ses clients.
 * Un projet sans gestionnaire assigné reste ouvert à toute l'équipe.
 */
function peut_gerer_projet($projet, $u = null) {
    $u = $u ?: user();
    if (!$u || ($u['role'] ?? '') !== 'admin') { return false; }
    if (est_admin_principal($u))       { return true; }
    $st = db()->prepare("SELECT gestionnaire_id FROM users WHERE id=?");
    $st->execute([(int) ($projet['entreprise_id'] ?? 0)]);
    $g = (int) $st->fetchColumn();
    return $g === 0 || $g === (int) $u['id'];
}

/** Idem pour un client donné (entreprise/particulier). */
function peut_gerer_client($client_id, $u = null) {
    $u = $u ?: user();
    if (!$u || ($u['role'] ?? '') !== 'admin') { return false; }
    if (est_admin_principal($u))       { return true; }
    $st = db()->prepare("SELECT gestionnaire_id FROM users WHERE id=?");
    $st->execute([(int) $client_id]);
    $g = (int) $st->fetchColumn();
    return $g === 0 || $g === (int) $u['id'];
}

/** Message affiché quand la modification est refusée. */
function refus_gestion() {
    return "Ce client est suivi par un autre gestionnaire : vous pouvez consulter, pas modifier.";
}

/** Les entreprises/particuliers suivis par un gestionnaire. */
function clients_du_gestionnaire($admin_id) {
    $st = db()->prepare("SELECT * FROM users
                         WHERE role IN ('entreprise','particulier') AND gestionnaire_id=?
                         ORDER BY societe, nom");
    $st->execute([(int) $admin_id]);
    return $st->fetchAll();
}

/** Assigne un client à un gestionnaire (0 = aucun). */
function assigner_gestionnaire($client_id, $admin_id) {
    $admin_id = (int) $admin_id;
    if ($admin_id !== 0) {
        $st = db()->prepare("SELECT COUNT(*) FROM users WHERE id=? AND role='admin'");
        $st->execute([$admin_id]);
        if (!$st->fetchColumn()) { return false; }
    }
    $st = db()->prepare("UPDATE users SET gestionnaire_id=? WHERE id=? AND role IN ('entreprise','particulier')");
    $st->execute([$admin_id, (int) $client_id]);
    return $st->rowCount() > 0;
}

/** Admins éligibles à la répartition automatique (principal inclus selon le réglage). */
function gestionnaires_repartition() {
    $rows = db()->query("SELECT id, prenom, nom, email FROM users WHERE role='admin' AND actif=1 ORDER BY id")->fetchAll();
    if (!$rows) { return []; }
    if (!(int) param('repartition_inclut_principal', 1)) {
        $princ = admin_principal();
        if ($princ) {
            $sans = array_values(array_filter($rows, fn($r) => (int) $r['id'] !== (int) $princ['id']));
            if ($sans) { return $sans; }
        }
    }
    return $rows;
}

/** Nombre de projets actifs suivis par chaque admin éligible : [admin_id => total]. */
function charge_gestionnaires() {
    $charge = [];
    foreach (gestionnaires_repartition() as $g) { $charge[(int) $g['id']] = 0; }
    if (!$charge) { return []; }
    $sql = "SELECT c.gestionnaire_id AS gid, COUNT(p.id) AS n
            FROM projets p JOIN users c ON c.id = p.entreprise_id
            WHERE c.gestionnaire_id > 0 AND p.statut NOT IN ('termine','annule')
            GROUP BY c.gestionnaire_id";
    foreach (db()->query($sql) as $r) {
        $gid = (int) $r['gid'];
        if (isset($charge[$gid])) { $charge[$gid] = (int) $r['n']; }
    }
    return $charge;
}

/** Gestionnaire le moins chargé (égalité départagée par le moins de clients, puis par id). */
function gestionnaire_le_moins_charge() {
    $charge = charge_gestionnaires();
    if (!$charge) { return 0; }
    $best = 0; $bestN = PHP_INT_MAX; $bestC = PHP_INT_MAX;
    foreach ($charge as $gid => $n) {
        $st = db()->prepare("SELECT COUNT(*) FROM users WHERE gestionnaire_id=?");
        $st->execute([$gid]);
        $c = (int) $st->fetchColumn();
        if ($n < $bestN || ($n === $bestN && $c < $bestC)) { $best = $gid; $bestN = $n; $bestC = $c; }
    }
    return $best;
}

/** Assigne un client non suivi au gestionnaire le moins chargé. Renvoie l'id retenu ou 0. */
function auto_assigner_client($client_id) {
    if (!(int) param('repartition_auto', 1)) { return 0; }
    $st = db()->prepare("SELECT gestionnaire_id FROM users WHERE id=? AND role IN ('entreprise','particulier')");
    $st->execute([(int) $client_id]);
    $cur = $st->fetchColumn();
    if ($cur === false || (int) $cur > 0) { return 0; }
    $gid = gestionnaire_le_moins_charge();
    if ($gid && assigner_gestionnaire($client_id, $gid)) { return $gid; }
    return 0;
}

/** Rééquilibre tous les clients entre gestionnaires. $tout=false : seuls les clients non assignés. */
function repartir_clients($tout = false) {
    $gs = array_map(fn($g) => (int) $g['id'], gestionnaires_repartition());
    if (!$gs) { return 0; }
    $sql = "SELECT c.id, COUNT(CASE WHEN p.statut NOT IN ('termine','annule') THEN 1 END) AS n
            FROM users c LEFT JOIN projets p ON p.entreprise_id = c.id
            WHERE c.role IN ('entreprise','particulier')" . ($tout ? "" : " AND c.gestionnaire_id = 0") . "
            GROUP BY c.id ORDER BY n DESC, c.id";
    $clients = db()->query($sql)->fetchAll();
    if (!$clients) { return 0; }
    $charge = $tout ? array_fill_keys($gs, 0) : charge_gestionnaires();
    foreach ($gs as $g) { if (!isset($charge[$g])) { $charge[$g] = 0; } }
    $n = 0;
    db()->beginTransaction();
    try {
        foreach ($clients as $c) {
            asort($charge);
            $gid = (int) array_key_first($charge);
            if (assigner_gestionnaire($c['id'], $gid)) { $n++; }
            $charge[$gid] += max(1, (int) $c['n']);
        }
        db()->commit();
    } catch (Exception $ex) { db()->rollBack(); return 0; }
    return $n;
}

/** Gestionnaire d'un client, ou null. */
function gestionnaire_de($client) {
    $id = (int) ($client['gestionnaire_id'] ?? 0);
    if (!$id) { return null; }
    $st = db()->prepare("SELECT * FROM users WHERE id=? AND role='admin'");
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

/**
 * Nom du chargé de compte vu par le client : son gestionnaire assigné si
 * l'équipe lui en a désigné un, sinon le nom générique paramétrable.
 */
function charge_compte_nom($client = null) {
    $client = $client ?: user();
    if ($client && isset($client['gestionnaire_id']) && (int) $client['gestionnaire_id'] > 0) {
        if ($g = gestionnaire_de($client)) {
            $n = trim($g['prenom'] . ' ' . $g['nom']);
            if ($n !== '') { return $n; }
        }
    }
    $v = trim((string) param('charge_nom', ''));
    return $v !== '' ? $v : 'Sophie Dupont';
}

/** Intitulé du chargé de compte. */
function charge_compte_role($client = null) {
    $client = $client ?: user();
    if ($client && isset($client['gestionnaire_id']) && (int) $client['gestionnaire_id'] > 0 && gestionnaire_de($client)) {
        return 'Gestionnaire de projet';
    }
    $v = trim((string) param('charge_role', ''));
    return $v !== '' ? $v : 'Chargée de compte';
}

/** Initiales du chargé de compte, pour l'avatar. */
function charge_initiales($client = null) {
    $parts = preg_split('/\s+/', trim(charge_compte_nom($client)));
    $a = mb_substr($parts[0] ?? '', 0, 1);
    $b = count($parts) > 1 ? mb_substr(end($parts), 0, 1) : '';
    return mb_strtoupper($a . $b) ?: 'WC';
}

/** Enregistre un paramètre. */
function set_param($cle, $valeur) {
    db()->prepare("INSERT INTO parametres (cle,valeur) VALUES (?,?)
                   ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur")
        ->execute([$cle, (string) $valeur]);
}

/** Tous les comptes administrateurs. */
function admins() {
    return db()->query("SELECT * FROM users WHERE role='admin' ORDER BY id")->fetchAll();
}

/** Nombre de comptes admin encore actifs. */
function nb_admins() {
    return (int) db()->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
}

/**
 * Crée un compte administrateur.
 * @return array{ok:bool,erreur:string}
 */
function creer_admin($email, $mdp, $nom, $prenom = '') {
    $email = trim(mb_strtolower($email));
    $nom   = trim($nom);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'erreur' => "Adresse e-mail invalide."];
    }
    if (mb_strlen($mdp) < 8) {
        return ['ok' => false, 'erreur' => "Le mot de passe doit faire au moins 8 caractères."];
    }
    if ($nom === '') {
        return ['ok' => false, 'erreur' => "Le nom est obligatoire."];
    }
    $st = db()->prepare("SELECT COUNT(*) FROM users WHERE email=?");
    $st->execute([$email]);
    if ($st->fetchColumn()) {
        return ['ok' => false, 'erreur' => "Cette adresse est déjà utilisée."];
    }
    db()->prepare("INSERT INTO users (email,password_hash,role,nom,prenom) VALUES (?,?,'admin',?,?)")
        ->execute([$email, password_hash($mdp, PASSWORD_DEFAULT), $nom, trim($prenom)]);
    return ['ok' => true, 'erreur' => ''];
}

/**
 * Supprime un compte administrateur.
 * Refuse de supprimer le dernier admin ou soi-même.
 */
function supprimer_admin($id, $moi) {
    $id = (int) $id;
    if ($id === (int) $moi)  { return ['ok' => false, 'erreur' => "Vous ne pouvez pas supprimer votre propre compte."]; }
    $p = admin_principal();
    if ($p && $id === (int) $p['id']) {
        return ['ok' => false, 'erreur' => "L'administrateur principal ne peut pas être supprimé."];
    }
    if (nb_admins() <= 1)    { return ['ok' => false, 'erreur' => "Il doit rester au moins un administrateur."]; }
    $st = db()->prepare("SELECT COUNT(*) FROM users WHERE id=? AND role='admin'");
    $st->execute([$id]);
    if (!$st->fetchColumn()) { return ['ok' => false, 'erreur' => "Compte introuvable."]; }
    // Le compte est référencé par ses messages et notifications : on les
    // transfère au principal plutôt que d'échouer sur une clé étrangère.
    $repli = admin_principal();
    $repli = $repli ? (int) $repli['id'] : 0;
    if ($repli === $id || !$repli) {
        return ['ok' => false, 'erreur' => "Aucun compte de repli pour reprendre ses échanges."];
    }
    try {
        db()->beginTransaction();
        // Ses clients reviennent à l'équipe, ils ne restent pas orphelins.
        db()->prepare("UPDATE users SET gestionnaire_id=0 WHERE gestionnaire_id=?")->execute([$id]);
        // L'historique des échanges est conservé, rattaché au principal.
        db()->prepare("UPDATE messages SET expediteur_id=?   WHERE expediteur_id=?")->execute([$repli, $id]);
        db()->prepare("UPDATE messages SET destinataire_id=? WHERE destinataire_id=?")->execute([$repli, $id]);
        db()->prepare("DELETE FROM notifications WHERE user_id=?")->execute([$id]);
        db()->prepare("DELETE FROM users WHERE id=? AND role='admin'")->execute([$id]);
        db()->commit();
    } catch (Exception $e) {
        if (db()->inTransaction()) { db()->rollBack(); }
        return ['ok' => false, 'erreur' => "Suppression impossible : ce compte est encore rattaché à des données."];
    }
    return ['ok' => true, 'erreur' => ''];
}

/* ─────────────────────────────────────────────────────────────
   FORFAITS DES EXPERTS
   ───────────────────────────────────────────────────────────── */

/** Les forfaits proposés par un expert, du moins cher au plus cher. */
function forfaits_de($user_id) {
    $st = db()->prepare("SELECT * FROM forfaits WHERE user_id=? ORDER BY prix, id");
    $st->execute([$user_id]);
    return $st->fetchAll();
}

/** Ajoute un forfait. Retourne false si les données sont inexploitables. */
function ajouter_forfait($user_id, $nom, $prix, $delai = 0, $description = '') {
    $nom  = trim($nom);
    $prix = max(0, (int) $prix);
    if ($nom === '' || $prix <= 0) { return false; }
    db()->prepare("INSERT INTO forfaits (user_id,nom,description,prix,delai) VALUES (?,?,?,?,?)")
        ->execute([$user_id, mb_substr($nom, 0, 60), trim($description), $prix, max(0, (int) $delai)]);
    return true;
}

/** Supprime un forfait, à condition qu'il appartienne bien à l'utilisateur. */
function supprimer_forfait($id, $user_id) {
    db()->prepare("DELETE FROM forfaits WHERE id=? AND user_id=?")->execute([(int) $id, $user_id]);
}

/** Tarif de référence d'un expert : son forfait le moins cher, sinon son tarif unique. */
function tarif_reference($user) {
    $f = forfaits_de($user['id']);
    if ($f) { return (int) $f[0]['prix']; }
    return (int) ($user['tarif_projet'] ?? 0);
}

/** Libère les frais en suspens : la prestation est livrée. */
function liberer_frais($projet_id) {
    db()->prepare("UPDATE paiements SET statut='libere' WHERE projet_id=? AND type='frais' AND statut='en_suspens'")
        ->execute([$projet_id]);
}

/** Rembourse les frais en suspens (projet annulé). */
function rembourser_frais($projet_id) {
    db()->prepare("UPDATE paiements SET statut='rembourse' WHERE projet_id=? AND type='frais' AND statut IN ('en_suspens','a_payer')")
        ->execute([$projet_id]);
}

/** Étape 1 réglée ? Conditionne le démarrage de la mission. */
function frais_regles($projet_id) {
    $p = paiements_projet($projet_id);
    return isset($p['frais']) && in_array($p['frais']['statut'], ['en_suspens','libere'], true);
}

/* ─────────────────────────────────────────────────────────────
   DEMANDES D'ANNULATION ET DE REMBOURSEMENT
   ───────────────────────────────────────────────────────────── */

/** Demande en cours sur un projet, ou null. */
function demande_active($projet_id) {
    $st = db()->prepare("SELECT * FROM demandes WHERE projet_id=? AND statut='en_attente' ORDER BY id DESC LIMIT 1");
    $st->execute([$projet_id]);
    return $st->fetch() ?: null;
}

/** Historique complet des demandes d'un projet. */
function demandes_projet($projet_id) {
    $st = db()->prepare("SELECT d.*, u.nom, u.prenom, u.societe FROM demandes d
                         JOIN users u ON u.id = d.auteur_id
                         WHERE d.projet_id=? ORDER BY d.id DESC");
    $st->execute([$projet_id]);
    return $st->fetchAll();
}

/** Toutes les demandes en attente (back-office). */
function demandes_en_attente() {
    return db()->query("SELECT d.*, p.titre, p.statut AS p_statut, u.nom, u.prenom, u.societe
                        FROM demandes d
                        JOIN projets p ON p.id = d.projet_id
                        JOIN users u   ON u.id = d.auteur_id
                        WHERE d.statut='en_attente' ORDER BY d.id DESC")->fetchAll();
}

function nb_demandes_en_attente() {
    return (int) db()->query("SELECT COUNT(*) FROM demandes WHERE statut='en_attente'")->fetchColumn();
}

/**
 * Le client peut-il encore demander l'annulation ?
 * Impossible sur un projet déjà clos.
 */
function peut_demander_annulation($projet) {
    return !in_array($projet['statut'], ['termine','annule'], true);
}

/**
 * Annule un projet et solde les paiements.
 * Paiement direct : Missiona n'a rien encaissé. Les lignes encore dues
 * sont annulées ; un règlement déjà versé à l'expert est marqué
 * « remboursé » pour tracer la restitution organisée entre les parties.
 */
function annuler_projet($projet_id, $rembourser = true) {
    db()->prepare("UPDATE projets SET statut='annule' WHERE id=?")->execute([$projet_id]);
    // Paiement direct : Missiona n'encaisse rien, donc rien à rembourser
    // côté plateforme. Si le client a déjà réglé l'expert, le remboursement
    // se traite entre eux ; l'équipe l'indique dans sa réponse.
    if ($rembourser) {
        rembourser_frais($projet_id);
        db()->prepare("UPDATE paiements SET statut='rembourse' WHERE projet_id=? AND type='projet' AND statut='paye'")
            ->execute([$projet_id]);
    }
    db()->prepare("UPDATE paiements SET statut='annule' WHERE projet_id=? AND statut='a_payer'")
        ->execute([$projet_id]);
    db()->prepare("DELETE FROM factures WHERE projet_id=? AND statut='en_attente'")->execute([$projet_id]);
}

/** Supprime définitivement un projet et tout ce qui s'y rattache. */
function supprimer_projet($projet_id) {
    foreach (['demandes','paiements','factures','evaluations','messages','fichiers'] as $t) {
        db()->prepare("DELETE FROM $t WHERE projet_id=?")->execute([$projet_id]);
    }
    db()->prepare("DELETE FROM projets WHERE id=?")->execute([$projet_id]);
}

/** Identifiant du compte administrateur (robuste même après suppression du n°1). */
function admin_id() {
    static $id = null;
    if ($id !== null) return $id;
    $id = (int) db()->query("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1")->fetchColumn();
    return $id ?: 0;
}

function notify($user_id, $texte, $lien = '') {
    if (!$user_id) { return; }   // destinataire inconnu : on n'enregistre rien
    db()->prepare("INSERT INTO notifications (user_id,texte,lien) VALUES (?,?,?)")->execute([$user_id, $texte, $lien]);
}
function notifications($user_id, $limit = 10) {
    $st = db()->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT ?");
    $st->execute([$user_id, $limit]);
    return $st->fetchAll();
}
function nb_notifs_non_lues($user_id) {
    $st = db()->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND lu = 0");
    $st->execute([$user_id]);
    return (int)$st->fetchColumn();
}

function statut_label($s) {
    return [
        'nouveau'   => 'Nouveau',
        'analyse'   => 'En analyse',
        'attribue'  => 'Attribué',
        'en_cours'  => 'En cours',
        'livraison' => 'En livraison',
        'termine'   => 'Terminé',
        'annule'    => 'Annulé',
    ][$s] ?? $s;
}
/**
 * Avancement implicite d'un statut, en pourcentage.
 * Sert de valeur par défaut : l'équipe peut toujours saisir une autre valeur.
 */
function avancement_auto($statut) {
    return [
        'nouveau'   => 0,
        'analyse'   => 10,
        'attribue'  => 15,
        'en_cours'  => 50,
        'livraison' => 85,
        'termine'   => 100,
        'annule'    => 0,
    ][$statut] ?? 0;
}

function statut_classe($s) {
    return [
        'nouveau'   => 'badge-gray',
        'analyse'   => 'badge-amber',
        'attribue'  => 'badge-blue',
        'en_cours'  => 'badge-blue',
        'livraison' => 'badge-violet',
        'termine'   => 'badge-green',
        'annule'    => 'badge-red',
    ][$s] ?? 'badge-gray';
}
function euros($n) { return number_format((float)$n, 0, ',', ' ') . ' €'; }
/* Plafond du curseur budget : au-delà on affiche « 5 000 €+ ».
   Suit le réglage de config.php au lieu d'une valeur figée. */
define('BUDGET_PLAFOND', defined('BUDGET_PLAFOND_CFG') ? (int) BUDGET_PLAFOND_CFG : 5000);
function euros_max($n) {
    return number_format((float)$n, 0, ',', ' ') . ' €' . ((float)$n >= BUDGET_PLAFOND ? '+' : '');
}
function date_fr($d) { return $d ? date('d/m/Y', strtotime($d)) : '—'; }
function initiales($u) { return strtoupper(mb_substr($u['prenom'] ?: $u['nom'], 0, 1) . mb_substr($u['nom'], 0, 1)); }

/* ---------- Moteur de matching (critères mesurables, coefficients configurables) ---------- */
function calculer_matching($projet) {
    $coefs = [
        'competences' => (float)param('coef_competences', 40),
        'budget'      => (float)param('coef_budget', 25),
        'dispo'       => (float)param('coef_dispo', 15),
        'experience'  => (float)param('coef_experience', 10),
        'note'        => (float)param('coef_note', 10),
    ];
    $total_coef = array_sum($coefs) ?: 1;

    $freelances = db()->query("SELECT * FROM users WHERE role = 'freelance' AND actif = 1")->fetchAll();
    $requises = array_filter(array_map('trim', explode(',', mb_strtolower($projet['competences']))));
    $budget_moy = ($projet['budget_min'] + $projet['budget_max']) / 2;

    $res = [];
    foreach ($freelances as $f) {
        $detail = [];

        // 1. Correspondance des compétences
        $skills = array_filter(array_map('trim', explode(',', mb_strtolower($f['competences']))));
        $match = $requises ? count(array_intersect($requises, $skills)) / count($requises) : 0;
        $detail['competences'] = round($match * 100);

        // 2. Adéquation budgétaire : on retient le forfait le moins cher
        //    de l'expert, ou son tarif unique s'il n'en propose aucun.
        $tarif = tarif_reference($f);
        if ($budget_moy <= 0)      { $sb = 50; }   // budget inconnu : neutre
        elseif ($tarif <= 0)       { $sb = 50; }   // tarif non renseigné : neutre
        elseif ($tarif <= $budget_moy) { $sb = 100; }
        else { $sb = max(0, 100 - (($tarif - $budget_moy) / $budget_moy) * 100); }
        $detail['budget'] = round($sb);

        // 3. Disponibilité
        $detail['dispo'] = $f['disponibilite'] === 'disponible' ? 100 : ($f['disponibilite'] === 'partiel' ? 50 : 10);

        // 4. Expérience (plafonnée à 10 ans)
        $detail['experience'] = round(min($f['experience'], 10) / 10 * 100);

        // 5. Note moyenne
        $detail['note'] = round(($f['note_moyenne'] / 5) * 100);

        $score = 0;
        foreach ($coefs as $k => $c) { $score += $detail[$k] * $c; }
        $score = round($score / $total_coef);

        $res[] = ['freelance' => $f, 'score' => $score, 'detail' => $detail];
    }
    usort($res, fn($a, $b) => $b['score'] <=> $a['score']);
    return $res;
}

/* ---------- Statistiques admin ---------- */
function stats_globales() {
    $d = db();
    return [
        'entreprises'   => (int)$d->query("SELECT COUNT(*) FROM users WHERE role IN ('entreprise','particulier')")->fetchColumn(),
        'freelances'    => (int)$d->query("SELECT COUNT(*) FROM users WHERE role='freelance'")->fetchColumn(),
        'projets'       => (int)$d->query("SELECT COUNT(*) FROM projets")->fetchColumn(),
        'en_cours'      => (int)$d->query("SELECT COUNT(*) FROM projets WHERE statut IN ('attribue','en_cours','livraison')")->fetchColumn(),
        'a_traiter'     => (int)$d->query("SELECT COUNT(*) FROM projets WHERE statut IN ('nouveau','analyse')")->fetchColumn(),
        'termines'      => (int)$d->query("SELECT COUNT(*) FROM projets WHERE statut='termine'")->fetchColumn(),
        'ca'            => (int)$d->query("SELECT COALESCE(SUM(montant_final),0) FROM projets WHERE statut='termine'")->fetchColumn(),
        'commissions'   => (int)$d->query("SELECT COALESCE(SUM(commission),0) FROM factures")->fetchColumn(),
        'messages_nl'   => (int)$d->query("SELECT COUNT(*) FROM messages WHERE destinataire_id=1 AND lu=0")->fetchColumn(),
    ];
}

/* ============================================
   Gestion des fichiers téléversés
   ============================================ */

define('UPLOAD_MAX', 8 * 1024 * 1024); // 8 Mo

/** Extensions autorisées pour les livrables de projet */
function ext_doc_autorisees() {
    return ['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','csv','zip','rar',
            'jpg','jpeg','png','gif','webp','svg','ai','psd','fig','mp4','mov',
            // livrables techniques : ils sont stockés hors exécution et ne
            // sont jamais servis comme du code actif sur le site
            'html','htm','js','css','json','md','php','py','sql','sh','log',
            'yml','yaml','ini','xml'];
}
/**
 * Formats affichables dans la fenêtre d'aperçu.
 * Volontairement restreint : le SVG est un format exécutable, il ne
 * doit jamais être rendu en ligne sur notre domaine.
 */
function ext_apercu() {
    return array_merge(
        ['jpg','jpeg','png','gif','webp','pdf'],
        ['html','htm'],
        ext_code_apercu()
    );
}

/** Extensions de code/texte affichables en lecture seule dans l'aperçu. */
function ext_code_apercu() {
    return ['txt','csv','md','json','js','css','php','py','sh','sql','log',
            'yml','yaml','ini','xml'];
}

/**
 * Mode d'affichage d'un fichier dans la boîte d'aperçu protégée.
 *  - img   : image
 *  - pdf   : document PDF
 *  - html  : page rendue dans un cadre isolé (jamais le code)
 *  - texte : code affiché en lecture seule
 *  - false : aucun aperçu (téléchargement seul, si autorisé)
 * Le SVG et les formats exécutables restent exclus de l'aperçu.
 */
function apercu_mode($nom) {
    $ext = strtolower(pathinfo((string) $nom, PATHINFO_EXTENSION));
    if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) { return 'img'; }
    if ($ext === 'pdf')  { return 'pdf'; }
    if (in_array($ext, ['html','htm'], true)) { return 'html'; }
    if (in_array($ext, ext_code_apercu(), true)) { return 'texte'; }
    return false;
}

function fichier_previsualisable($nom) {
    return apercu_mode($nom) !== false;
}

/**
 * En-têtes + contenu pour l'affichage d'un document dans la boîte
 * d'aperçu. Chaque mode reçoit le type MIME qui l'empêche d'exécuter
 * du code dans notre domaine (le HTML est par ailleurs isolé côté
 * navigateur dans un cadre « sandbox »).
 */
function servir_apercu($chemin, $nom) {
    $mode = apercu_mode($nom);
    $ext  = strtolower(pathinfo((string) $nom, PATHINFO_EXTENSION));

    $mimes_img = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png',
                  'gif'=>'image/gif','webp'=>'image/webp'];

    switch ($mode) {
        case 'img':   $mime = $mimes_img[$ext]; break;
        case 'pdf':   $mime = 'application/pdf'; break;
        case 'html':  $mime = 'text/html'; break;
        case 'texte': $mime = 'text/plain'; break;
        default:      return false;
    }

    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: ' . $mime . '; charset=' . ($mode === 'img' || $mode === 'pdf' ? 'binary' : 'utf-8'));
    header('Content-Disposition: inline; filename="' . str_replace('"', '', $nom) . '"');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, max-age=0, must-revalidate');
    // Le document ne peut être encadré que par nos propres pages.
    header("Content-Security-Policy: frame-ancestors 'self'");
    header('Content-Length: ' . filesize($chemin));
    readfile($chemin);
    exit;
}

/** Extensions autorisées pour les images de portfolio */
function ext_img_autorisees() { return ['jpg','jpeg','png','gif','webp']; }

/**
 * Traite un fichier téléversé et le range dans /uploads/<sous_dossier>/
 * Renvoie ['ok'=>bool, 'nom'=>string, 'chemin'=>string, 'taille'=>int, 'erreur'=>string]
 */
function traiter_upload(array $file, $sous_dossier, array $extensions) {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'erreur' => "Aucun fichier sélectionné."];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'erreur' => "Le téléversement a échoué (le fichier est peut-être trop lourd)."];
    }
    if ($file['size'] > UPLOAD_MAX) {
        return ['ok' => false, 'erreur' => "Fichier trop volumineux : 8 Mo maximum."];
    }

    $nom_original = $file['name'];
    $ext = strtolower(pathinfo($nom_original, PATHINFO_EXTENSION));
    if (!in_array($ext, $extensions, true)) {
        return ['ok' => false, 'erreur' => "Format non autorisé (." . htmlspecialchars($ext) . ")."];
    }

    // Nom de stockage aléatoire : empêche l'écrasement et l'exécution
    $nom_stocke = bin2hex(random_bytes(12)) . '.' . $ext;
    $dossier = __DIR__ . '/../uploads/' . $sous_dossier;
    if (!is_dir($dossier)) { @mkdir($dossier, 0755, true); }
    $destination = $dossier . '/' . $nom_stocke;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return ['ok' => false, 'erreur' => "Impossible d'enregistrer le fichier sur le serveur."];
    }
    @chmod($destination, 0644);

    return [
        'ok'     => true,
        'nom'    => mb_substr($nom_original, 0, 180),
        'chemin' => $sous_dossier . '/' . $nom_stocke,
        'taille' => (int)$file['size'],
    ];
}

/** Récupère le portfolio d'un freelance */
function portfolio_de($user_id) {
    $st = db()->prepare("SELECT * FROM portfolio WHERE user_id = ? ORDER BY id DESC");
    $st->execute([$user_id]);
    return $st->fetchAll();
}

/** Icône associée à une extension de fichier */
function icone_fichier($nom) {
    $e = strtolower(pathinfo($nom, PATHINFO_EXTENSION));
    if (in_array($e, ['jpg','jpeg','png','gif','webp','svg','psd','ai','fig'])) return '🖼️';
    if (in_array($e, ['pdf'])) return '📕';
    if (in_array($e, ['doc','docx','txt'])) return '📄';
    if (in_array($e, ['xls','xlsx','csv'])) return '📊';
    if (in_array($e, ['ppt','pptx'])) return '📽️';
    if (in_array($e, ['zip','rar'])) return '🗜️';
    if (in_array($e, ['mp4','mov'])) return '🎬';
    if (in_array($e, ['html','htm','js','css','json','php','py','sql','sh','yml','yaml','ini','xml','md','log'])) return '💻';
    return '📎';
}

/** Taille lisible */
function taille_lisible($o) {
    if ($o >= 1048576) return round($o / 1048576, 1) . ' Mo';
    if ($o >= 1024)    return round($o / 1024) . ' Ko';
    return $o . ' o';
}

/* ============================================
   Référentiel des compétences, par domaine
   ============================================ */
function competences_par_domaine() {
    // Référentiel couvrant l'ensemble des familles de services proposées
    // par les grandes places de marché (Fiverr, Upwork) : le numérique,
    // mais aussi la finance, le juridique, l'ingénierie, l'assistance
    // administrative et le coaching.
    return [
        /* ---------- Technique ---------- */
        'Développement web' => ['PHP','JavaScript','TypeScript','React','Vue','Angular','Node.js','Laravel','Symfony','WordPress','Shopify','PrestaShop','Webflow','HTML/CSS','MySQL','PostgreSQL','API REST','E-commerce'],
        'Développement mobile' => ['Flutter','React Native','Swift','Kotlin','iOS','Android','Firebase','Application hybride','Publication sur les stores'],
        'Logiciels, jeux & blockchain' => ['Java','C#','C++','Python','.NET','Logiciel de bureau','Unity','Unreal Engine','Game design','Solidity','Smart contracts','Web3','Scripts d\'automatisation'],
        'Intelligence artificielle' => ['Agents IA','Chatbots','Intégration GPT','Prompt engineering','Automatisation IA','Vision par ordinateur','Traitement du langage','Modèles sur mesure','RAG / bases de connaissances','Génération d\'images'],
        'Data & analyse' => ['SQL','Python data','Data visualisation','Power BI','Tableau','Looker Studio','Excel avancé','Google Sheets','Web scraping','ETL','Statistiques','Machine learning','Tableaux de bord'],
        'Infrastructure, cloud & sécurité' => ['DevOps','Docker','Kubernetes','Linux','AWS','Azure','Google Cloud','Hébergement','Migration','Sauvegarde','Cybersécurité','Audit de sécurité','Conformité RGPD','Réseaux','Maintenance'],

        /* ---------- Création ---------- */
        'Design graphique & identité' => ['Logo','Charte graphique','Identité visuelle','Direction artistique','Print / Édition','Packaging','Affiche','Brochure','Carte de visite','Illustrator','Photoshop','InDesign','Canva'],
        'UI / UX & produit' => ['UI Design','UX Design','UX Research','Design system','Figma','Adobe XD','Maquettage','Prototypage','Webdesign','Accessibilité','Test utilisateur'],
        'Illustration & 3D' => ['Illustration','Dessin numérique','Character design','Bande dessinée','Modélisation 3D','Rendu 3D','Blender','Texturing','NFT / art numérique'],
        'Vidéo & animation' => ['Montage vidéo','After Effects','Premiere Pro','DaVinci Resolve','Motion design','Animation 2D','Animation 3D','Habillage vidéo','Sous-titrage','Vidéo courte / Reels','UGC','Vidéo explicative'],
        'Photographie' => ['Photo produit','Photo portrait','Photo immobilier','Photo événementielle','Retouche photo','Détourage','Colorimétrie','Direction photo'],
        'Musique & audio' => ['Voix off','Composition musicale','Mixage','Mastering','Sound design','Montage audio','Production de podcast','Jingle','Doublage'],

        /* ---------- Marketing & contenu ---------- */
        'Marketing digital' => ['SEO','SEA / Google Ads','Publicité Meta','LinkedIn Ads','TikTok Ads','Emailing','Newsletter','Growth hacking','Tunnel de conversion','Analytics','CRM','Marketing automation','Affiliation'],
        'Réseaux sociaux & influence' => ['Community management','Stratégie éditoriale','Création de contenu','Instagram','TikTok','LinkedIn','YouTube','Marketing d\'influence','Modération'],
        'Rédaction & contenu' => ['Rédaction web','Copywriting','Ghostwriting','Article de blog','Fiche produit','Communiqué de presse','Storytelling','Documentation technique','Correction','Relecture','Scénario','Livre blanc'],
        'Traduction & langues' => ['Traduction anglais','Traduction espagnol','Traduction allemand','Traduction italienne','Traduction arabe','Localisation','Sous-titrage traduit','Transcription','Interprétariat','Relecture bilingue'],

        /* ---------- Métiers & services ---------- */
        'Vente & développement commercial' => ['Prospection','Prise de rendez-vous','Téléprospection','Rédaction d\'offres','Négociation','Gestion de comptes','Stratégie commerciale','Études de marché'],
        'Assistance & administration' => ['Assistanat virtuel','Saisie de données','Gestion d\'agenda','Gestion de mails','Facturation','Secrétariat','Recherche documentaire','Annotation de données','Organisation d\'événements'],
        'Relation client' => ['Support client','Support par chat','Support téléphonique','Service après-vente','Zendesk','Rédaction de FAQ','Gestion des avis'],
        'Finance & comptabilité' => ['Comptabilité','Tenue de livres','Bilan','Déclarations fiscales','Paie','Prévisionnel','Modélisation financière','Analyse financière','Contrôle de gestion','Levée de fonds','Business plan','Direction financière externalisée'],
        'Juridique' => ['Rédaction de contrats','Conditions générales','Droit des sociétés','Propriété intellectuelle','Marques et brevets','Conformité','Protection des données','Droit du travail','Recherche juridique'],
        'Ressources humaines & formation' => ['Recrutement','Sourcing de candidats','Rédaction d\'offres d\'emploi','Intégration','Entretien annuel','Formation professionnelle','Ingénierie pédagogique','Création de module e-learning','Rédaction de CV'],
        'Conseil & stratégie' => ['Gestion de projet','Product management','Agile / Scrum','Conseil en organisation','Transformation numérique','Optimisation de processus','Étude de faisabilité','Gestion des achats','Supply chain'],
        'Ingénierie & architecture' => ['Architecture','Plans 2D','Modélisation BIM','AutoCAD','SolidWorks','Ingénierie mécanique','Génie civil','Électronique','Design industriel','Architecture d\'intérieur','Impression 3D','Étude thermique'],
        'Développement personnel & coaching' => ['Coaching professionnel','Coaching de vie','Préparation aux entretiens','Prise de parole','Gestion du temps','Bien-être au travail','Soutien scolaire','Cours de langue','Nutrition','Sport et forme'],
    ];
}

/**
 * Domaines proposés au client lorsqu'il dépose un projet.
 * Tirés du même référentiel que les compétences des experts : sans
 * cela, un projet classé « Design UI/UX » ne rencontrerait jamais un
 * expert rangé sous « UI / UX & produit ».
 */
function domaines_projet() {
    $d = array_keys(competences_par_domaine());
    $d[] = 'Autre';
    return $d;
}

/** Liste à plat de toutes les compétences */
function toutes_competences() {
    $out = [];
    foreach (competences_par_domaine() as $liste) { $out = array_merge($out, $liste); }
    return $out;
}

/**
 * Affiche le sélecteur de compétences groupé par domaine.
 * $selection : chaîne "PHP,Figma" des compétences déjà choisies.
 */
function champ_competences($selection = '', $input_id = 'competences') {
    $sel = array_filter(array_map('trim', explode(',', (string) $selection)));
    $id  = htmlspecialchars($input_id);

    echo '<input type="hidden" id="' . $id . '" name="' . $id . '" value="'
       . htmlspecialchars($selection, ENT_QUOTES) . '">';

    echo '<div class="skills-box" data-input="' . $id . '">';

    // Recherche : avec plus de 250 compétences, parcourir les domaines
    // un par un serait décourageant.
    echo '<div class="skills-search">'
       . '<input type="text" class="input" placeholder="Rechercher une compétence…" '
       . 'data-skills-search aria-label="Rechercher une compétence">'
       . '<span class="skills-count" data-skills-count></span>'
       . '</div>';
    echo '<p class="skills-vide" data-skills-vide hidden>Aucune compétence ne correspond.</p>';

    foreach (competences_par_domaine() as $domaine => $liste) {
        // Un domaine s'ouvre d'emblée s'il contient déjà une sélection
        $actifs = count(array_intersect($liste, $sel));
        $ouvert = $actifs > 0;

        echo '<div class="skills-group' . ($ouvert ? ' ouvert' : '') . '">';
        echo '<button type="button" class="skills-title" data-skills-toggle>'
           . '<span class="chev" aria-hidden="true">▸</span>'
           . '<span>' . htmlspecialchars($domaine) . '</span>'
           . '<span class="skills-badge" data-skills-actifs>' . ($actifs ?: '') . '</span>'
           . '</button>';
        echo '<div class="tagbox-inner">';
        foreach ($liste as $c) {
            $on = in_array($c, $sel, true) ? ' on' : '';
            echo '<span class="tag-opt' . $on . '">' . htmlspecialchars($c) . '</span>';
        }
        echo '</div></div>';
    }
    echo '</div>';
}

/* ---------------------------------------------------------------
   Mode maintenance — verrou global.
   Chargé en dernier pour que toutes les fonctions soient définies.
   --------------------------------------------------------------- */
require_once __DIR__ . '/payouts.php';
require_once __DIR__ . '/dac7.php';
require_once __DIR__ . '/pdf.php';
require_once __DIR__ . '/facture-pdf.php';
require_once __DIR__ . '/email.php';
require_once __DIR__ . '/google.php';
require_once __DIR__ . '/stats.php';
require_once __DIR__ . '/push.php';
require_once __DIR__ . '/equipe.php';
require_once __DIR__ . '/messagerie.php';
require_once __DIR__ . '/maintenance.php';
require_once __DIR__ . '/beta.php';

// La page de maintenance elle-même ne doit pas se verrouiller (boucle infinie)
// Présence de l'utilisateur, notée avant toute lecture de données
// pour que son propre voyant soit juste dès la première page.
equipe_marquer_presence();

if (basename($_SERVER['SCRIPT_NAME'] ?? '') !== 'maintenance.php') {
    maintenance_verrou();
    // La maintenance prime : elle ferme tout, la bêta ne fait que restreindre.
    beta_verrou();
}
