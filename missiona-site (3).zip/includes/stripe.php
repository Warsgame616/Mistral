<?php
/**
 * Missiona — Client Stripe minimal (PHP pur, sans dépendance externe)
 * ----------------------------------------------------------------------
 * Aucun framework, aucune bibliothèque à installer : simples appels HTTPS
 * à l'API Stripe. Fonctionne avec cURL, et bascule sur les flux natifs PHP
 * si l'extension n'est pas disponible.
 */

/** Stripe est-il configuré ? */
function stripe_actif() {
    return defined('STRIPE_SECRET_KEY')
        && STRIPE_SECRET_KEY !== ''
        && strpos(STRIPE_SECRET_KEY, 'sk_') === 0;
}

/** Mode test ou production, d'après le préfixe de la clé. */
function stripe_mode_test() {
    return stripe_actif() && strpos(STRIPE_SECRET_KEY, 'sk_test_') === 0;
}

/**
 * Appelle l'API Stripe.
 * @return array{ok:bool,data:array,erreur:string}
 */
function stripe_api($methode, $chemin, array $params = [], array $entetes_sup = []) {
    if (!stripe_actif()) {
        return ['ok' => false, 'data' => [], 'erreur' => "Stripe n'est pas configuré."];
    }

    $url  = 'https://api.stripe.com/v1/' . ltrim($chemin, '/');
    $body = $params ? http_build_query($params) : '';
    if ($methode === 'GET' && $body !== '') { $url .= '?' . $body; $body = ''; }

    $entetes = [
        'Authorization: Bearer ' . STRIPE_SECRET_KEY,
        'Content-Type: application/x-www-form-urlencoded',
        'Stripe-Version: 2024-06-20',
    ];
    foreach ($entetes_sup as $e) { $entetes[] = $e; }

    $brut = null;
    $code = 0;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $methode,
            CURLOPT_HTTPHEADER     => $entetes,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        if ($body !== '') { curl_setopt($ch, CURLOPT_POSTFIELDS, $body); }
        $brut = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($brut === false) {
            return ['ok' => false, 'data' => [], 'erreur' => 'Connexion à Stripe impossible : ' . $err];
        }
    } else {
        // Repli sans cURL
        $ctx = stream_context_create(['http' => [
            'method'        => $methode,
            'header'        => implode("\r\n", $entetes),
            'content'       => $body,
            'timeout'       => 30,
            'ignore_errors' => true,
        ]]);
        $brut = @file_get_contents($url, false, $ctx);
        if (isset($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m)) {
            $code = (int) $m[1];
        }
        if ($brut === false) {
            return ['ok' => false, 'data' => [], 'erreur' => 'Connexion à Stripe impossible.'];
        }
    }

    $data = json_decode($brut, true) ?: [];
    if ($code >= 200 && $code < 300) {
        return ['ok' => true, 'data' => $data, 'erreur' => ''];
    }
    return [
        'ok'     => false,
        'data'   => $data,
        'erreur' => $data['error']['message'] ?? ('Erreur Stripe (HTTP ' . $code . ').'),
    ];
}

/** URL de base du site, pour construire les retours de paiement. */
function site_url() {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir   = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return ($https ? 'https://' : 'http://') . $host . $dir;
}

/**
 * Compte de paiement de l'expert affecté à ce projet.
 * Renvoie une chaîne vide si aucun compte utilisable n'existe.
 */
function stripe_destination_expert($projet) {
    $fid = (int) ($projet['freelance_id'] ?? 0);
    if ($fid <= 0) { return ''; }

    $st = db()->prepare("SELECT * FROM users WHERE id = ?");
    $st->execute([$fid]);
    $u = $st->fetch();
    if (!$u) { return ''; }

    if (function_exists('connect_pret') && !connect_pret($u)) { return ''; }
    return (string) ($u['stripe_account'] ?? '');
}

/**
 * Crée une session de paiement Stripe Checkout.
 * @param array $projet Le projet concerné
 * @param string $type  'frais' ou 'projet'
 * @param int $montant  Montant en euros
 * @return array{ok:bool,url:string,erreur:string}
 */
function stripe_creer_session($projet, $type, $montant) {
    $libelle = ($type === 'frais')
        ? 'Validation de la proposition — ' . $projet['titre']
        : 'Règlement du projet — ' . $projet['titre'];

    $base   = site_url();
    $retour = $base . '/paiement-retour.php?projet=' . (int) $projet['id'] . '&type=' . urlencode($type);

    $params = [
        'mode'                                   => 'payment',
        'success_url'                            => $retour . '&statut=ok&session_id={CHECKOUT_SESSION_ID}',
        'cancel_url'                             => $retour . '&statut=annule',
        'client_reference_id'                    => $projet['id'] . '-' . $type,
        'line_items[0][quantity]'                => 1,
        'line_items[0][price_data][currency]'    => 'eur',
        'line_items[0][price_data][unit_amount]' => (int) round($montant * 100), // centimes
        'line_items[0][price_data][product_data][name]' => mb_substr($libelle, 0, 250),
        'metadata[projet_id]'                    => (int) $projet['id'],
        'metadata[type]'                         => $type,
    ];

    // Mode gratuit : le règlement est dirigé vers le compte de l'expert
    // dès l'encaissement. Les fonds ne transitent pas par le solde de
    // la plateforme, qui ne détient donc l'argent de personne.
    if (function_exists('mode_gratuit') && mode_gratuit() && $type === 'projet') {
        $dest = stripe_destination_expert($projet);
        if ($dest !== '') {
            $params['payment_intent_data[transfer_data][destination]'] = $dest;
            $params['metadata[versement]'] = 'direct';
        } else {
            // Sans compte d'expert utilisable, un paiement direct est
            // impossible : on refuse plutôt que d'encaisser des fonds
            // que la plateforme ne devrait pas détenir.
            return ['ok' => false, 'url' => '',
                    'erreur' => "L'expert n'a pas terminé la configuration de ses versements : "
                              . "le paiement direct est impossible."];
        }
    }

    $r = stripe_api('POST', 'checkout/sessions', $params);

    if (!$r['ok']) { return ['ok' => false, 'url' => '', 'erreur' => $r['erreur']]; }
    return ['ok' => true, 'url' => $r['data']['url'] ?? '', 'erreur' => ''];
}

/**
 * Vérifie auprès de Stripe qu'une session a bien été payée.
 * Ne jamais se fier au seul retour du navigateur : l'URL est falsifiable.
 */
function stripe_session_payee($session_id) {
    if ($session_id === '') { return false; }
    $r = stripe_api('GET', 'checkout/sessions/' . urlencode($session_id));
    return $r['ok'] && (($r['data']['payment_status'] ?? '') === 'paid');
}

/** Identifiant du paiement encaissé, pour tracer un remboursement. */
function stripe_payment_intent($session_id) {
    $r = stripe_api('GET', 'checkout/sessions/' . urlencode($session_id));
    return $r['ok'] ? (string) ($r['data']['payment_intent'] ?? '') : '';
}

/** Rembourse un paiement encaissé. */
function stripe_rembourser($payment_intent, $montant = null) {
    if ($payment_intent === '') { return ['ok' => false, 'erreur' => 'Référence de paiement absente.']; }
    $p = ['payment_intent' => $payment_intent];
    if ($montant !== null) { $p['amount'] = (int) round($montant * 100); }
    $r = stripe_api('POST', 'refunds', $p);
    return ['ok' => $r['ok'], 'erreur' => $r['erreur']];
}
