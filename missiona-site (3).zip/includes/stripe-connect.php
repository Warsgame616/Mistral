<?php
/**
 * Missiona — Stripe Connect (versements aux experts)
 * ------------------------------------------------------------------
 * Comptes « Express » : Stripe héberge le formulaire de collecte des
 * coordonnées bancaires et réalise la vérification d'identité (KYC).
 * Missiona ne stocke JAMAIS d'IBAN dans ce mode : seul l'identifiant
 * du compte Stripe (acct_…) est conservé.
 *
 * Fonctionnement en l'absence de clés : toutes les fonctions renvoient
 * un état inactif et la plateforme retombe sur le mode manuel
 * (coordonnées saisies dans le profil, virement fait par l'équipe).
 *
 * PHP pur, aucune dépendance : s'appuie sur includes/stripe.php.
 */

/** Connect est-il utilisable ? (mêmes clés que l'encaissement) */
function connect_actif() {
    return stripe_actif();
}

/**
 * Pays dans lesquels Stripe sait ouvrir un compte Express.
 * ------------------------------------------------------------------
 * Stripe fait évoluer cette liste régulièrement. Elle est modifiable
 * dans le back-office (Paramètres → Versements) sans toucher au code.
 * En cas d'erreur de liste, le site ne reste pas bloqué : si Stripe
 * refuse la création du compte, l'expert bascule automatiquement en
 * mode manuel (voir connect_basculer_en_manuel).
 */
function connect_pays_supportes() {
    $perso = trim((string) param('connect_pays', ''));
    if ($perso !== '') {
        $l = array_filter(array_map('trim', explode(',', strtoupper($perso))));
        if ($l) { return $l; }
    }
    return array_keys(pays_liste());
}

/** Stripe peut-il prendre en charge les versements vers ce pays ? */
function connect_pays_ok($pays) {
    $p = strtoupper(trim((string) $pays));
    if ($p === '' || $p === 'AUTRE') { return false; }
    return in_array($p, connect_pays_supportes(), true);
}

/**
 * Cet expert précis passe-t-il par Stripe ?
 * ------------------------------------------------------------------
 * C'est la question à poser partout, plutôt que connect_actif() :
 * un expert dont le pays n'est pas couvert, ou qui a été basculé en
 * manuel après un refus de Stripe, doit garder un moyen d'être payé.
 */
function connect_pour($u) {
    if (!connect_actif()) { return false; }
    if (!empty($u['payout_manuel']))  { return false; }
    // Compte déjà ouvert chez Stripe : on ne change plus de circuit.
    if (!empty($u['stripe_account'])) { return true; }
    $pays = $u['pays'] ?? '';
    // Pays pas encore choisi : on présente d'abord le parcours Stripe.
    if ($pays === '') { return true; }
    return connect_pays_ok($pays);
}

/** Bascule définitive d'un expert vers le versement manuel. */
function connect_basculer_en_manuel($user_id, $motif = '') {
    db()->prepare("UPDATE users SET payout_manuel = 1 WHERE id = ?")->execute([(int) $user_id]);
    if ($motif !== '') {
        @error_log('[connect] bascule manuelle user ' . (int) $user_id . ' : ' . $motif);
    }
}

/* ------------------------------------------------------------------
 *  Comptes experts
 * ------------------------------------------------------------------ */

/**
 * Crée le compte Express de l'expert s'il n'en a pas encore.
 * @return array{ok:bool,compte:string,erreur:string}
 */
function connect_compte_creer($u) {
    if (!connect_actif()) {
        return ['ok' => false, 'compte' => '', 'erreur' => "Stripe n'est pas configuré."];
    }
    if (!empty($u['stripe_account'])) {
        return ['ok' => true, 'compte' => $u['stripe_account'], 'erreur' => ''];
    }

    $pays = strtoupper(trim((string) ($u['pays'] ?? '')));
    if (strlen($pays) !== 2) { $pays = 'FR'; }

    $params = [
        'type'                                          => 'express',
        'country'                                       => $pays,
        'email'                                         => (string) $u['email'],
        'business_type'                                 => 'individual',
        'capabilities[transfers][requested]'            => 'true',
        'metadata[user_id]'                             => (int) $u['id'],
        'metadata[plateforme]'                          => 'Missiona',
        // Virement automatique vers la banque de l'expert dès réception.
        // Surtout pas 'manual' : les fonds resteraient bloqués sur son solde
        // Stripe sans jamais atteindre son compte bancaire. Le délai de
        // sécurité est déjà appliqué en amont par Missiona.
        'settings[payouts][schedule][interval]'          => 'daily',
    ];

    $r = stripe_api('POST', 'accounts', $params);
    if (!$r['ok']) {
        return ['ok' => false, 'compte' => '', 'erreur' => $r['erreur']];
    }

    $acct = (string) ($r['data']['id'] ?? '');
    if ($acct === '') {
        return ['ok' => false, 'compte' => '', 'erreur' => 'Réponse Stripe inattendue.'];
    }

    db()->prepare("UPDATE users SET stripe_account=? WHERE id=?")
        ->execute([$acct, (int) $u['id']]);

    return ['ok' => true, 'compte' => $acct, 'erreur' => ''];
}

/**
 * Lien d'inscription (ou de reprise) vers le formulaire hébergé par Stripe.
 * Ces liens sont à usage unique et expirent : toujours en régénérer un.
 */
function connect_lien_onboarding($u) {
    $c = connect_compte_creer($u);
    if (!$c['ok']) { return ['ok' => false, 'url' => '', 'erreur' => $c['erreur']]; }

    $base = site_url();
    $r = stripe_api('POST', 'account_links', [
        'account'     => $c['compte'],
        'refresh_url' => $base . '/profil.php?onglet=versements&connect=refresh',
        'return_url'  => $base . '/profil.php?onglet=versements&connect=retour',
        'type'        => 'account_onboarding',
    ]);

    if (!$r['ok']) { return ['ok' => false, 'url' => '', 'erreur' => $r['erreur']]; }
    return ['ok' => true, 'url' => (string) ($r['data']['url'] ?? ''), 'erreur' => ''];
}

/**
 * Lien vers le tableau de bord Express (l'expert y consulte ses virements
 * et met à jour son compte bancaire lui-même).
 */
function connect_lien_dashboard($u) {
    if (empty($u['stripe_account'])) { return ''; }
    $r = stripe_api('POST', 'accounts/' . urlencode($u['stripe_account']) . '/login_links');
    return $r['ok'] ? (string) ($r['data']['url'] ?? '') : '';
}

/**
 * Interroge Stripe sur l'état du compte et met la base à jour.
 * @return array{ok:bool,payouts:bool,details:bool,attente:array,erreur:string}
 */
function connect_rafraichir($u) {
    $vide = ['ok' => false, 'payouts' => false, 'details' => false, 'attente' => [], 'erreur' => ''];
    if (!connect_actif() || empty($u['stripe_account'])) { return $vide; }

    $r = stripe_api('GET', 'accounts/' . urlencode($u['stripe_account']));
    if (!$r['ok']) { $vide['erreur'] = $r['erreur']; return $vide; }

    $d       = $r['data'];
    $payouts = !empty($d['payouts_enabled']);
    $details = !empty($d['details_submitted']);
    $attente = $d['requirements']['currently_due'] ?? [];

    // Compte bancaire réellement enregistré chez Stripe : c'est lui qui
    // recevra l'argent. On en garde de quoi l'identifier à l'écran, jamais
    // l'IBAN complet — la plateforme n'a pas à le détenir.
    $banque = $d['external_accounts']['data'][0] ?? null;
    if ($banque === null) {
        $e = stripe_api('GET', 'accounts/' . urlencode($u['stripe_account']) . '/external_accounts',
                        ['object' => 'bank_account', 'limit' => 1]);
        if ($e['ok']) { $banque = $e['data']['data'][0] ?? null; }
    }
    $last4 = (string) ($banque['last4'] ?? '');
    $nom   = (string) ($banque['bank_name'] ?? '');
    $bpays = (string) ($banque['country'] ?? '');

    db()->prepare("UPDATE users SET stripe_payouts_ok=?, stripe_details_ok=?,
                          stripe_bank_last4=?, stripe_bank_nom=?, stripe_bank_pays=?
                   WHERE id=?")
        ->execute([$payouts ? 1 : 0, $details ? 1 : 0,
                   $last4, substr($nom, 0, 80), $bpays, (int) $u['id']]);

    return ['ok' => true, 'payouts' => $payouts, 'details' => $details,
            'attente' => $attente, 'banque' => $last4, 'erreur' => ''];
}

/** L'expert peut-il recevoir de l'argent ? (lecture rapide, sans appel réseau) */
function connect_pret($u) {
    return connect_actif() && !empty($u['stripe_account']) && !empty($u['stripe_payouts_ok']);
}

/**
 * Où part concrètement l'argent, en une ligne lisible.
 * Sert à lever le doute dans le back-office : l'administrateur voit le
 * compte destinataire avant de valider, sans jamais voir l'IBAN.
 */
function connect_destination($u) {
    if (empty($u['stripe_account'])) {
        return ['pret' => false, 'compte' => '', 'banque' => '',
                'texte' => "Aucun compte de paiement : l'expert n'a pas terminé son inscription."];
    }
    $banque = '';
    if (!empty($u['stripe_bank_last4'])) {
        $banque = trim(($u['stripe_bank_nom'] ?? '') . ' ••••' . $u['stripe_bank_last4']);
    }
    $pret = !empty($u['stripe_payouts_ok']);
    return [
        'pret'   => $pret,
        'compte' => (string) $u['stripe_account'],
        'banque' => $banque,
        'texte'  => $pret
            ? ($banque !== '' ? 'Compte bancaire ' . $banque : 'Compte de paiement vérifié')
            : "Compte créé mais pas encore validé : le virement serait refusé.",
    ];
}

/* ------------------------------------------------------------------
 *  Versements
 * ------------------------------------------------------------------ */

/**
 * Transfère des fonds du solde de la plateforme vers le compte de l'expert.
 * Le montant est en euros entiers ; Stripe attend des centimes.
 *
 * @return array{ok:bool,transfert:string,erreur:string}
 */
function connect_transferer($u, $montant, $retrait_id) {
    if (!connect_actif()) {
        return ['ok' => false, 'transfert' => '', 'erreur' => "Stripe n'est pas configuré."];
    }
    if (!connect_pret($u)) {
        return ['ok' => false, 'transfert' => '',
                'erreur' => "Le compte Stripe de l'expert n'est pas encore validé."];
    }
    $montant = (int) $montant;
    if ($montant <= 0) {
        return ['ok' => false, 'transfert' => '', 'erreur' => 'Montant invalide.'];
    }

    $r = stripe_api('POST', 'transfers', [
        'amount'                => $montant * 100,
        'currency'              => 'eur',
        'destination'           => $u['stripe_account'],
        'description'           => 'Missiona — versement #' . (int) $retrait_id,
        'metadata[retrait_id]'  => (int) $retrait_id,
        'metadata[user_id]'     => (int) $u['id'],
    ], [
        // Évite un double virement si la requête est rejouée.
        'Idempotency-Key: wc-retrait-' . (int) $retrait_id,
    ]);

    if (!$r['ok']) { return ['ok' => false, 'transfert' => '', 'erreur' => $r['erreur']]; }
    return ['ok' => true, 'transfert' => (string) ($r['data']['id'] ?? ''), 'erreur' => ''];
}

/** Solde disponible sur le compte plateforme, en euros (pour l'écran équipe). */
function connect_solde_plateforme() {
    if (!connect_actif()) { return null; }
    $r = stripe_api('GET', 'balance');
    if (!$r['ok']) { return null; }
    $total = 0;
    foreach (($r['data']['available'] ?? []) as $b) {
        if (strtolower($b['currency'] ?? '') === 'eur') { $total += (int) $b['amount']; }
    }
    return intdiv($total, 100);
}

/* ------------------------------------------------------------------
 *  Webhooks
 * ------------------------------------------------------------------ */

/**
 * Vérifie la signature d'un webhook Stripe (schéma v1, HMAC-SHA256).
 * Indispensable : sans cela, n'importe qui peut appeler l'URL.
 */
function connect_webhook_valide($charge_utile, $entete_signature, $secret, $tolerance = 300) {
    if ($secret === '' || $entete_signature === '') { return false; }

    $horodatage = '';
    $signatures = [];
    foreach (explode(',', $entete_signature) as $partie) {
        $kv = explode('=', trim($partie), 2);
        if (count($kv) !== 2) { continue; }
        if ($kv[0] === 't')  { $horodatage = $kv[1]; }
        if ($kv[0] === 'v1') { $signatures[] = $kv[1]; }
    }
    if ($horodatage === '' || !$signatures) { return false; }

    // Rejeu : on refuse un événement trop ancien.
    if (abs(time() - (int) $horodatage) > $tolerance) { return false; }

    $attendue = hash_hmac('sha256', $horodatage . '.' . $charge_utile, $secret);
    foreach ($signatures as $s) {
        if (hash_equals($attendue, $s)) { return true; }
    }
    return false;
}

/** Libellé lisible de l'état du compte Express. */
function connect_etat_label($u) {
    if (!connect_actif())              { return 'Mode manuel'; }
    if (empty($u['stripe_account']))   { return 'Non démarré'; }
    if (!empty($u['stripe_payouts_ok'])) { return 'Actif'; }
    if (!empty($u['stripe_details_ok'])) { return 'En cours de vérification'; }
    return 'À compléter';
}

function connect_etat_badge($u) {
    if (!connect_actif())                { return 'badge-gray'; }
    if (empty($u['stripe_account']))     { return 'badge-gray'; }
    if (!empty($u['stripe_payouts_ok'])) { return 'badge-green'; }
    if (!empty($u['stripe_details_ok'])) { return 'badge-blue'; }
    return 'badge-amber';
}
