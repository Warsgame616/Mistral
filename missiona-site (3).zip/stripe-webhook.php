<?php
/**
 * Missiona — Webhook Stripe (inactif)
 * ------------------------------------------------------------------
 * Le modèle « paiement direct » n'utilise plus d'encaissement en ligne :
 * aucun événement Stripe n'est attendu. Cette page répond poliment pour
 * éviter les erreurs si un webhook était encore déclaré côté Stripe,
 * puis il suffit de le supprimer dans le tableau de bord Stripe.
 */
http_response_code(200);
header('Content-Type: text/plain; charset=utf-8');
echo "OK - endpoint inactif (modèle paiement direct)\n";
