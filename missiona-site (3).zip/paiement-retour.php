<?php
/**
 * Missiona — Retour de paiement (page conservée pour compatibilité d'URL)
 * ------------------------------------------------------------------
 * Le modèle « paiement direct » ne comporte plus aucun encaissement en
 * ligne : le client règle l'expert directement. Cette page historique
 * (retour Stripe Checkout) redirige simplement vers le projet.
 */
require_once __DIR__ . '/includes/functions.php';
if (!is_logged()) { header('Location: ' . u('/connexion')); exit; }

$pid = (int) ($_GET['projet'] ?? 0);
flash("Le règlement s'effectue directement auprès de l'expert : aucun paiement en ligne n'est traité ici.", 'info');
header('Location: ' . u($pid > 0 ? 'projet.php?id=' . $pid : '/projets'));
exit;
